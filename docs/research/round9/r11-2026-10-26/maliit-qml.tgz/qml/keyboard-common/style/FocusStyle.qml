/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

QtObject {
    id: root
    property int resolution
    property color bgColor: "#E6E6E6"
    property color fgColor: "#4C5059"
    property int radius:       12 / resolution
    property int bottomMargin:  6 / resolution
    property int fontSize:     78 / resolution
    property int widthOffset:  30 / resolution
    property int heightOffset: 24 / resolution
    property real selectRatio: 0.95
    property string fontFamily: defaultFontFamily
    property int minimumMargin: 12 / resolution

    property var hotKey: QtObject {
        property int rightMargin: 12 / resolution
        property int height:      42 / resolution
        property int fontSize:    36 / resolution
        property color fgColor: "#4C5059"
    }
}
