/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

QtObject {
    id: root
    property real resolution
    property string fontFamily: defaultFontFamily
    property color bgMerge:"#3B4045"
    property int radius: 12 / resolution

    property var normal: QtObject {
        property color bgColor: "#42484E"
        property color fgColor: "#E6E6E6"
        property color borderColor: "#545A64"
        property int borderWidth: 4 / resolution
        property real fontSize:   78 / resolution
    }
    property var disable: QtObject {
        property color bgColor: "#42484E"
        property color fgColor: "#42484E"
        property color borderColor: "#545A64"
        property int borderWidth: 4 / resolution
        property real fontSize:   38 / resolution
    }
}

