/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

QtObject {
    id: root
    property int resolution
    property int width:   3840 / resolution
    property int height:   264 / resolution
    property int radius:    0
    property int seperator: 48 / resolution
    property int cellSpace: 12 / resolution
    property color bgColor: "#3B4045"

    property var symbolButton: QtObject {
        property string fontFamily: defaultFontFamily
        property color bgMerge:"#3B4045"
        property int width:  402 / resolution
        property int height: 132 / resolution
        property int minimumMargin: 12 / resolution
        property var normal: QtObject {
            property color bgColor: "#3B4045"
            property color fgColor: "#E6E6E6"
            property color borderColor: "#545A64"
            property int borderWidth: 4 / resolution
            property int fontSize:   70 / resolution
        }
        property var disable: QtObject {
            property color bgColor: "transparent"
            property color fgColor: "transparent"
            property color borderColor: "transparent"
            property int borderWidth: 0
            property int fontSize: 70 / resolution
        }
    }

    property var numberButton: QtObject {
        property string fontFamily: defaultFontFamily
        property color bgMerge:"#42484E"
        property int width:  174 / resolution
        property int height: 132 / resolution
        property int minimumMargin: 12 / resolution
        property var normal: QtObject {
            property color bgColor: "#42484E"
            property color fgColor: "#E6E6E6"
            property color borderColor: "#545A64"
            property int borderWidth: 4 / resolution
            property int fontSize:   78 / resolution
        }
        property var disable: QtObject {
            property color bgColor: "transparent"
            property color fgColor: "transparent"
            property color borderColor: "transparent"
            property int borderWidth: 0
            property int fontSize: 78 / resolution
        }
    }

    property var deleteButton: QtObject {
        property string fontFamily: defaultFontFamily
        property color bgMerge:"#3B4045"
        property int width:  402 / resolution
        property int height: 132 / resolution
        property var normal: QtObject {
            property color bgColor: "#3B4045"
            property color fgColor: "#E6E6E6"
            property color borderColor: "#545A64"
            property int borderWidth: 4 / resolution
            property int fontSize:   78 / resolution
        }
        property var disable: QtObject {
            property color bgColor: "transparent"
            property color fgColor: "transparent"
            property color borderColor: "transparent"
            property int borderWidth: 0
            property int fontSize:   78 / resolution
        }
    }

    property var enterButton: QtObject {
        property string fontFamily: defaultFontFamily
        property color bgMerge:"#3B4045"
        property int width:   402 / resolution
        property int height:  132 / resolution
        property int minimumMargin: 12 / resolution
        property var normal: QtObject {
            property color bgColor:"#248351"
            property color fgColor: "#E6E6E6"
            property color borderColor: "#545A64"
            property int borderWidth: 4 / resolution
            property int fontSize:   70 / resolution
        }
        property var disable: QtObject {
            property color bgColor: "transparent"
            property color fgColor: "transparent"
            property color borderColor: "transparent"
            property int borderWidth: 0
            property int fontSize: 70 / resolution
        }
    }
}

