/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "/usr/share/javascript/language-style/language-style.js" as LanguageStyle

QtObject {
    id: root

    readonly property int resolution_4k: 1
    readonly property int resolution_2k: 2
    readonly property int resolution_HD: 3
    readonly property real resolution_QHD: 1.5

    property real resolution : resolution_4k

    property color bgColor: "#3B4045"
    property real opacity: 1.0
    property int radius: 0
    property string defaultFontFamily: "LG Smart UI"

    property string webosVariant: "standard"
    property int keyboardDefaultWidth: 3840 / resolution
    property int keyboardDefaultHeight: 876 / resolution
    property int hidTopMargin:           66 / resolution
    property int hidPredHight:          264 / resolution
    property int hidPredWidth:         3840 / resolution

    property var left: QtObject {
        property int width:      402 / resolution
        property int height:     564 / resolution
        property int topMargin:   66 / resolution
        property int leftMargin: 546 / resolution
        property int cellWidth:  228 / resolution
        property int cellHeight: 132 / resolution
        property int cellSpace:   12 / resolution
        property int fontSize:    38 / resolution
    }

    property var right: QtObject {
        property int width:      402 / resolution
        property int height:     564 / resolution
        property int topMargin:   66 / resolution
        property int leftMargin:  48 / resolution
        property int rightMargin: 24 / resolution
        property int cellHeight: 132 / resolution
        property int cellSpace:   12 / resolution
    }

    property QtObject middle: QtObject {
        property int width:     1848 / resolution
        property int height:     564 / resolution
        property int topMargin:   66 / resolution
        property int leftMargin:  48 / resolution
        property int cellHeight: 132 / resolution
        property int cellWidth:  174 / resolution
        property int cellSpace:   12 / resolution
    }

    property var bottom: QtObject {
        property int width:         2098 / resolution
        property int height:         132 / resolution
        property int spaceBarWidth: 1848 / resolution
        property int topMargin:       48 / resolution
        property int leftMargin:     546 / resolution
        property int rightMargin:     26 / resolution
        property int bottomMargin:    26 / resolution
        property int cellSpace:       48 / resolution
        property int navCellSpace:     6 / resolution
        property int navBtnWidth:    198 / resolution
        property int hideBtnWidth:   140 / resolution
    }

    property var shiftButton: QtObject {
        property int dotWidth:  60 / resolution
        property int dotHeight: 60 / resolution
        property color normalColor: "#31363A"
        property color shiftColor : "#30AD6B"
    }

    property var focus : FocusStyle {resolution: root.resolution}

    property var panelFocus : PanelFocusStyle {resolution: root.resolution}

    property var button: ButtonStyle {resolution: root.resolution}

    property var symbolButton: SymbolButtonStyle {resolution: root.resolution}

    property var panelButton: PanelButtonStyle {resolution: root.resolution}

    property var pageCountButton: PageCountButtonStyle {resolution: root.resolution}

    property var numberKeyboard : NumberKeyboardStyle {resolution: root.resolution}

    property var predictPanel : PredictionPanelStyle {resolution: root.resolution}

    function getImage(name) {
        switch(root.resolution) {
            case resolution_4k:
                return "qrc:///images-4k/" + name + ".png";
            case resolution_2k:
                return "qrc:///images-2k/" + name + ".png";
            case resolution_HD:
                return "qrc:///images-hd/" + name + ".png";
        }
    }

    function setDefaultFont(langCode) {
        root.defaultFontFamily = getFontForLanguage(langCode);
    }

    function getFontForLanguage(langCode) {
        var style;
        try {
            style = LanguageStyle.getStyle(langCode);
        } catch (e) {
            console.warn("invalid lang value");
            style = LanguageStyle.getStyle("en-GB");
        }
        var isValidArr = ["item", "fontFamily"];
        var result = isValidArr.reduce(function (obj, current, idx) {
            if(obj[current]){
                return idx < isValidArr.length-1 ? obj[current] : true;
            }
            return false;
        }, style);
        console.warn("@@@ getFontForLanguage langCode : ", langCode, " ", style.item.fontFamily[0]);
        return result ? style.item.fontFamily[0] : defaultFontFamily;
    }
}