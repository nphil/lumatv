/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import QtGraphicalEffects 1.0

Rectangle {
    id: focucRect
    property variant focusStyle: style.focus
    property alias focusTxt: txt.text
    property alias hotKeyText: hotkey.text
    property alias fontSize: txt.font.pixelSize
    property url image
    property bool focusAdjust: false
    property alias dotColor: dotRect.circleColor
    property alias dotVisible: dotRect.visible
    property string focusedArea: ""
    property Item focusedItem: undefined

    color: focusStyle.bgColor
    radius: focusStyle.radius

    DotRect {
        id: dotRect
        objectName: "dotRect"
        visible: false
    }

    Text {
        id: hotkey
        objectName: "hotkey"
        anchors.top: parent.top
        anchors.right: parent.right
        anchors.rightMargin: focusStyle.hotKey.rightMargin
        height: focusStyle.hotKey.height
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment:   Text.AlignTop
        font.family:   focusStyle.fontFamily
        font.pixelSize: focusStyle.hotKey.fontSize
        color: focusStyle.hotKey.fgColor
    }

    // child objects
    Image {
        id: img
        source: image
        smooth: true
        anchors.centerIn: focucRect
    }

    Text {
        id: txt
        anchors.fill: parent
        anchors.margins: focusStyle.minimumMargin
        anchors.bottomMargin: focusStyle.bottomMargin
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        font.family: focusStyle.fontFamily
        font.weight: Font.DemiBold
        text: ""
        color: focusStyle.fgColor
        fontSizeMode: Text.Fit
    }

    layer.enabled: true
    layer.effect: DropShadow {
        cached: true
        samples: 24
        source: focucRect
        horizontalOffset: 0
        verticalOffset: 12
        color: "#000000"
        transparentBorder: true
    }
}
