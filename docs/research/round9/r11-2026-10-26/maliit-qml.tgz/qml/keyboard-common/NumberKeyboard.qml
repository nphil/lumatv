/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import com.meego.maliit 1.0
import "commonvariables.js" as CommonVariables

Rectangle {
    id: numberKeyboard
    objectName: "numberKeyboard"
    color: style.numberKeyboard.bgColor
    radius: style.numberKeyboard.radius

    property string mode: "Normal"

    signal ttsService(string text)
    signal sendKey(int keycode, bool shift, int eventType)
    signal sendText(string text)
    signal meetTopBoundary()
    signal meetBottomBoundary()
    signal orientationChanged(string orientation)

    function setFocusIn(x,y,w,h,txt,op) {
        focusRect.image = "";
        focusRect.visible = true;
        focusRect.height = h * op;
        focusRect.width = w * op;
        focusRect.x = x - (focusRect.width - w)/2;
        focusRect.y = y - (focusRect.height - h)/2;
        focusRect.focusTxt = txt;
    }

    function updateFocusItem() {
        if (focusRect.visible)
        {
            var item = focusRect.focusedItem;
            var xOffset = 0;
            var yOffset = 0;

            if (item.objectName === "symbolButton")
            {
                xOffset = numberBar.x;
            }
            else if (item.objectName === "deleteButton" || item.objectName === "enterButton")
            {
                xOffset = numberBar.x + tabButtons.x;
            }
            else    // number button
            {
                xOffset = numberBar.x + numberView.x;
            }
            yOffset = (style.numberKeyboard.height - style.numberKeyboard.symbolButton.height) / 2;

            var focusRectWidth = item.width  + focusRect.focusStyle.widthOffset;
            var focusRectHeight = item.height + focusRect.focusStyle.heightOffset;
            focusRect.width =  item.state === "Select" ? focusRectWidth  * focusRect.focusStyle.selectRatio : focusRectWidth;
            focusRect.height = item.state === "Select" ? focusRectHeight * focusRect.focusStyle.selectRatio : focusRectHeight;
            focusRect.x = xOffset + item.x - (focusRect.width - item.width) / 2;
            focusRect.y = yOffset + item.y - (focusRect.height - item.height) / 2;
        }
    }

    function setFocusItem(item,x,y) {
        focusRect.image = "";
        focusRect.visible = true;
        var focusRectWidth = item.width  + focusRect.focusStyle.widthOffset
        var focusRectHeight = item.height + focusRect.focusStyle.heightOffset
        focusRect.width =  item.state === "Select" ? focusRectWidth  * focusRect.focusStyle.selectRatio : focusRectWidth;
        focusRect.height = item.state === "Select" ? focusRectHeight * focusRect.focusStyle.selectRatio : focusRectHeight;
        focusRect.x = x - (focusRect.width - item.width) / 2;
        focusRect.y = y - (focusRect.height - item.height) / 2;
        focusRect.focusTxt = item.text;
        focusRect.fontSize = item.fontSize;
        focusRect.focusedArea = "number";
        focusRect.focusedItem = item;
    }

    function setFocusOut() {
        focusRect.visible = false;
        focusRect.focusTxt = "";
        focusRect.image = "";
    }

    function focusImage(img) {
        focusRect.image = img;
    }

    function updateHeight() {
        PluginProxy.setPanelSize(style.numberKeyboard.width, style.numberKeyboard.height);
        height = style.numberKeyboard.height;
    }

    function setMovableArea() {
        var number_area_width = style.numberKeyboard.symbolButton.width + style.numberKeyboard.seperator
                                + 10 * style.numberKeyboard.numberButton.width + 9 * style.numberKeyboard.cellSpace
                                + style.numberKeyboard.seperator + style.numberKeyboard.deleteButton.width
                                + style.numberKeyboard.cellSpace + style.numberKeyboard.enterButton.width;
        var number_area_height = style.numberKeyboard.symbolButton.height;
        var side_area_width = (style.numberKeyboard.width - number_area_width) / 2;
        var top_bottom_area_heigth = (style.numberKeyboard.height - number_area_height) / 2;
        var right_area_x = style.numberKeyboard.width - side_area_width;
        var bottom_area_y = style.numberKeyboard.height - top_bottom_area_heigth;

        PluginProxy.setMovableArea(Maliit.MovableAreaLeft, 0, 0, side_area_width, style.numberKeyboard.height);
        PluginProxy.setMovableArea(Maliit.MovableAreaTop, 0, 0, style.numberKeyboard.width, top_bottom_area_heigth);
        PluginProxy.setMovableArea(Maliit.MovableAreaRight, right_area_x, 0, side_area_width, style.numberKeyboard.height);
        PluginProxy.setMovableArea(Maliit.MovableAreaBottom, 0, bottom_area_y, style.numberKeyboard.width, top_bottom_area_heigth);
    }

    function removeMovableArea() {
        PluginProxy.setMovableArea(Maliit.MovableAreaLeft, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaTop, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaRight, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaBottom, 0, 0, 0, 0);
    }

    onFocusChanged: {
        if (focus) CommonVariables.savedFocusItem = numberRepeater.itemAt(5);
    }

    onOrientationChanged: {
        updateHeight();
        if (orientation.includes("portrait"))
            setMovableArea();
        else
        {
            removeMovableArea();
        }

        numberView.forceLayout();
        tabButtons.forceLayout();
        numberBar.forceLayout();
        updateFocusItem();
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Up) {
            numberKeyboard.meetTopBoundary()
            event.accepted =  true;
        }

        if (event.key === Qt.Key_Down) {
            numberKeyboard.meetBottomBoundary()
            event.accepted =  true;
        }
    }

    Row {
        id: numberBar
        anchors.horizontalCenter: numberKeyboard.horizontalCenter
        anchors.verticalCenter : numberKeyboard.verticalCenter
        spacing: style.numberKeyboard.seperator

        /* Symbol Button */
        ButtonBase {
            id: symbolButton
            objectName: "symbolButton"
            property string ttsStringSymbol: qsTr("Numbers to Symbols") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            property string ttsStringNumbers: qsTr("Symbols to Numbers") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")

            signal meetRightBoundary()
            borderPosition: 1
            buttonStyle: style.numberKeyboard.symbolButton
            width: style.numberKeyboard.symbolButton.width
            height: style.numberKeyboard.symbolButton.height

            text: (numberKeyboard.mode === "Symbol") ? "1 2 3" : "* + /"

            onReleased: {
                switch (numberKeyboard.mode) {
                case "Normal":
                    numberKeyboard.mode = "Symbol";
                    break;
                case "Symbol":
                    numberKeyboard.mode = "Normal";
                    break;
                default:
                    numberKeyboard.mode = "Normal";
                    break;
                }
                if (focus && numberKeyboard.mode === "Normal") numberKeyboard.ttsService(ttsStringSymbol)
                else if (focus && numberKeyboard.mode === "Symbol") numberKeyboard.ttsService(ttsStringNumbers)
            }
            onTtsService: {
                if (numberKeyboard.mode === "Normal") numberKeyboard.ttsService(ttsStringSymbol)
                else if (numberKeyboard.mode === "Symbol") numberKeyboard.ttsService(ttsStringNumbers)
            }

            Keys.onPressed: {
                if (event.key === Qt.Key_Right) {
                    meetRightBoundary();
                    event.accepted = true;
                }
            }

            KeyNavigation.left : enterButton

            onMeetRightBoundary: numberView.setKeyNavigation(0)

            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        focusRect.focusStyle = style.panelFocus;
                        numberKeyboard.setFocusItem(symbolButton, symbolButton.x + ((numberKeyboard.width - numberBar.width)/2),((numberKeyboard.height - symbolButton.height)/2));
                        break;
                    default:
                        break;
                }
            }
            onExited: numberKeyboard.setFocusOut()

            function setKeyNavigation() {
                symbolButton.focus = true;
            }
        }

        /* Numbers */
        Row {
            id: numberView
            objectName: "numberView"

            spacing: style.numberKeyboard.cellSpace
            property variant model

            signal meetLeftBoundary()
            signal meetRightBoundary()

            Repeater {
                id: numberRepeater
                objectName: "numberRepeater"
                model: numberView.model

                NumberButton {
                    buttonStyle: style.numberKeyboard.numberButton
                    width: style.numberKeyboard.numberButton.width
                    height: style.numberKeyboard.numberButton.height
                    mainChar: modelData.mainChar
                    symbolChar: modelData.symbolChar
                    borderPosition: 1
                    onTextKeyPressed: numberKeyboard.sendText(text)
                    onTtsService: {
                        var t;
                        switch (text) {
                        case "(":
                            t = qsTr("Open Parenthesis") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                            numberKeyboard.ttsService(t)
                            break;
                        case ")":
                            t = qsTr("Close Parenthesis") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                            numberKeyboard.ttsService(t)
                            break;
                        default:
                            numberKeyboard.ttsService(text)
                        }
                    }
                    onStateChanged: {
                        switch(state) {
                            case "Focus":
                            case "Select":
                                focusRect.focusStyle = style.panelFocus;
                                numberKeyboard.setFocusItem(numberRepeater.itemAt(index), numberRepeater.itemAt(index).x + ((numberKeyboard.width - numberBar.width)/2) + symbolButton.width + numberBar.spacing,
                                                            numberRepeater.itemAt(index).y + ((numberKeyboard.height -  numberRepeater.itemAt(index).height)/2));
                                break;
                            default:
                                break;
                        }
                    }
                    onExited: numberKeyboard.setFocusOut()
                    KeyNavigation.left:  numberRepeater.itemAt(index - 1)
                    KeyNavigation.right: numberRepeater.itemAt(index + 1)
                    Keys.onPressed: event.accepted = checkNavigationKey(index, event.key)
                }
                onItemRemoved: item.removed = true
            }

            onMeetLeftBoundary: symbolButton.setKeyNavigation()
            onMeetRightBoundary: tabButtons.setKeyNavigation()

            function setKeyNavigation(index) {
                if (index === 0)
                    numberRepeater.itemAt(0).focus = true;
                else if (index === 9)
                    numberRepeater.itemAt(9).focus = true;
            }
        }

        /* Function Keys */
        Row {
            id: tabButtons
            objectName: "tabButtons"
            spacing: style.numberKeyboard.cellSpace

            signal meetLeftBoundary()

            /* Delete Button */
            ButtonBase {
                id: deleteButton
                objectName: "deleteButton"
                property string ttsString: qsTr("Back Space") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                borderPosition: 1
                image: style.getImage("clear")
                onReleased: sendKey(14, false, eventType)
                onTtsService: numberKeyboard.ttsService(ttsString)

                buttonStyle: style.numberKeyboard.deleteButton
                width: style.numberKeyboard.deleteButton.width
                height: style.numberKeyboard.deleteButton.height

                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            focusRect.focusStyle = style.panelFocus;
                            numberKeyboard.setFocusItem(deleteButton, deleteButton.x + ((numberKeyboard.width - numberBar.width)/2) + symbolButton.width + numberView.width + (numberBar.spacing*2),
                                                        deleteButton.y + ((numberKeyboard.height -  deleteButton.height)/2));
                            numberKeyboard.focusImage(style.getImage("clear_f"))
                            break;
                        default:
                            break;
                    }
                }
                onExited: numberKeyboard.setFocusOut()
                KeyNavigation.right: enterButton
                Keys.onPressed: {
                    if (event.key === Qt.Key_Left) {
                        tabButtons.meetLeftBoundary();
                        event.accepted = true;
                    }
                }
            }

            /* Enter Button */
            ButtonBase {
                id: enterButton
                objectName: "enterButton"
                borderPosition: 0
                buttonStyle: style.numberKeyboard.enterButton
                text: qsTr("Enter") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                onReleased: sendKey(28, false, eventType)
                onTtsService: numberKeyboard.ttsService(text)

                width: style.numberKeyboard.enterButton.width
                height: style.numberKeyboard.enterButton.height

                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            focusRect.focusStyle = style.panelFocus;
                            numberKeyboard.setFocusItem(enterButton, enterButton.x + ((numberKeyboard.width - numberBar.width)/2) + symbolButton.width + numberView.width + (numberBar.spacing*2),
                                                     enterButton.y + ((numberKeyboard.height -  enterButton.height)/2));
                            break;
                        default:
                            break;
                    }
                }
                onExited: numberKeyboard.setFocusOut()
                KeyNavigation.left: deleteButton
            }

            onMeetLeftBoundary: numberView.setKeyNavigation(9)

            function setKeyNavigation() {
                deleteButton.focus = true;
            }
        }
        Connections {
            target: PluginProxy
            onKeyReleased : {
                if (isReleased && (symbolButton.state === "Select"))
                    symbolButton.state = "Focus";
                else if (isReleased && (deleteButton.state === "Select"))
                    deleteButton.state = "Focus";
                else if (isReleased && (enterButton.state === "Select"))
                    enterButton.state = "Focus";
            }
        }
    }

    Item {
        id: dragIconArea
        objectName:"dragIconArea"
        anchors.left: numberBar.right
        anchors.top: parent.top
        width: (parent.width - numberBar.width)/2
        height: parent.height
        visible:  isPortrait

        Image {
            id: dragIcon
            source: style.getImage("ic_drag");
            smooth: true
            anchors.centerIn: dragIconArea
        }
    }

    Component.onCompleted: drawNumberLayout()

    FocusPanel {
        id: focusRect
        objectName: "focusRect"
        focusStyle: style.focus
    }

    function drawNumberLayout() {
        var model = [];
        var key;

        for (var i = 0; i < 10; i++) {
            key = new Object;
            key.mainChar = CommonVariables.numbers[i];
            key.symbolChar = CommonVariables.numberSymbols[i];
            model.push(key);
        }
        numberView.model = model;
    }

    function checkNavigationKey(index, key) {
        var accepted = false;

        if (key === Qt.Key_Left && index === 0) {
            numberView.meetLeftBoundary();
            accepted = true;
        } else if (key === Qt.Key_Right && index === 9) {
            numberView.meetRightBoundary();
            accepted = true;
        }

        return accepted;
    }

    function setDefaultFocus() {
        CommonVariables.savedFocusItem.focus = false;
        CommonVariables.savedFocusItem = numberRepeater.itemAt(5);
    }

    function setFocusToEnter() {
        enterButton.focus = true;
    }

    function setToDefault() {
        mode = "Normal";
    }
}
