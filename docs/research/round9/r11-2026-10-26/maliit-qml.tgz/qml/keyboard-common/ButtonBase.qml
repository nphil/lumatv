/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import QtGraphicalEffects 1.0

import "commonvariables.js" as CV

Rectangle {
    id: btn     // id on the first line makes it easy to find an object

    // property declarations
    property alias text: txt.text
    property string audioText: ""
    property variant buttonStyle: style.button
    property alias fontSize: txt.font.pixelSize
    property alias fontSizeMode: txt.fontSizeMode
    property string fontfamily: ""
    property url image
    property int contentWidth: txt.contentWidth
    property int radius: buttonStyle.radius
    property bool removed: false
    property bool locked: false
    property bool allowRepeat: true
    property bool noBorder: false
    property int borderPosition: 0
    property bool disableShadow: false
    property bool focusAdjust: false
    property int enterPriority: executeBeforeRelease
    property var buttonColor: buttonStyle.normal.bgColor
    readonly property int executeBeforeRelease: 0
    readonly property int releaseBeforeExecute: 1

    z: btn.state == "Focus" ? 100 : 0
    // signal declarations
    signal pressed(int eventType)
    signal released(int eventType)
    signal clicked()
    signal entered()
    signal exited()
    signal executed()   // signal for Ok button of the Remote
    signal ttsService(string text)
    signal focusEnter()
    signal focusExit()

    property int currentEvent: CV.MouseEvent

    onFocusChanged: {
        if (focus) {
            if (audioText !== "") {
                btn.ttsService(audioText);
            } else {
                btn.ttsService(text);
            }
            focusEnter();
        } else {
            focusExit();
        }
    }

    Connections {
        target: PluginProxy
        onKeyReleased : {
            if (isReleased && (state === "Select"))
                state = "Focus";
        }
    }

    onReleased: {
        if (focus) btn.ttsService(qsTr("OK"));
    }

    // JavaScript functions
    onEnabledChanged: {
        // stop the timer
        starter.stop();
        ticker.stop();
    }

    Rectangle {
        anchors.fill: parent
        color: buttonStyle.bgMerge !== undefined? buttonStyle.bgMerge : "transparent"
        Rectangle {
            id: btnRec
            radius: noBorder? 0 : btn.radius
            color: buttonColor
            border.color: noBorder? "transparent" : buttonStyle.normal.borderColor
            border.width: noBorder? 0 : buttonStyle.normal.borderWidth
            anchors.fill: parent
            anchors.topMargin: (btn.borderPosition & 1<<3) > 0 ? 1 : 0
            anchors.bottomMargin: (btn.borderPosition & 1<<2) > 0 ? 1 : 0
            anchors.rightMargin: (btn.borderPosition & 1<<0) > 0 ? 1 : 0
            anchors.leftMargin: (btn.borderPosition & 1<<1) > 0 ? 1 : 0
        }
    }

    // object properties
    state: "Normal"

    Keys.onPressed: {
        if (event.key === Qt.Key_Execute) {
            btn.currentEvent = CV.KeyBoardEvent;
            if (enterPriority === releaseBeforeExecute) {
                btn.released(btn.currentEvent);
                btn.executed();
            } else {
                btn.executed();
                btn.state = "Select"
                btn.released(btn.currentEvent);
            }
            event.accepted = true;
        }
    }

    // child objects
    Image {
        id: img
        source: image
        smooth: true
        anchors.centerIn: btn
    }

    Text {
        id: txt
        anchors.fill: parent
        anchors.margins: buttonStyle.minimumMargin !== undefined ? buttonStyle.minimumMargin : 2
        anchors.bottomMargin: 2
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        fontSizeMode: Text.Fit
        font.family: fontfamily !== "" ? fontfamily : buttonStyle.fontFamily
        font.weight: buttonStyle.fontWeight ? buttonStyle.fontWeight : Font.Normal
        text: ""
        color: btn.state === "Disable" ? buttonStyle.disable.fgColor : buttonStyle.normal.fgColor
        font.pixelSize: buttonStyle.normal.fontSize
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true

        onReleased: {
            starter.stop();
            ticker.stop();

            if (!btn.focus) return;

            btn.currentEvent = CV.MouseEvent;
            if (enterPriority === releaseBeforeExecute) {
                btn.released(btn.currentEvent);
                btn.executed();
            } else {
                btn.executed();
                btn.released(btn.currentEvent);
            }

            if (removed) return;
            if (btn.state === "Disable") return;
            btn.focus = mouseArea.containsMouse;
            if (!btn.focus)
                btn.state = "Normal";
        }

        onPressed: {
            btn.currentEvent = CV.MouseEvent;
            btn.pressed(btn.currentEvent);
            if (allowRepeat)
                starter.restart();
            if (removed) return;
            if (btn.state === "Disable") return;
            btn.focus = mouseArea.containsMouse;
            if (!btn.focus)
                btn.state = "Normal";

            // Check and change the JP PlugIn "space"button image
            if (btn.text === " ") {
                btn.image =  style.getImage("space_bar");
            }
        }

        onEntered: {
            if (btn.state === "Disable") return;
            if (mouseArea.pressed) return;
            btn.focus = true;
            btn.entered();
        }

        onExited: {
            starter.stop();
            ticker.stop();

            if (btn.state === "Disable") return;
            btn.focus = false;
            btn.state = "Normal";
            btn.exited();
        }

        onClicked:{
            btn.clicked();
        }
    }

    MultiPointTouchArea {
        id: touchArea
        anchors.fill: parent
        mouseEnabled : false
        minimumTouchPoints: 1
        maximumTouchPoints: 1

        onPressed: {
            btn.currentEvent = CV.TouchEvent;
            btn.pressed(btn.currentEvent);
            if (allowRepeat)
                starter.restart();
            if (removed) return;
            if (btn.state === "Disable") return;
            btn.focus = true;
            if (!btn.focus)
                btn.state = "Normal";

            // Check and change the JP PlugIn "space"button image
            if (btn.text === " ") {
                btn.image =  style.getImage("space_bar");
            }
        }

        onReleased: {
            starter.stop();
            ticker.stop();

            if (!btn.focus) return;
            btn.currentEvent = CV.TouchEvent;
            btn.released(btn.currentEvent);
            btn.exited();
            if (removed) return;
            if (btn.state === "Disable") return;
            btn.focus = false;
            if (!btn.focus)
                btn.state = "Normal";
        }

        onUpdated: {
            if (touchPoints.length <= 0) {
                return;
            }

            if (btn.state === "Disable") {
                return;
            }

            const curX = touchPoints[0].x;
            const curY = touchPoints[0].y;
            if (curX < 0 || curY < 0 || curX > btn.width || curY > btn.height) {
                btn.focus = false;
                btn.state = "Normal";
                btn.exited();
            }
        }

    }

    function releaseButton() {
        if (btn.state === "Select") {
            starter.stop();
            ticker.stop();
            if (btn.state !== "Disable")
                btn.state = "Focus";
        }
    }

    Timer {
        id: starter
        interval: 500; running:false; repeat: false
        onTriggered: ticker.restart()
    }

    Timer {
        id: ticker
        interval: 160; running: false; repeat: true
        onTriggered: {
            if (btn.state !== "Select") {
                starter.stop();
                ticker.stop();
                return;
            }
            btn.released(btn.currentEvent);
        }
    }

    // states
    states: [
        State {
            name: ""; extend: "Enabled"
        },
        State {
            name: "Normal"; extend: "Enabled"
        },
        State {
            name: "Focus"; extend: "Enabled"
            when: btn.enabled && btn.focus && !mouseArea.pressed
            StateChangeScript {
                script: {
                    CV.savedFocusItem = btn;
                }
            }
        },
        State {
            name: "Select"; extend: "Enabled"
            when: btn.enabled && btn.focus && mouseArea.pressed
        },
        State {
            name: "Disable"; extend: "Disabled"
            PropertyChanges {
                target: btnRec
                color: noBorder ? buttonStyle.normal.bgColor : "transparent"
                border.color: noBorder ? "transparent" : buttonStyle.disable.borderColor
                border.width: noBorder ? 0 : buttonStyle.disable.borderWidth
                focus: false
            }
            PropertyChanges {
                target: txt
                color: buttonStyle.disable.fgColor
                font.pixelSize: buttonStyle.disable.fontSize
            }
        },
        State { name: "Enabled"; PropertyChanges { target: btn; enabled: true; } },
        State { name: "Disabled"; PropertyChanges { target: btn; enabled: false; } }
    ]
    // transitions
    Connections {
        target: PluginProxy
        onTranslatorChanged: {
            if( state === "Focus") {
                // For refresh focusRect, Text need to be updated in focusRect by focusing
                state = "";
                state = "Focus";
            }
        }
    }
}
