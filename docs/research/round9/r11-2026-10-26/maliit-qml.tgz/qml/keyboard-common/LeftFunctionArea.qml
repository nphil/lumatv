/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

import "commonvariables.js" as CommonVariables

Rectangle {
    id: root
    color: 'transparent'
    property variant buttonStyle: style.panelButton
    property string currLanguage: "English"
    property string languageLabel: "ENG"
    property bool supportShiftMode: true
    property bool supportExpandMode: false
    property bool supportExpandShiftMode: false
    property bool supportPageButton: false
    property bool activateLanguageButton: false
    property int rowIndex: 0
    property bool predictModeCheck: false

    signal ttsService(string text)
    signal clickLanguageButton()
    signal meetLeftBoundary(int row)
    signal meetRightBoundary(int row)
    signal meetTopBoundary(int column)
    signal meetBottomBoundary(int column)
    signal focusItem(var item, int x, int y)
    signal focusImage(url img)
    signal focusDot(var color)
    signal focusOut()
    signal predictState(var tempState)

    function setFocusIn(item) {
        root.focusItem(item, item.x + style.left.leftMargin, item.y + style.left.topMargin);
    }

    function setToDefault() {
        shiftButton.locked = false;
        if (shiftButton.state === "Disable")
            return;
        else if (shiftButton.focus)
            shiftButton.state = "Focus"
        else
            shiftButton.state = "Normal";
    }

    function setKeyNavigation(row) {
        if (row === 0 && languageChangeButton.state !== "Disable")
            languageChangeButton.focus = true;
        else if (row === 0 && languageChangeButton.state === "Disable")
            symbolButton.focus = true;
        else if (row === 1)
            symbolButton.focus = true;
        else if (row === 2 && accentButton.state !== "Disable")
            accentButton.focus = true;
        else if (row === 2 && accentButton.state === "Disable")
            symbolButton.focus = true;
        else if (row === 3 && shiftButton.state !== "Disable")
            shiftButton.focus = true;
        else if (row === 3 && shiftButton.state === "Disable" && accentButton.state !== "Disable")
            accentButton.focus = true;
        else if (row === 3 && shiftButton.state === "Disable" && accentButton.state === "Disable")
            symbolButton.focus = true;
    }

    state: "Normal"
    onStateChanged: {
        if ((state === "Expand" && !supportExpandShiftMode) || (state === "Symbol")) shiftButton.state = "Disable";
        else if (supportShiftMode && shiftButton.focus) shiftButton.state = "Focus";
        else if (supportShiftMode && !shiftButton.focus) shiftButton.state = "Normal";
    }
    onSupportExpandModeChanged: accentButton.state = supportExpandMode ? "Normal" : "Disable"
    onSupportShiftModeChanged: shiftButton.state = supportShiftMode ? "Normal" : "Disable"

    Keys.onPressed: {
        if (event.key === Qt.Key_Up) {
            meetTopBoundary(0);
            event.accepted = true;
        } else if (event.key === Qt.Key_Down) {
            meetBottomBoundary(-1); //focus to the first column of the bottom region
            event.accepted = true;
        } else if (event.key === Qt.Key_Left) {
            meetLeftBoundary(rowIndex);
            event.accepted = true;
        } else if (event.key === Qt.Key_Right) {
            meetRightBoundary(rowIndex);
            event.accepted = true;
        }
    }

    Column {
        id: leftColumn
        objectName: "leftColumn"
        spacing: style.left.cellSpace
        property bool activateLanguageButton : root.activateLanguageButton
        onActivateLanguageButtonChanged: {
            languageChangeButton.state = activateLanguageButton ? "Normal" : "Disable";
        }
        /* Language Button */
        ButtonBase {
            id: languageChangeButton
            state: activateLanguageButton ? "Normal" : "Disable"
            objectName: "languageChangeButton"
            property string ttsString: qsTr("Change Language") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            property int row: 0

            buttonStyle: root.buttonStyle
            text: (languageLabel !== undefined && languageLabel !== "") ? languageLabel : currLanguage
            width: root.width
            height: style.left.cellHeight
            fontSizeMode: Text.Fit
            allowRepeat: false

            onStateChanged: {
                switch(state) {
                    case "Focus":
                        rowIndex = row;
                    case "Select":
                        root.setFocusIn(languageChangeButton);
                        break;
                    default:
                        break;
                }
            }
            onExited: root.focusOut()

            onClicked: { //For Handling Cursor+Key Events
                shiftButton.state = "Normal";
                clickLanguageButton();
            }

            Keys.onReleased: { //For Handling Key Events
                shiftButton.state = "Normal";
                clickLanguageButton();
            }

            onTtsService: root.ttsService(text);
            audioText: ttsString + " " + globalStringModel.getStringLangCode(langCode)

            KeyNavigation.down: symbolButton
        }

        /* Symbol Button */
        ButtonBase {
            id: symbolButton
            objectName: "symbolButton"
            buttonStyle: root.buttonStyle

            property int row: 1
            property string ttsStringSymbol: qsTr("Text to Symbols") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            property string ttsStringText: qsTr("Symbols to Text") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")

            text: (root.state === "Symbol") ? ((currLanguage === "English") ? "ABC" : qsTr("ABC")) + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                                            : "$%^"
            fontfamily: buttonStyle.defaultFontFamily
            width: root.width
            height: style.left.cellHeight
            allowRepeat: false
            onReleased: {
                if(predictModeCheck){
                    root.predictState(root.state);
                    return;
                }
                switch (root.state) {
                case "Normal":
                case "Normal-Shift":
                case "Normal-Shift-Lock":
                case "Expand":
                case "Expand-Shift":
                case "Expand-Shift-Lock":
                    root.state = "Symbol";
                    break;
                case "Symbol":
                    root.state = "Normal";
                    break;
                default:
                    break;
                }
                shiftButton.locked = false;
                if (focus && root.state === "Normal" || root.state === "Expand" || root.state === "Normal-Shift" || root.state === "Normal-Shift-Lock")
                    root.ttsService(ttsStringSymbol)
                else if (focus && root.state === "Symbol")
                    root.ttsService(ttsStringText)
            }

            onTtsService: {
                if (root.state === "Normal" || root.state === "Expand" || root.state === "Normal-Shift" || root.state === "Normal-Shift-Lock")
                    root.ttsService(ttsStringSymbol)
                else if (root.state === "Symbol")
                    root.ttsService(ttsStringText)
            }
            onStateChanged: {
                switch(state) {
                    case "Focus":
                        rowIndex = row;
                    case "Select":
                        root.setFocusIn(symbolButton);
                        break;
                    default:
                        break;
                }
            }
            onExited: root.focusOut()
            KeyNavigation.up: languageChangeButton
            Keys.onPressed: {
                if (event.key === Qt.Key_Down) {
                    if (accentButton.state === "Disable") {
                        if (shiftButton.state === "Disable") {
                            meetBottomBoundary(-1);
                        } else {
                            shiftButton.focus = true;
                        }
                    } else {
                        accentButton.focus = true;
                    }
                    event.accepted = true;
                }
            }
        }

        /* Accent Button */
        DotButton {
            id: accentButton
            objectName: "accentButton"
            buttonStyle: root.buttonStyle

            property int row: 2
            property string ttsStringUmlautOn: qsTr("Umlaut on") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            property string ttsStringUmlautOff: qsTr("Umlaut off") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")

            text: (root.state === "Expand" || root.state === "Expand-Shift" || root.state === "Expand-Shift-Lock") ? "ABC" : "Àà"
            width: root.width
            height: style.left.cellHeight
            state: supportExpandMode ? "Normal" : "Disable"
            allowRepeat: false

            dotColor: {
                switch (root.state) {
                    case "Expand":
                        return style.shiftButton.shiftColor;
                    default:
                        return style.shiftButton.normalColor;
                }
            }

            onReleased: {
                switch (root.state) {
                case "Normal":
                case "Normal-Shift":
                case "Normal-Shift-Lock":
                    if (supportExpandMode)
                        root.state = "Expand";
                    break;
                case "Expand":
                case "Expand-Shift":
                case "Expand-Shift-Lock":
                    root.state = "Normal";
                    break;
                case "Symbol":
                    if (supportExpandMode)
                        root.state = "Expand";
                    break;
                default:
                    break;
                }
                shiftButton.locked = false;
                if (focus && root.state === "Symbol" || root.state === "Normal" || root.state === "Normal-Shift" || root.state === "Normal-Shift-Lock")
                    root.ttsService(ttsStringUmlautOn)
                else if (focus && root.state === "Expand")
                    root.ttsService(ttsStringUmlautOff)
            }
            onTtsService: {
                if (root.state === "Symbol" || root.state === "Normal" || root.state === "Normal-Shift" || root.state === "Normal-Shift-Lock")
                    root.ttsService(ttsStringUmlautOn)
                else if (root.state === "Expand")
                    root.ttsService(ttsStringUmlautOff)
            }
            onStateChanged: {
                switch(state) {
                    case "Focus":
                        rowIndex = row;
                    case "Select":
                        root.setFocusIn(accentButton);
                        if (root.state === "Expand")
                            root.focusDot(style.shiftButton.shiftColor);
                        else
                            root.focusDot(style.shiftButton.normalColor);
                        break;
                    default:
                        break;
                }
            }
            onExited: root.focusOut()
            KeyNavigation.up: symbolButton

            Keys.onPressed: {
                if (event.key === Qt.Key_Down) {
                    if (shiftButton.state == "Disable") {
                        meetBottomBoundary(-1);
                    } else {
                        shiftButton.focus = true;
                    }
                    event.accepted = true;
                }
            }
        }

        /* Shift Button */
        DotButton {
            id: shiftButton
            objectName: "shiftButton"
            buttonStyle: root.buttonStyle
            property int row: 3

            property url iconOn:  style.getImage("shift_on")
            property url iconLockOn:  style.getImage("shift_keep_on")
            property url iconOff: style.getImage("shift_off")
            property url iconOn_f:  style.getImage("shift_on_f")
            property url iconLockOn_f:  style.getImage("shift_keep_on_f")
            property url iconOff_f: style.getImage("shift_off_f")

            property string ttsStringCaps: qsTr("Caps") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            property string ttsStringCapsLock: qsTr("Caps Lock") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            property string ttsStringOff: qsTr("off") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            property string ttsStringLowerCase: qsTr("Lower case") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")

            dotColor: {
                switch (root.state) {
                    case "Normal-Shift":
                    case "Normal-Shift-Lock":
                    case "Expand-Shift":
                    case "Expand-Shift-Lock":
                        return style.shiftButton.shiftColor;
                    default:
                        return style.shiftButton.normalColor;
                }
            }

            image : {
                if (supportPageButton)
                    return "";

                var icon = iconOff;
                switch (state) {
                case "":
                case "Normal":
                    if (root.state === "Normal-Shift" || root.state === "Expand-Shift") {
                        icon = iconOn;
                    } else if (root.state === "Normal-Shift-Lock" || root.state === "Expand-Shift-Lock") {
                        icon = iconLockOn;
                    }
                    break;
                case "Disable":
                    icon = "";
                    break;
                default:
                    icon = iconOff;
                }
                return icon;
            }

            text: (!supportPageButton) ? "" : ((root.state === "Normal-Shift") ? "2/2" : "1/2")
            width: root.width
            height: style.left.cellHeight
            allowRepeat: false
            onTextChanged: {
                if( state === "Focus") {
                    // For refresh focus
                    shiftButton.state = ""
                    shiftButton.state = "Focus"
                }
            }
            onReleased: {
                if (!supportShiftMode)
                    return;

                switch (root.state) {
                case "Normal":
                    root.state = "Normal-Shift";
                    break;
                case "Normal-Shift":
                    if (supportPageButton) {
                        root.state = "Normal";
                    }
                    else {
                        root.state = "Normal-Shift-Lock";
                        shiftButton.locked = true;
                    }
                    break;
                case "Normal-Shift-Lock":
                    root.state = "Normal";
                    shiftButton.locked = false;
                    break;
                case "Expand":
                    if (supportExpandShiftMode)
                        root.state = "Expand-Shift";
                    break;
                case "Expand-Shift":
                    root.state = "Expand-Shift-Lock";
                    shiftButton.locked = true;
                    break;
                case "Expand-Shift-Lock":
                    root.state = "Expand";
                    shiftButton.locked = false;
                    break;
                case "Symbol":
                default:
                    break;
                }
                if (focus && root.state === "Normal")
                    root.ttsService(ttsStringCaps)
                else if (focus && root.state === "Normal-Shift")
                    root.ttsService(ttsStringCapsLock)
                else if (focus && root.state === "Normal-Shift-Lock")
                    root.ttsService(ttsStringCapsLock + " " + ttsStringOff)
            }
            onTtsService: {
                if (root.state === "Normal")
                    root.ttsService(ttsStringCaps)
                else if (root.state === "Normal-Shift")
                    root.ttsService(ttsStringCapsLock)
                else if (root.state === "Normal-Shift-Lock")
                    root.ttsService(ttsStringCapsLock + " " + ttsStringOff)
            }
            onStateChanged: {
                switch(state) {
                    case "Focus":
                        rowIndex = row;
                    case "Select":
                        root.setFocusIn(shiftButton);
                        if (root.state === "Normal-Shift" || root.state === "Expand-Shift"){
                            root.focusDot(style.shiftButton.shiftColor);
                            if (!supportPageButton) root.focusImage(iconOn_f);
                        } else if (root.state === "Normal-Shift-Lock" || root.state === "Expand-Shift-Lock") {
                            root.focusDot(style.shiftButton.shiftColor);
                            if (!supportPageButton) root.focusImage(iconLockOn_f);
                        } else {
                            if (!supportPageButton) root.focusImage(iconOff_f);
                            root.focusDot(style.shiftButton.normalColor);
                        }
                        break;
                    default:
                        break;
                }
            }
            onExited:root.focusOut()
            KeyNavigation.up: (accentButton.state !== "Disable") ? accentButton : symbolButton
        }
    }

    states: [
        State { name: "Normal"; StateChangeScript { script: setToDefault() } },
        State { name: "Normal-Shift" },
        State { name: "Normal-Shift-Lock" },
        State { name: "Expand" },
        State { name: "Expand-Shift" },
        State { name: "Expand-Shift-Lock" },
        State { name: "Symbol" }
    ]

    Connections {
        target: PluginProxy
        onKeyReleased : {
            if (isReleased && (languageChangeButton.state === "Select"))
                languageChangeButton.state = "Focus";
            else if (isReleased && (symbolButton.state === "Select"))
                symbolButton.state = "Focus";
            else if (isReleased && (accentButton.state === "Select"))
                accentButton.state = "Focus";
            else if (isReleased && (shiftButton.state === "Select"))
                shiftButton.state = "Focus";
        }
    }
}
