/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

ButtonBase {
    id: numberButton
    objectName: "numberButton"
    property string mainChar
    property string symbolChar
    signal textKeyPressed(string text)

    buttonStyle: style.numberButton
    text: getCurrentText()

    onReleased: {
        textKeyPressed(text);
    }

    function getCurrentText() {
        var t;

        switch (numberKeyboard.mode) {
        case "Normal":
            t = mainChar;
            break;
        case "Symbol":
            t = symbolChar;
            break;
        default:
            t = "";
        }

        return (t !== undefined) ? t : "";
    }

    Connections {
        target: PluginProxy
        onKeyReleased : {
            if (isReleased && (numberButton.state === "Select"))
                numberButton.state = "Focus";
        }
    }
}
