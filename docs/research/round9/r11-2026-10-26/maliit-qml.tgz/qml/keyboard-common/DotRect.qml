/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import QtGraphicalEffects 1.0

Rectangle {
    id: dotRect
    width: style.shiftButton.dotWidth
    height: style.shiftButton.dotHeight
    color: "transparent"

    property color circleColor: style.shiftButton.normalColor

    onCircleColorChanged: {
        dot.requestPaint();
    }

    Canvas {
        id: dot
        anchors.fill: parent
        property var ctx
        onAvailableChanged: if (available) ctx = getContext('2d');
        onPaint: {
            if (!ctx) return;
            ctx.clearRect(0, 0, dotRect.width, dotRect.height);
            var centreX = dotRect.width / 2;
            var centreY = dotRect.height / 2;
            ctx.beginPath();
            ctx.fillStyle = dotRect.circleColor;
            ctx.moveTo(centreX, centreY);
            ctx.arc(centreX, centreY, dotRect.width / 4, 0, Math.PI*2, false);
            ctx.lineTo(centreX, centreY);
            ctx.fill();
        }
    }
}

