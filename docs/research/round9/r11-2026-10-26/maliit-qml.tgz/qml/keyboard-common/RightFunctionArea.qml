/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "commonvariables.js" as CommonVariables
import com.meego.maliit 1.0

Rectangle {
    id: root
    color: 'transparent'
    property var mode: "Normal"
    property variant buttonStyle: style.panelButton
    property alias enterText: enterButton.text
    property bool enableVoiceButton: true
    property bool inputMax: PluginProxy.inputMax
    property int middleWidth: style.middle.width
    property int xOffset: style.left.leftMargin + style.left.width + style.middle.leftMargin + middleWidth + style.right.leftMargin
    property int yOffset: style.right.topMargin

    property bool enableNav: false
    signal ttsService(string text)
    signal clickClearAllButton()
    signal clickVoiceButton()
    signal sendKey(int keycode, bool shift, int eventType)
    signal meetLeftBoundary(int row)
    signal meetRightBoundary(int row)
    signal meetTopBoundary(int column)
    signal meetBottomBoundary(int column)
    signal focusItem(var item, int x, int y)
    signal focusImage(url img)
    signal focusOut()

    function setFocusIn(item) {
        root.focusItem(item, item.x + root.xOffset, item.y + root.yOffset);
    }

    function updateRightColumnLayout() {
        navRow.forceLayout();
        rightColumn.forceLayout();
    }

    onEnableVoiceButtonChanged: {
        if (!enableVoiceButton) {
            voiceButton.state = "Disable";
        } else {
            voiceButton.state = "Normal";
            voiceButton.visible = true;
        }
    }

    Column {
        id: rightColumn
        objectName: "rightColumn"
        spacing: style.right.cellSpace
        /* Delete Button */
        RightButtonBase {
            id: deleteButton
            objectName: "deleteButton"
            buttonStyle: root.buttonStyle
            image: style.getImage("clear")
            width: root.width
            height: style.right.cellHeight
            audioText: qsTr("Back Space") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            onTtsService: root.ttsService(text)
            onReleased: sendKey(14, false, eventType)

            property int row: 0
            KeyNavigation.down: enterButton

            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(deleteButton);
                        root.focusImage(style.getImage("clear_f"))
                        break;
                    default:
                        break;
                }
            }
            onExited:root.focusOut()
        }

        /* Enter Button */
        RightButtonBase {
            id: enterButton
            property string searchStr: qsTr("Search") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "") //i18n This string is a naun for a button on VKB. It means "searching an word user writes using the keyboard".
            property string enterStr: qsTr("Enter") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "");
            property int row: 1
            readonly property int initRow: 1

            objectName: "enterButton"
            buttonStyle: root.buttonStyle
            text: {
                switch (enterKeyType) {
                case Maliit.SearchEnterKeyType:
                    return searchStr
                default:
                    return enterStr
                }
            }
            fontSizeMode: Text.Fit
            buttonColor: "#248351"
            onTtsService: root.ttsService(text)
            onReleased: {
                pmLog.printNormalLog("NL_VKB_INPUT_METHOD", {"input_method" : "keyboard", "foreground_app": foregroundAppId});
                sendKey(28, false, eventType)
            }

            width: root.width
            height: style.right.cellHeight
            allowRepeat: false

            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(enterButton);
                        break;
                    default:
                        break;
                }
            }
            onExited:root.focusOut()
            KeyNavigation.up: deleteButton
            KeyNavigation.down: (voiceButton.state !== "Disable") ? voiceButton : clearAllButton
        }

        /* Voice button */
        RightButtonBase {
            id: voiceButton
            objectName: "voiceButton"
            buttonStyle: root.buttonStyle
            image: {
                if (voiceButton.state === "Disable") {
                    return ""
                } else {
                    return style.getImage("voice_mike");
                }
            }
            audioText: qsTr("Speech to text") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            fontSizeMode: Text.Fit
            onTtsService: root.ttsService(text)
            onReleased: {
                pmLog.printNormalLog("NL_VKB_INPUT_METHOD", {"input_method" : "voice", "foreground_app": foregroundAppId});
                clickVoiceButton()
            }

            width: root.width
            height: style.right.cellHeight

            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(voiceButton);
                        root.focusImage(style.getImage("voice_mike_f"))
                        break;
                    default:
                        break;
                }
            }
            onExited:root.focusOut()

            property int row: 2
            KeyNavigation.down: clearAllButton
            KeyNavigation.up: enterButton
        }

        /* Clear-All button */
        ButtonBase {
            id: clearAllButton
            objectName: "clearAllButton"
            buttonStyle: root.buttonStyle
            borderPosition: mode === "Hiragana" || mode === "Katakana" ? 4 : 0
            text: qsTr("Clear all") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            fontSizeMode: Text.Fit
            onTtsService: root.ttsService(text)
            onReleased: clickClearAllButton()
            width: root.width
            height: style.right.cellHeight
            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(clearAllButton);
                        break;
                    default:
                        break;
                }
            }
            onExited:root.focusOut()

            property int row: 3
            KeyNavigation.up: (voiceButton.state !== "Disable") ? voiceButton : enterButton
            Keys.onPressed: {
                if (event.key === Qt.Key_Down) {
                    if (root.enableNav) {
                        moveCursorLeftButton.focus = true;
                        event.accepted = true;
                    } else {
                        meetBottomBoundary(0);
                        event.accepted = true;
                    }
                }
            }
        }

        Row {
            id: navRow
            objectName: "navRow"
            width : root.width
            height: style.right.cellHeight
            spacing: style.bottom.navCellSpace
            visible: root.enableNav

            ButtonBase {
                id: moveCursorLeftButton
                objectName: "moveCursorLeftButton"
                buttonStyle: style.panelButton
                image: style.getImage("back")
                audioText: qsTr("Left") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                onTtsService: root.ttsService(text)
                height: style.bottom.height
                width: style.bottom.navBtnWidth
                fontSizeMode: Text.Fit
                property int row: 4

                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            root.focusItem(moveCursorLeftButton, moveCursorLeftButton.x + root.xOffset,
                                           moveCursorLeftButton.y + root.yOffset + style.right.height + style.right.cellSpace);
                            root.focusImage(style.getImage("back_f"));
                            break;
                        default:
                            break;
                    }
                }
                onExited: root.focusOut()
                onReleased: moveCursorPosition(CommonVariables.left,eventType);

                KeyNavigation.right: moveCursorRightButton
                KeyNavigation.up: clearAllButton
            }

            ButtonBase {
                id: moveCursorRightButton
                objectName: "moveCursorRightButton"
                buttonStyle: style.panelButton
                image: style.getImage("next")
                audioText : qsTr("Right") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                onTtsService: root.ttsService(text)
                height: style.bottom.height
                width: style.bottom.navBtnWidth
                fontSizeMode: Text.Fit
                property int row: 4

                onReleased: moveCursorPosition(CommonVariables.right,eventType)

                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            root.focusItem(moveCursorRightButton, moveCursorRightButton.x + root.xOffset,
                                           moveCursorRightButton.y + root.yOffset + style.right.height + style.right.cellSpace);
                            root.focusImage(style.getImage("next_f"));
                            break;
                        default:
                            break;
                    }
                }
                onExited: root.focusOut()

                KeyNavigation.left: moveCursorLeftButton
                KeyNavigation.up: clearAllButton
            }
        }
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Up) {
            meetTopBoundary(0);
            event.accepted = true;
        } else if (event.key === Qt.Key_Down) {
            meetBottomBoundary(0);
            event.accepted = true;
        } else if (event.key === Qt.Key_Left) {
            meetLeftBoundary(CommonVariables.savedFocusItem.row);
            enterButton.row = enterButton.initRow;
            event.accepted = true;
        } else if (event.key === Qt.Key_Right) {
            meetRightBoundary(CommonVariables.savedFocusItem.row);
            event.accepted = true;
        }
    }

    Connections {
        target: PluginProxy
        onKeyReleased : {
            if (isReleased && (deleteButton.state === "Select"))
                deleteButton.state = "Focus";
            else if (isReleased && (enterButton.state === "Select"))
                enterButton.state = "Focus";
            else if (isReleased && (voiceButton.state === "Select"))
                voiceButton.state = "Focus";
            else if (isReleased && (clearAllButton.state === "Select"))
                clearAllButton.state = "Focus";
        }
    }

    function setKeyNavigation(row, from) {
        if (row === 0) {
            deleteButton.focus = true;
        } else if (row === 1) {
            enterButton.focus = true;
            enterButton.row = row;
        } else if (row === 2) {
            if (voiceButton.state === "Disable") {
                enterButton.focus = true;
                enterButton.row = row;
            } else {
                voiceButton.focus = true;
            }
        } else if (row === 3 || row === -1) {
            clearAllButton.focus = true;
        } else if (row === 4 || row === -1) {
            moveCursorLeftButton.focus = true;
        }
    }

    function setFocusTo(name) {
        if (name === "Enter")
            enterButton.focus = true;
    }
}
