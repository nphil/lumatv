/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

import "commonvariables.js" as CommonVariables

Item {
    id: root
    objectName: "bottomArea"
    property variant preColumn: "defaultIndex"
    property int spaceBarWidth: style.bottom.spaceBarWidth
    signal ttsService(string text)
    signal sendKey(int keycode, bool shift, int eventType)
    signal meetLeftBoundary()
    signal meetRightBoundary()
    signal meetTopBoundary(variant column)
    signal meetBottomBoundary()
    signal focusIn(int x, int y, int h, int w, string txt, real op)
    signal focusItem(var item, int x, int y)
    signal focusOut()
    signal focusImage(url img)
    signal pressMore()
    signal pressBack()

    property bool showMoreButton
    property bool showBackButton

    property int xOffset: style.left.leftMargin
    property int yOffset: style.left.topMargin + style.middle.height + style.bottom.topMargin

    function setFocusIn(item) {
        root.focusItem(item, item.x + root.xOffset, item.y + root.yOffset);
    }

    function updateBottomLayout() {
        navButtons.forceLayout();
        row.forceLayout();
    }

    Row {
        id: row
        objectName: "bottomRow"
        spacing: style.bottom.cellSpace

        Rectangle {
            id:spacingButton
            color: "transparent"
            width: style.left.width
            height: style.bottom.height
            visible: !(showMoreButton || showBackButton)
        }

        /* More Button */
        ButtonBase {
            id: moreButton
            objectName: "moreButton"
            buttonStyle: style.panelButton

            property int row: 4
            property string ttsStringMore: qsTr("More") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            property string ttsStringBack: qsTr("Back") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")

            text: showBackButton ? ttsStringBack : ""
            image: showMoreButton ? style.getImage("more") : ""
            width: style.left.width
            height: style.left.cellHeight
            visible: showMoreButton || showBackButton
            onReleased:  {
                if (showMoreButton) {
                    pressMore();
                } else {
                    pressBack();
                }
            }

            audioText: {
                if (showMoreButton) {
                    return ttsStringMore
                } else {
                    return ttsStringBack
                }
            }
            onTtsService: root.ttsService(text)

            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(moreButton);
                        if (showMoreButton)
                            root.focusImage(style.getImage("more_f"))
                        else
                            root.focusImage("")
                        break;
                    default:
                        break;
                }
            }
            onExited:root.focusOut()

            KeyNavigation.left: moveCursorRightButton
            KeyNavigation.right: spaceButton

            Keys.onPressed: {
                if (event.key === Qt.Key_Up) {
                    meetTopBoundary(-1);
                    event.accepted = true;
                } else
                if (event.key === Qt.key_Down) {
                    meetBottomBoundary();
                    event.accepted = true;
                }
            }
        }

        // spaceBar
        ButtonBase {
            id: spaceButton
            objectName: "spaceButton"
            image: style.getImage("space_bar")
            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(spaceButton);
                        root.focusImage(style.getImage("space_bar_f"))
                        break;
                    default:
                        break;
                }
            }
            onExited: root.focusOut()
            onReleased: {
                sendKey(57, false, eventType);
            }
            onTtsService: root.ttsService(text)
            audioText: qsTr("Space") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")

            width: root.spaceBarWidth
            height: root.height

            KeyNavigation.left: moreButton.state !== "Disable" ? moreButton : meetLeftBoundary()
            KeyNavigation.right: moveCursorLeftButton

            Keys.onPressed: {
                if (event.key === Qt.Key_Up) {
                    meetTopBoundary(root.preColumn === -1? 0 : root.preColumn);
                    event.accepted = true;
                } else
                if (event.key === Qt.key_Down) {
                    meetBottomBoundary();
                    event.accepted = true;
                }
            }
        }

        Row {
            id: navButtons
            objectName: "navButtons"
            width : style.right.width
            height: style.bottom.height
            spacing: style.bottom.navCellSpace

            ButtonBase {
                id: moveCursorLeftButton
                objectName: "moveCursorLeftButton"
                buttonStyle: style.panelButton
                image: style.getImage("back")
                onTtsService: root.ttsService(text)
                audioText:qsTr("Left") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                height: style.bottom.height
                width: style.bottom.navBtnWidth
                fontSizeMode: Text.Fit

                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            root.focusItem(moveCursorLeftButton, style.left.leftMargin + spacingButton.width + spaceButton.width + (style.bottom.cellSpace * 2),
                                           moveCursorLeftButton.y + root.yOffset);
                            root.focusImage(style.getImage("back_f"));
                            break;
                        default:
                            break;
                    }
                }
                onExited: root.focusOut()
                onReleased: {
                    moveCursorPosition(CommonVariables.left,eventType);
                }

                KeyNavigation.left: spaceButton
                KeyNavigation.right: moveCursorRightButton
                Keys.onPressed: {
                    if (event.key === Qt.Key_Up) {
                        meetTopBoundary(-2);
                        event.accepted = true;
                    } else
                    if (event.key === Qt.Key_Down) {
                        meetBottomBoundary();
                        event.accepted = true;
                    }
                }
            }

            RightButtonBase {
                id: moveCursorRightButton
                objectName: "moveCursorRightButton"
                buttonStyle: style.panelButton
                image: style.getImage("next")
                onTtsService: root.ttsService(text)
                audioText:qsTr("Right") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                height: style.bottom.height
                width: style.bottom.navBtnWidth
                fontSizeMode: Text.Fit
                onReleased: moveCursorPosition(CommonVariables.right,eventType)
                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            root.focusItem(moveCursorRightButton, style.left.leftMargin + spacingButton.width + spaceButton.width + (style.bottom.cellSpace * 2) + style.bottom.navBtnWidth + style.bottom.navCellSpace,
                                           moveCursorRightButton.y + root.yOffset);
                            root.focusImage(style.getImage("next_f"));
                            break;
                        default:
                            break;
                    }
                }
                onExited: root.focusOut()

                KeyNavigation.left: moveCursorLeftButton
                KeyNavigation.right: moreButton.state !== "Disable" ? moreButton : spaceButton
                Keys.onPressed: {
                    if (event.key === Qt.Key_Up) {
                        meetTopBoundary(-2);
                        event.accepted = true;
                    } else
                    if (event.key === Qt.Key_Down) {
                        meetBottomBoundary();
                        event.accepted = true;
                    }
                }
            }
        }
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Down) {
            meetBottomBoundary();
            event.accepted = true;
        }
    }

    function setKeyNavigation(column) {
        if (column === -1 && moreButton.visible) {
            moreButton.focus = true;
            root.preColumn = 0;
        }
        else if (column === -2) {
            moveCursorLeftButton.focus = true;
            root.preColumn = 0;
        } else {
            spaceButton.focus = true;
            root.preColumn = column
        }
    }
}
