/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

Rectangle {
    id: root
    objectName: "predictionArea"
    property variant preColumn: "defaultIndex"
    property variant words
    property bool noWords: words == undefined || words.length <=0
    property var buttonStyle: style.predictPanel.panelButton
    property int maxLength: 6
    property int buttonWidth
    property int buttonHeight
    property bool constantPrediction: false
    property bool predictMode: false
    property bool showNextButton
    property bool showPreviousButton: false
    property string pageTxt;
    property int xOffset: predictionBar.x
    property int xOffsetPageCount: pageCount.x

    signal ttsService(string text)
    signal sendKey(int keycode, bool shift, int eventType)
    signal selectPrediction(int index, string word)

    signal focusIn(int x, int y, int h, int w, string txt, real op) //TODO - need to remove this call

    signal focusItem(var item, int x, int y)
    signal focusOut()
    signal pressNext()
    signal pressPrev()
    signal meetLeftBoundary()
    signal meetRightBoundary()
    signal meetTopBoundary()
    signal meetBottomBoundary()

    color: style.predictPanel.bgColor
    opacity: style.predictPanel.opacity
    radius: style.predictPanel.radius

    onShowPreviousButtonChanged: leftBtn.state = showPreviousButton? "Normal" : "Disable"
    onShowNextButtonChanged: rightBtn.state = showNextButton? "Normal" : "Disable"

    function getMiddleItem() {
        return predictionRepeater.itemAt(words.length/2);
    }

    function updatePredictLayout() {
        pageCount.forceLayout();
        predictionBar.forceLayout();
    }

    function setKeyNavigation(column) {
        if (predictionMode) {
            if (leftBtn.state !== "Disable") leftBtn.focus = true;
            else
            if (rightBtn.state !== "Disable") rightBtn.focus = true;
        } else {
            if (column === 1) {
                predictionRepeater.itemAt(0).focus = true;
            } else
            if (column === 2) {
                predictionRepeater.itemAt(words.length/2).focus = true;
            } else
            if (column === 3) {
                predictionRepeater.itemAt(words.length-1).focus = true;
            }
        }
    }

    Row {
        id: pageCount
        objectName: "pageCount"
        visible: predictionMode
        spacing: style.predictPanel.cellSpace
        anchors.horizontalCenter: root.horizontalCenter
        anchors.verticalCenter : root.verticalCenter
        ButtonBase {
            id: leftBtn
            objectName: "leftBtn"
            width: style.predictPanel.leftBtn.width
            height: style.predictPanel.leftBtn.height
            buttonStyle: style.pageCountButton
            text: "<"
            state: "Disable"
            noBorder:true
            onReleased: pressPrev()
            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.focusItem(leftBtn, leftBtn.x + ((root.width - pageCount.width)/2),
                                       leftBtn.y - root.height + root.buttonStyle.focusOffset);
                        break;
                    default:
                        break;
                }
            }
            property string ttsStringNextlist: qsTr("Previous") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            onTtsService: root.ttsService(ttsStringNextlist)
            onExited: root.focusOut()
            KeyNavigation.right: rightBtn
            Keys.onPressed: {
                if (event.key === Qt.Key_Down) {
                    meetBottomBoundary();
                    event.accepted = true;
                }
            }
       }
       Text {
            id: txt
            objectName: "txt"
            height: 63
            width: contentWidth
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            font.family: fontfamily !== "" ? fontfamily : root.buttonStyle.fontFamily
            font.weight: root.buttonStyle.fontWeight ? root.buttonStyle.fontWeight : Font.Normal
            text: root.pageTxt
            color: root.buttonStyle.normal.fgColor
            font.pixelSize: root.buttonStyle.normal.fontSize
       }
       ButtonBase {
            id: rightBtn
            objectName: "rightBtn"
            width: style.predictPanel.rightBtn.width
            height: style.predictPanel.rightBtn.height
            buttonStyle: style.pageCountButton
            text: ">"
            state: "Disable"
            noBorder:true
            onReleased: pressNext()
            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.focusItem(rightBtn, rightBtn.x + ((root.width - pageCount.width)/2),
                                       rightBtn.y - root.height + root.buttonStyle.focusOffset);
                        break;
                    default:
                        break;
                }
            }
            property string ttsStringNextlist: qsTr("Next") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
            onTtsService: root.ttsService(ttsStringNextlist)
            onExited: root.focusOut()
            KeyNavigation.left: leftBtn
            Keys.onPressed: {
                if (event.key === Qt.Key_Down) {
                    meetBottomBoundary();
                    event.accepted = true;
                }
            }
        }
    }

    // prediction words
    Row {
        id: predictionBar
        objectName: "predictionBar"
        visible: !predictionMode
        property int predictionIndex: -1
        spacing: style.predictPanel.cellSpace
        anchors.horizontalCenter: root.horizontalCenter
        anchors.verticalCenter : root.verticalCenter
        Repeater {
            id: predictionRepeater
            objectName: "predictionRepeater"
            model: words
            ButtonBase {
                buttonStyle: root.buttonStyle
                borderPosition: 1
                text: modelData
                fontSizeMode: Text.Fit
                disableShadow: true
                height: root.buttonHeight
                width: {
                    if (constantPrediction) {
                        return root.buttonWidth;
                    } else {
                        return (contentWidth + style.predictPanel.minMargin) < style.predictPanel.constWidth?
                               style.predictPanel.constWidth: contentWidth + style.predictPanel.minMargin;
                    }
                }
                fontfamily: root.buttonStyle.fontFamily
                onReleased: selectPrediction(index,text)
                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            root.focusItem(predictionRepeater.itemAt(index),
                                   predictionRepeater.itemAt(index).x + ((root.width - predictionBar.width)/2),
                                   predictionRepeater.itemAt(index).y - root.height + buttonStyle.focusOffset);
                            break;
                        default:
                            break;
                    }
                }
                onTtsService: {
                    var audioString = text;
                    switch (audioString) {
                        case "http://":
                            audioString = qsTr("http colon slash slash") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                            break;
                        case "https://":
                            audioString = qsTr("https colon slash slash") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                            break;
                        case "www.":
                            audioString = qsTr("www dot") + (PluginProxy.emptyString !== undefined ? PluginProxy.emptyString : "")
                            break;
                        case ".org":
                            audioString = ". o r g"
                            break;
                        default:
                            break;
                    }
                    root.ttsService(audioString)
                }
                onExited: root.focusOut()
                KeyNavigation.right: predictionRepeater.itemAt(index + 1)
                KeyNavigation.left: predictionRepeater.itemAt(index - 1)
                Keys.onPressed: {
                    if (event.key === Qt.Key_Down) {
                        meetBottomBoundary();
                        event.accepted = true;
                    }
                }
            }
            onItemRemoved: item.removed = true
        }
    }
}
