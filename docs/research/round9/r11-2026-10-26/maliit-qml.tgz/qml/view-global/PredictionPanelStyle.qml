/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

QtObject {
    id: root
    property int resolution
    property int height:     180 / resolution
    property color bgColor: "#42484E"
    property real opacity: 1.0
    property int radius:      24 / resolution
    property int constWidth: 402 / resolution
    property int minMargin:   40 / resolution
    property int cellSpace:   12 / resolution
    property int topMargin:   26 / resolution
    property int leftMargin:  26 / resolution
    property int cellWidth:  228 / resolution
    property int cellHeight:  70 / resolution
    property int fontSize:    38 / resolution

    property string defaultFontFamily: "LG Smart UI"

    property var panelButton: PredictionPanelButtonStyle {resolution: root.resolution}

    property var moreButton:  MoreButtonStyle {resolution: root.resolution}
}

