/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

var symbolSet10x4 = [
            "!", "@", "#", "$", "%", "^", "&", "*", "(", ")",
            "-", "_", "=", "+", "\\", "|", "[", "]", "{", "}",
            ";", ":", "'", '"', ",", ".", "<", ">", "/", "?",
            "₩", "€", "£", "¥", "§", "¿", "`", "~", "", ""
];  //10*4

var symbolSet12x4 = [
            "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "`", "~",
            "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "§", "¿",
            "-", "_", "=", "+", "\\", "|", "[", "]", "{", "}", "₩", "€",
            ";", ":", "'", '"', ",", ".", "<", ">", "/", "?", "£", "¥"
]; //12*4
