/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import QtGraphicalEffects 1.0

Rectangle {
    id: root
    objectName: "hidPredictionItem"
    property QtObject buttonStyle: style.hidPredItem
    property alias wordWidth: word.contentWidth
    property alias wordText: word.text
    property alias hotKeyText: hotkey.text
    property alias fontSize: word.font.pixelSize
    property bool removed: false
    property int borderPosition: 1
    color: style.bgColor
    property int radius: buttonStyle.radius

    signal pressed()
    signal released()
    signal entered()
    signal exited()

    Rectangle {
        id: btnRec
        color: root.state === "Disable" ? buttonStyle.disable.bgColor : buttonStyle.normal.bgColor
        radius: root.radius
        anchors.fill: parent
        anchors.topMargin: (root.borderPosition & 1<<3) > 0 ? 1 : 0
        anchors.bottomMargin: (root.borderPosition & 1<<2) > 0 ? 1 : 0
        anchors.rightMargin: (root.borderPosition & 1<<0) > 0 ? 1 : 0
        anchors.leftMargin: (root.borderPosition & 1<<1) > 0 ? 1 : 0
        border.color: root.state == "Disable" ? buttonStyle.disable.bgColor : buttonStyle.normal.borderColor
        border.width: root.state == "Disable" ? 0 : buttonStyle.normal.borderWidth
    }

    Text {
        id: hotkey
        objectName: "hotkey"
        visible: root.state !== "Disable"
        anchors.top: parent.top
        anchors.right: parent.right
        anchors.rightMargin: buttonStyle.hotKey.rightMargin
        height: buttonStyle.hotKey.height
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment:   Text.AlignTop
        font.family:    buttonStyle.fontFamily
        font.pixelSize: buttonStyle.hotKey.fontSize
        color: buttonStyle.hotKey.fgColor
    }

    Text {
        id: word
        objectName: "word"
        height: buttonStyle.wordHeight
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment:   Text.AlignBottom
        font.family:    buttonStyle.fontFamily
        font.pixelSize: buttonStyle.normal.fontSize
        elide: Text.ElideRight
        color: buttonStyle.normal.fgColor
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent

        hoverEnabled: true
        onReleased: {
            if (!root.focus) return;
            root.released();
            if (removed) return;
            if (root.state === "Disable") return;
            root.focus = mouseArea.containsMouse;
            if (!root.focus)
                root.state = "Normal";
        }
        onPressed: {
            root.pressed();
            if (removed) return;
            if (root.state === "Disable") return;
            root.focus = mouseArea.containsMouse;
            if (!root.focus)
                root.state = "Normal";
        }
        onEntered: {
            if (root.state === "Disable") return;
            if (mouseArea.pressed) return;
            root.focus = true;
            root.entered();
        }
        onExited: {
            if (root.state === "Disable") return;
            root.focus = false;
            root.state = "Normal";
            root.exited();
        }
    }

    state: "Normal"
    states: [
        State {
            name: ""; extend: "Enabled"
        },
        State {
            name: "Normal"; extend: "Enabled"
        },
        State {
            name: "Focus"; extend: "Enabled"
            when: root.enabled && root.focus && !mouseArea.pressed
        },
        State {
            name: "Select"; extend: "Enabled"
            when: root.enabled && root.focus && mouseArea.pressed
        },
        State {
            name: "Disable"; extend: "Disabled"
            PropertyChanges {
                target: btnRec
                focus: false
            }
        },
        State { name: "Enabled";  PropertyChanges { target: root; enabled: true  } },
        State { name: "Disabled"; PropertyChanges { target: root; enabled: false } }
    ]
}
