/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import com.meego.maliit 1.0

import "../keyboard-common"
import "../keyboard-common/commonvariables.js" as CommonVariables
import "variables.js" as Variables

Rectangle {
    id: root
    objectName: "normalKeyboard"
    color: style.bgColor
    opacity: style.opacity
    radius: style.radius

    property alias mode: leftFunctionArea.state
    property alias currLanguage: leftFunctionArea.currLanguage
    property alias languageLabel: leftFunctionArea.languageLabel
    property alias supportShiftMode: leftFunctionArea.supportShiftMode
    property alias supportExpandMode: leftFunctionArea.supportExpandMode
    property alias supportExpandShiftMode: leftFunctionArea.supportExpandShiftMode
    property alias predictionIndex: middleLayoutArea.predictionIndex
    property alias predictionMode: middleLayoutArea.predictionMode
    property alias middleWidth: middleLayoutArea.width
    property alias supportPageButton: leftFunctionArea.supportPageButton
    property alias noWords: predictionArea.noWords
    property int contentType: PluginProxy.contentType
    property int enterKeyType: 0
    property alias enableVoiceButton: rightFunctionArea.enableVoiceButton
    property bool showScreenKeyboard: true
    property bool activateLanguageButton : false
    property string predictModeState: ""

    signal ttsService(string text)
    signal keyPressed(string rawcode, bool shift, int eventType)
    signal keysymPressed(string keysym, int eventType)
    signal textKeyPressed(string text)
    signal changeLanguage()
    signal activateSTT()
    signal clearAllPressed()
    signal meetTopBoundary()
    signal meetBottomBoundary()
    signal orientationChanged(string orientation)

    onFocusChanged: if (focus)  CommonVariables.savedFocusItem = middleLayoutArea.getMiddleItem()

    onOrientationChanged: {
        updateHeight();
        if (orientation.includes("portrait"))
        {
            setMovableArea();
        }
        else
        {
            removeMovableArea();
        }
        predictionArea.updatePredictLayout();
        updateFocusItem();
    }

    function updateHeight() {
        var newHeight = style.keyboardDefaultHeight + (noWords?0:style.predictPanel.height);
        PluginProxy.setPanelSize(normalKeyboard.width,newHeight);
        height = newHeight;
    }

    function setMovableArea() {
        var marginTop = noWords ? 0 : style.predictPanel.height;
        var right_area_w = style.keyboardDefaultWidth - style.left.leftMargin - style.left.width - style.middle.leftMargin
                         - style.middle.width - style.right.leftMargin - style.right.width;
        var right_area_x = style.keyboardDefaultWidth - right_area_w;
        var bottom_area_y = normalKeyboard.height - style.bottom.bottomMargin;

        PluginProxy.setMovableArea(Maliit.MovableAreaLeft, 0, marginTop, style.left.leftMargin, style.keyboardDefaultHeight);
        PluginProxy.setMovableArea(Maliit.MovableAreaTop, 0, marginTop, style.keyboardDefaultWidth, style.middle.topMargin);
        PluginProxy.setMovableArea(Maliit.MovableAreaRight, right_area_x, marginTop, right_area_w, style.keyboardDefaultHeight);
        PluginProxy.setMovableArea(Maliit.MovableAreaBottom, 0, bottom_area_y, style.keyboardDefaultWidth, style.bottom.bottomMargin);
    }

    function removeMovableArea() {
        PluginProxy.setMovableArea(Maliit.MovableAreaLeft, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaTop, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaRight, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaBottom, 0, 0, 0, 0);
    }

    function updateFocusItem()
    {
        var item = focusRect.focusedItem;
        if (focusRect.visible && item)
        {
            var xOffset = 0;
            var yOffset = 0;

            if (focusRect.focusedArea === "bottomRow")
            {
                xOffset = style.left.leftMargin;
                yOffset = style.left.topMargin + style.middle.height + style.bottom.topMargin;
            }
            else if (focusRect.focusedArea === "navButtons")
            {
                xOffset = style.left.leftMargin + style.left.width + style.middle.leftMargin + normalKeyboard.middleWidth + style.right.leftMargin;
                yOffset = style.left.topMargin + style.middle.height + style.bottom.topMargin;
            }
            else if (focusRect.focusedArea === "leftColumn")
            {
                xOffset = style.left.leftMargin;
                yOffset = style.middle.topMargin;
            }
            else if (focusRect.focusedArea === "letterGrid" || focusRect.focusedArea === "symbolGrid" || focusRect.focusedArea === "predictionGrid")
            {
                xOffset = style.left.leftMargin + style.left.width + style.middle.leftMargin;
                yOffset = style.middle.topMargin;
            }
            else if (focusRect.focusedArea === "rightColumn")
            {
                xOffset = style.left.leftMargin + style.left.width + style.middle.leftMargin + normalKeyboard.middleWidth + style.right.leftMargin;
                yOffset = style.middle.topMargin;
            }
            else if (focusRect.focusedArea === "predictionBar")
            {
                xOffset = predictionArea.xOffset;
                yOffset = -((style.predictPanel.height - style.predictPanel.panelButton.height) / 2 + style.predictPanel.panelButton.height);
            }


            if (item.state === "Select") {
                var selectWidth  = (item.width  + focusRect.focusStyle.widthOffset)  * focusRect.focusStyle.selectRatio;
                var selectHeight = (item.height + focusRect.focusStyle.heightOffset) * focusRect.focusStyle.selectRatio;
                focusRect.width  = selectWidth  < item.width  ? item.width  : selectWidth;
                focusRect.height = selectHeight < item.height ? item.height : selectHeight;
            } else {
                focusRect.width  = item.width  + focusRect.focusStyle.widthOffset;
                focusRect.height = item.height + focusRect.focusStyle.heightOffset;
            }

            focusRect.x = xOffset + item.x - (focusRect.width - item.width)/2;
            focusRect.y = yOffset + item.y - (focusRect.height - item.height)/2 + (predictionArea.visible?predictionArea.height:0);
        }
        else
        {
            setFocusOut();
        }
    }

    function setFocusItem(item,x,y) {
        focusRect.image = "";
        focusRect.visible  = true;
        focusRect.dotVisible = false;

        focusRect.focusedArea = item.parent.objectName;
        focusRect.focusedItem = item;

        // Space-bar "selection state" width will become lesser than its original width
        // if selection ratio directly applied.
        if (item.state === "Select") {
            var selectWidth  = focusRect.width  * focusRect.focusStyle.selectRatio;
            var selectHeight = focusRect.height * focusRect.focusStyle.selectRatio;
            focusRect.width  = selectWidth  < item.width  ? item.width  : selectWidth;
            focusRect.height = selectHeight < item.height ? item.height : selectHeight;
        } else {
            focusRect.width  = item.width  + focusRect.focusStyle.widthOffset;
            focusRect.height = item.height + focusRect.focusStyle.heightOffset;
        }
        focusRect.x = x - (focusRect.width - item.width)/2
        focusRect.y = y - (focusRect.height - item.height)/2 + (predictionArea.visible?predictionArea.height:0);
        focusRect.focusTxt = item.text;
        focusRect.fontSize = item.fontSize;
    }

    function setFocusOut() {
        focusRect.visible = false;
        focusRect.focusTxt = "";
        focusRect.image = "";
    }

    PredictionPanel {
        id: predictionArea
        objectName: "predictionArea"
        visible: !noWords
        anchors.left: parent.left
        anchors.top: parent.top
        height: style.predictPanel.height
        buttonStyle: style.predictPanel.panelButton
        width: root.width
        buttonHeight: style.predictPanel.panelButton.height
        constantPrediction: false
        words: !predictionMode ? Prediction.list.slice(0, predictionArea.maxLength) : undefined

        onSelectPrediction: {
            Prediction.onSelected(word);
            predictionMode = false;
            predictionIndex = 0;
            middleLayoutArea.getMiddleItem().focus = true;
        }

        onSendKey: root.keyPressed(keycode, shift, eventType)
        onTtsService: root.ttsService(text)

        onFocusItem: {
            focusRect.focusStyle = style.panelFocus;
            root.setFocusItem(item,x,y);
        }
        onFocusOut: root.setFocusOut()
        onMeetBottomBoundary: middleLayoutArea.setKeyNavigation(-1,"defaultIndex","Down")
        onMeetTopBoundary: root.meetTopBoundary()
        onVisibleChanged: {
            if (focusRect.visible) {
                if (visible) {
                    focusRect.y = focusRect.y + style.predictPanel.height;
                } else {
                    focusRect.y = focusRect.y - style.predictPanel.height;
                }
            }
        }
    }

    LeftFunctionArea {
        id: leftFunctionArea
        objectName: "leftFunctionArea"
        anchors.top: noWords? parent.top : predictionArea.bottom
        anchors.topMargin: style.left.topMargin
        anchors.left: parent.left
        anchors.leftMargin: style.left.leftMargin
        width: style.left.width
        height: style.left.height
        activateLanguageButton: root.activateLanguageButton
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y)
        }
        onFocusOut: root.setFocusOut()
        onFocusDot: {
            focusRect.dotVisible = true;
            focusRect.dotColor = color;
        }
        onFocusImage: focusRect.image = img
        onClickLanguageButton: root.changeLanguage()
        onTtsService: root.ttsService(text)
        predictModeCheck: root.predictionMode
        onMeetRightBoundary: middleLayoutArea.setKeyNavigation(row, 0, "Right")
        onMeetBottomBoundary: bottomArea.setKeyNavigation(-1)
        onMeetLeftBoundary: rightFunctionArea.setKeyNavigation(row, "Left")
        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(1) :root.meetTopBoundary()
        onPredictState: {
            root.predictModeState = tempState;
            root.setToDefault();
        }
    }

    MiddleLayout {
        id: middleLayoutArea
        objectName: "middleLayoutArea"

        function checkShift(mode) {
            if (mode === "Normal-Shift" && !root.supportPageButton)
                return "Normal";
            else if (mode === "Expand-Shift")
                return "Expand";
            else
                return mode;
        }

        mode: root.mode
        anchors.top: noWords? parent.top : predictionArea.bottom
        anchors.topMargin: style.middle.topMargin
        anchors.left: leftFunctionArea.right
        anchors.leftMargin: style.middle.leftMargin
        height: style.middle.height

        onCurrRepeaterChanged: CommonVariables.savedFocusItem = middleLayoutArea.getMiddleItem()
        onModelChanged: CommonVariables.savedFocusItem = middleLayoutArea.getMiddleItem()
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusOut: root.setFocusOut()
        onSendKey: {
            root.keyPressed(rawcode, shift, eventType);
            root.mode = checkShift(root.mode);
        }

        onSendKeysym: {
            root.keysymPressed(keysym, eventType);
            root.mode = checkShift(root.mode);
        }

        onSendText: {
            root.textKeyPressed(text);
            root.mode = checkShift(root.mode);
        }
        onPressNextPrediction: {
            if (contentType !== Maliit.EmailContentType && contentType !== Maliit.UrlContentType)
                root.drawPredictionLayout();
        }
        onTtsService: root.ttsService(text)

        onMeetLeftBoundary: leftFunctionArea.setKeyNavigation(row)
        onMeetRightBoundary: rightFunctionArea.setKeyNavigation(row)
        onMeetBottomBoundary: bottomArea.setKeyNavigation(column)
        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(2) :root.meetTopBoundary()
    }

    RightFunctionArea {
        id: rightFunctionArea
        objectName:"rightFunctionArea"
        anchors.left: middleLayoutArea.right
        anchors.leftMargin: style.right.leftMargin
        anchors.top: noWords? parent.top : predictionArea.bottom
        anchors.topMargin: style.right.topMargin
        width: style.right.width
        height: style.right.height
        middleWidth: root.middleWidth
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusImage: focusRect.image = img
        onFocusOut: root.setFocusOut()

        onTtsService: root.ttsService(text)
        Component.onCompleted: {
            clickVoiceButton.connect(activateSTT);
            clickClearAllButton.connect(clearAllPressed);
            sendKey.connect(keyPressed);
        }

        onMeetLeftBoundary: {
            if (row < 4) middleLayoutArea.setKeyNavigation(row, -1, "Left");
            else bottomArea.setKeyNavigation("defaultIndex");
        }

        onMeetRightBoundary: {
            if (row < 4) {
                leftFunctionArea.setKeyNavigation(row)
            }
            else bottomArea.setKeyNavigation(-1)
        }

        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(3) :root.meetTopBoundary()
        onMeetBottomBoundary: bottomArea.setKeyNavigation(-2)
    }

    BottomArea {
        id: bottomArea
        objectName: "bottomArea"
        anchors.left: root.left
        anchors.leftMargin: style.bottom.leftMargin
        anchors.top: leftFunctionArea.bottom

        showMoreButton: (!predictionMode) && (predictionArea.maxLength < Prediction.list.length)
        showBackButton: predictionMode

        anchors.topMargin: style.bottom.topMargin
        height: style.bottom.height
        spaceBarWidth: root.middleWidth
        onSendKey: root.keyPressed(keycode, shift, eventType)
        onTtsService: root.ttsService(text)
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusOut: root.setFocusOut()
        onFocusImage: focusRect.image = img

        onPressMore: {
            if (contentType !== Maliit.EmailContentType && contentType !== Maliit.UrlContentType) {
                root.drawPredictionLayout();
            }
        }
        onPressBack:root.setToDefault()

        onMeetTopBoundary: {
            if (column === -1)
                leftFunctionArea.setKeyNavigation(3);
            else if (column === -2)
                rightFunctionArea.setKeyNavigation(-1);
            else
                middleLayoutArea.setKeyNavigation(-1, column, "Up");
        }
        onMeetBottomBoundary: root.meetBottomBoundary()
    }

    Item {
        id: dragIconArea
        objectName:"dragIconArea"
        anchors.left: rightFunctionArea.right
        anchors.top: noWords? parent.top : predictionArea.bottom
        width: style.right.rightMargin
        height: noWords? parent.height : parent.height - predictionArea.height
        visible:  isPortrait
        Image {
            id: dragIcon
            source: style.getImage("ic_drag");
            smooth: true
            anchors.centerIn: dragIconArea
        }
    }

    FocusPanel {
        id: focusRect
        objectName: "focusRect"
        focusStyle: style.focus
        visible: true
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Up)
            PluginProxy.onHideRequested(true);
    }

    onModeChanged: {
        if (predictionMode) {
            setToDefault()
        }
        CommonVariables.savedFocusItem = middleLayoutArea.getMiddleItem();
    }

    onContentTypeChanged: {
        middleLayoutArea.getMiddleItem().focus = true;
    }

    Connections {
        target: Prediction
        onActiveChanged: {
            if (!active) {
                root.predictionMode = false;
                root.predictionIndex = 0;
            }
        }
        onPredictionListChanged: {
            if (predictionMode) {
                root.predictionIndex = 0;
                root.drawPredictionLayout();
            }
        }
    }

    function setDefaultFocus(shouldResetFocus = true) {
        if (middleLayoutArea.defaultFocus !== undefined) {
            if (shouldResetFocus) {
                CommonVariables.savedFocusItem.focus = false;
            }
            CommonVariables.savedFocusItem = middleLayoutArea.currRepeater.itemAt(middleLayoutArea.defaultFocus);
        }
    }

    function setLanguage(language, label, langCode, data) {
        currLanguage = language;
        languageLabel = label;
        style.setDefaultFont(langCode);
        mode = "Normal";

        if ( currLanguage === 'Arabic' || currLanguage === 'Kurdish' || currLanguage === 'Hindi')
            root.supportPageButton = true;
        else
            root.supportPageButton = false;
        if (currLanguage === 'Hebrew')
            root.supportShiftMode = false;
        else
            root.supportShiftMode = true;

        drawLayout(data);
        setDefaultFocus(false);
    }

    function drawLayout(data) {
        supportExpandMode = data.supportAccent;
        supportExpandShiftMode = data.supportAccentEx;

        // set language grid
        middleLayoutArea.setLayoutData(data.row, data.column, data.keys);

        // set symbol grid
        var symbolColumnLength = (data.column < 12) ? 10 : 12;
        middleLayoutArea.setSymbolLayoutData(
                    4, symbolColumnLength,
                    (symbolColumnLength === 10) ? Variables.symbolSet10x4 : Variables.symbolSet12x4);

        middleLayoutArea.defaultFocus = ( 2 * data.column ) + Math.round( data.column/2 ) - 1;
    }

    function updateMiddleLayout(col) {
        middleLayoutArea.updateSymbolLayout(col);
        middleLayoutArea.updateLetterLayout(col);
        middleLayoutArea.updatePredictionLayout();
        bottomArea.updateBottomLayout();
    }

    function drawPredictionLayout() {

        var row = 4;
        var column = 5;
        var i = 0;

        var model = [];
        for (i = 0; i < row * column - 1; i++) {    // 1 cell is reserved for the [...] button
            if (Prediction.list[predictionIndex + i] !== undefined)
                model.push(Prediction.list[predictionIndex + i]);
            else
                break;
        }

        var spaceIndex = i;
        for (spaceIndex; spaceIndex < row * column - 1; spaceIndex++) {
            model.push('');
        }

        // set layout to grid
        middleLayoutArea.setPredictionLayoutData(row, column, model);
        predictionMode = true;
        predictionIndex += i;
    }

    function setToDefault() {
        predictionIndex = 0;
        if(predictionMode && predictModeState && predictModeState !== "" && predictModeState === "Normal"){
            mode = "Symbol"
        } else {
            mode = "Normal";
        }
        predictionMode = false;
        if (PluginProxy.cursorVisible) {
            return;
        }
        var item = middleLayoutArea.getMiddleItem();
        if (item.x === 0) {
            focusTimer.start();
        } else {
            item.focus = true;
            middleLayoutArea.setFocusIn(item, item.x, item.y);
        }
    }

    Timer {
        id: focusTimer
        interval: 100
        repeat: true
        onTriggered: {
            var item = middleLayoutArea.getMiddleItem();
            if (item.x !== 0) {
                // Make sure when the timer expired, Active keyboard is still the "Normal-keyboard"
                if (activeKeyboard === "Normal-Keyboard") {
                    item.focus = true;
                    middleLayoutArea.setFocusIn(item, item.x, item.y);
                }
                focusTimer.stop();
            }
        }
    }

    function setFocusToEnter() {
        rightFunctionArea.setFocusTo("Enter");
    }
}
