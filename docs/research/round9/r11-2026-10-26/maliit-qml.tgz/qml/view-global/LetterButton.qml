/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

import "../keyboard-common"

ButtonBase {
    id: letterButton
    objectName: "letterButton"
    property string mode: "Normal"
    property variant keyData
    property string mainChar: (keyData && keyData.mainChar) ? keyData.mainChar : ""     /* display character */
    property string shiftedChar: (keyData && keyData.shiftedChar) ? keyData.shiftedChar : ""
    property string expandChar: (keyData && keyData.expandChar) ? keyData.expandChar : ""
    property string expandShiftedChar: (keyData && keyData.expandShiftedChar) ? keyData.expandShiftedChar : ""
    property string mainAudioChar: (keyData && keyData.mainAudioChar) ? keyData.mainAudioChar : ""     /* display Audiocharacter */
    property string shiftedAudioChar: (keyData && keyData.shiftedAudioChar) ? keyData.shiftedAudioChar : ""
    property string expandAudioChar: (keyData && keyData.expandAudioChar) ? keyData.expandAudioChar : ""
    property string expandShiftedAudioChar: (keyData && keyData.expandShiftedAudioChar) ? keyData.expandShiftedAudioChar : ""
    property string rawcode: (keyData && keyData.rawcode) ? keyData.rawcode : "-1"        /* code sening to engine */
    property string shiftRawcode: (keyData && keyData.shiftRawcode) ? keyData.shiftRawcode : "-1"
    property string expandRawcode: (keyData && keyData.expandRawcode) ? keyData.expandRawcode : "-1"
    property string expandShiftRawcode: (keyData && keyData.expandShiftRawcode) ? keyData.expandShiftRawcode : "-1"
    property string normalKeysym: (keyData && keyData.normalKeysym) ? keyData.normalKeysym : "-1"
    property string shiftKeysym: (keyData && keyData.shiftKeysym) ? keyData.shiftKeysym : "-1"
    property string expandKeysym: (keyData && keyData.expandKeysym) ? keyData.expandKeysym : "-1"
    property string expandShiftKeysym: (keyData && keyData.expandShiftKeysym) ? keyData.expandShiftKeysym : "-1"
    property bool forceText : (keyData && keyData.forceText) ? keyData.forceText : false
    signal sendKey(string rawcode, bool shift, int eventType)
    signal sendKeysym(string keysym,int eventType)
    signal sendText(string text)

    function updateState(text) {
        if (text.length === 0)
            state = "Disable";
        else if (state === "Disable")
            state = "Normal";
    }

    audioText : {
        var audio = "";
        if (mode === "Normal") {
            audio = mainAudioChar;
        }
        else if (mode === "Normal-Shift" || mode === "Normal-Shift-Lock") {
            audio = shiftedAudioChar;
        }
        else if (mode === "Expand") {
            audio = expandAudioChar;
        }
        else if (mode === "Expand-Shift" || mode === "Expand-Shift-Lock") {
            audio = expandShiftedAudioChar;
        }
        else {
            audio = "";
        }

        return audio;
    }

    text: {
        if (mode === "Normal")
            mainChar
        else if (mode === "Normal-Shift" || mode === "Normal-Shift-Lock")
            shiftedChar
        else if (mode === "Expand")
            expandChar
        else if (mode === "Expand-Shift" || mode === "Expand-Shift-Lock")
            expandShiftedChar
        else
            ""
    }

    onTextChanged: updateState(text)
    Component.onCompleted: updateState(text)

    onReleased: {
        if (forceText) {
            sendText(text);
            return;
        }

        switch (mode) {
        case "Normal":
            if (normalKeysym !== "-1")
                sendKeysym(normalKeysym, eventType);
            else
                sendKey(rawcode, false, eventType);
            break;
        case "Normal-Shift":
            if (shiftKeysym !== "-1")
                sendKeysym(shiftKeysym, eventType);
            else
                sendKey(shiftRawcode, true, eventType);
            break;
        case "Normal-Shift-Lock":
            if (shiftKeysym !== "-1")
                sendKeysym(shiftKeysym, eventType);
            else
                sendKey(shiftRawcode, true, eventType);
            break;
        case "Expand":
            if (expandKeysym !== "-1")
                sendKeysym(expandKeysym, eventType);
            else
                sendKey(expandRawcode, false, eventType);
            break;
        case "Expand-Shift":
            if (expandShiftKeysym !== "-1")
                sendKeysym(expandShiftKeysym, eventType);
            else
                sendKey(expandRawcode, false, eventType);
            break;
        case "Expand-Shift-Lock":
            if (expandShiftKeysym !== "-1")
                sendKeysym(expandShiftKeysym, eventType);
            else
                sendKey(expandRawcode, false, eventType);
            break;
        case "Symbol":
            sendText(text);
            break;
        default:
            console.log("Error! mode is " + mode);
        }
    }

    Connections {
        target: PluginProxy
        onKeyReleased : {
            if (isReleased && (state === "Select"))
                state = "Focus";
        }
    }
}
