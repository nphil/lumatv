/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import QtQuick.Window 2.2
import PmLog 1.0

import com.meego.maliit 1.0
import WebOSServices 1.0

import "../keyboard-common"
import "../keyboard-common/style"
import "../keyboard-common/commonvariables.js" as CommonVariables
import "StringResource"

Rectangle {
    id: root
    objectName: "mainGlPlugin"
    y: Screen.height + 1000;

    // Keyboard App Id for Luna Service
    property string appId: "com.webos.service.ime.globalplugin"

    property real resolution : {
        if ((Screen.width >= 3840 && Screen.height >= 2160) || (Screen.height >= 3840 && Screen.width >= 2160)) return style.resolution_4k;
        if ((Screen.width >= 2560 && Screen.height >= 1440) || (Screen.height >= 2560 && Screen.width >= 1440)) return style.resolution_QHD;
        if ((Screen.width >= 1920 && Screen.height >= 1080) || (Screen.height >= 1920 && Screen.width >= 1080)) return style.resolution_2k;
        return style.resolution_HD;
    }

    property string orientation: "landscape"
    property bool isPortrait : { return orientation.includes("portrait"); }

    property QtObject style_landscape: GlobalStyle {id: globalStyle; resolution: root.resolution}
    property QtObject style_portrait: GlobalStylePortrait {id: globalStylePortrait; resolution: root.resolution}
    property QtObject style: isPortrait ? style_portrait : style_landscape
    property QtObject globalStringModel: StringModel {}
    property string label    : ""
    property string langCode : ""
    property string audioGuidance: "off"
    property string foregroundAppId: ''
    property string lastInputType: 'touch'
    property bool supportVoiceRecognition : false
    property bool pointerVisible : false
    property bool setFocusFirstAfterEnabled : false
    property int contentType: PluginProxy.contentType
    property bool hiddenText: PluginProxy.hiddenText
    property int inputSource: PluginProxy.inputSource
    property int enterKeyType: PluginProxy.enterKeyType
    property int defaultKeyboardColumn: 10
    property int windowWidth: style.keyboardDefaultWidth
    property int windowHeight:style.keyboardDefaultHeight
    property alias pmLog: pmLog
    property alias activeKeyboard : root.state
    property int keyboardColumns: 0
    property var keyboardMap: {
        "Normal-Keyboard" : normalKeyboard,
        "Number-Keyboard" : numberKeyboard
    }
    property bool restrictedWindowType:false
    signal keyPressed(string rawcode, bool shift, int eventType)
    signal textKeyPressed(string text)
    signal switchContext()
    signal activateSTT()
    signal clearAllPressed()
    signal moveCursorPosition(int direction,int eventType)
    signal showRequested(bool reset)
    signal hideRequested(bool reset)
    signal keysymPressed(string keysym, int eventType)

    color: 'transparent'

    function setFocusToEnter() {
        if (state === "Normal-Keyboard")
            normalKeyboard.setFocusToEnter();
        else if (state === "Number-Keyboard")
            numberKeyboard.setFocusToEnter();
    }

    function setFoucusToHID() {
        hidWidget.setFocusToHID();
    }

    function reset() {
        if (state === "Normal-Keyboard") {
            normalKeyboard.setToDefault();
        }
        else if (state === "Number-Keyboard") {
            numberKeyboard.setToDefault();
        }
    }

    function adjustKeyboard(col) {
        if (root.orientation.includes("landscape"))
        {
            var newMiddleWidth = (style.middle.cellWidth + style.middle.cellSpace) * col - style.middle.cellSpace;
            var newWidth = style.left.width + style.middle.leftMargin + newMiddleWidth +
                        style.right.leftMargin + style.right.width;
            style.left.leftMargin = (style.keyboardDefaultWidth - newWidth) / 2;
            style.bottom.leftMargin = (style.keyboardDefaultWidth - newWidth) / 2;
            normalKeyboard.middleWidth = newMiddleWidth;
        }
        else if (root.orientation.includes("portrait"))
        {
            normalKeyboard.middleWidth = style.middle.width;
        }
        root.windowHeight = style.keyboardDefaultHeight
        normalKeyboard.updateMiddleLayout(col);
    }

    function triggerOrientationChanged() {
        if (state === "Normal-Keyboard")
        {
            normalKeyboard.orientationChanged(root.orientation);
        }
        else if (state === "Number-Keyboard")
        {
            numberKeyboard.orientationChanged(root.orientation);
        }
        else if (state === "Hid-Prediction")
        {
            hidWidget.orientationChanged(root.orientation);
        }
        else
        {
            normalKeyboard.height = style.keyboardDefaultHeight;
            normalKeyboard.removeMovableArea();
        }
    }

    onOrientationChanged: {
        if (root.orientation.includes("portrait"))
        {
            root.style = root.style_portrait;
        }
        else
        {
            root.style = root.style_landscape;
            normalKeyboard.removeMovableArea();
        }
        adjustKeyboard(root.keyboardColumns);
        triggerOrientationChanged();
    }

    Component.onCompleted: {
        audioService.getAudioGuidance();
        voiceService.getVoiceRecognition();
        surfaceManagerService.getForegroundAppInfo();
        orientationService.getOrientationInfo();
        inputService.getLastInputType();
    }

    onLastInputTypeChanged: {
        setDefaultFocusOnVirtualKeybaord();
    }

    onStateChanged:  {
        root.reset();
    }

    onSetFocusFirstAfterEnabledChanged: {
        console.warn("onSetFocusAfterEnabledChanged : " + setFocusFirstAfterEnabled);
        if (setFocusFirstAfterEnabled){
            setDefaultFocusOnVirtualKeybaord();
            setFocusFirstAfterEnabled = false;
        }
    }

    PmLog {
        id: pmLog
        context: root.appId

        function printNormalLog(messageId, value) {
            pmLog.info(messageId, value);
        }

    }

    // Normal Keyboard
    NormalKeyboard {
        id: normalKeyboard
        objectName: "normalKeyboard"
        enterKeyType: root.enterKeyType
        width: style.keyboardDefaultWidth
        height: style.keyboardDefaultHeight
        anchors.left: parent.left
        enabled: false
        y: windowHeight
        enableVoiceButton: root.restrictedWindowType ? false :((hiddenText || !supportVoiceRecognition) ? false : true)
        // slots
        onKeyPressed: root.keyPressed(rawcode, shift, eventType)
        onKeysymPressed: root.keysymPressed(keysym, eventType)
        onTextKeyPressed: root.textKeyPressed(text)
        onChangeLanguage: {
            root.switchContext()
        }
        onActivateSTT: root.activateSTT()
        onClearAllPressed: root.clearAllPressed()
        onTtsService: ttsService.speakButton(text)
        onNoWordsChanged: {
            // updateHeight();
            var newHeight = style.keyboardDefaultHeight + (noWords?0:style.predictPanel.height);
            PluginProxy.setPanelSize(normalKeyboard.width,newHeight);
            height = newHeight;
            if (root.orientation.includes("portrait"))
                setMovableArea()
        }

        onMeetTopBoundary: hideRequested(true)
        onMeetBottomBoundary: hideRequested(true)
    }

    // Number Keyboard
    NumberKeyboard {
        id: numberKeyboard
        objectName: "numberKeyboard"
        width: style.numberKeyboard.width
        height: style.numberKeyboard.height
        anchors.left: parent.left
        enabled: false
        y: windowHeight

        // slots
        onSendKey: root.keyPressed(keycode, shift, eventType)
        onSendText: root.textKeyPressed(text)

        onTtsService: ttsService.speakButton(text)
        onMeetTopBoundary: hideRequested(true)
        onMeetBottomBoundary: hideRequested(true)
    }

    // HID Prediction
    HidPredictionWidget {
        id: hidWidget
        objectName: "hidWidget"
        width: style.hidPredWidth
        height: style.hidPredHight
        anchors.left: parent.left
        enabled: false
        y: windowHeight
        Keys.onPressed: onSendKey(event.key)
    }

    Service {
        id: lunaService
        appId: "com.webos.service.ime.globalplugin"

        function showLanguageNotification(language) {
            var param = "";
            param += ("\"sourceId\":\"" + appId + "\"");
            param += (",\"message\":\"" + language + "\"");
            param += (",\"noactions\":\"true\"");
            call("palm://com.webos.notification", "/createToast", "{" + param + "}");
        }
    }
    /* Service : TTS Service Control */
    Service {
        id: ttsService
        property bool visible : PluginProxy.visible

        appId: "com.webos.service.ime.globalplugin"
        service: "com.webos.service.tts"
        method: "speak"
        onResponse: console.warn("@@@ VKB TTS onResponse @@@")
        onError: console.warn("@@@ VKB TTS onError @@@")
        function speakButton(value) {
            console.warn("= = = = = = = = = = = = = = = @@@ VKB TTS @@@ t:" + value + ", a:" + audioGuidance + ",langCode:" + langCode + ", p:" + pointerVisible + ", visible : " + visible);
            console.warn("= = = = = = = = = = = = = = = @@@ VKB TTS @@@ translatorLocale : " +  PluginProxy.translatorLocale);
            var text =globalStringModel.getPronounceByChar(value);
            console.warn("= = = = = = = = = = = = = = = @@@ VKB TTS @@@ text : " + text);
            if (visible && pointerVisible === false &&  audioGuidance === "on") {
                if (setFocusFirstAfterEnabled == true) {
                    return;
                }
                callService({"text" : text, "clear" : true, "language" : (state === "Number-Keyboard") ? PluginProxy.translatorLocale : langCode})
            }
        }
    }

    /* Service : Audio Guidance Control */
    Service {
        id: audioService
        appId: "com.webos.service.ime.globalplugin"
        service: "com.webos.settingsservice"
        method: "getSystemSettings"
        onResponse: {
            var jsonObject

            if (method.toString() && method.toString() === "getSystemSettings") {
                jsonObject = JSON.parse(payload);
                if (jsonObject && typeof jsonObject.settings !== 'undefined' && typeof jsonObject.settings.audioGuidance !== 'undefined') {
                    root.audioGuidance = jsonObject.settings.audioGuidance
                }
            }
        }
        function getAudioGuidance() {
            callService({"subscribe" : true, "keys" : ["audioGuidance"], "category" : "option"})
        }
    }

    /* Service : Voice Recognition */
    Service {
        id: voiceService
        appId: "com.webos.service.ime.stt"
        service: "com.webos.service.config"
        method: "getConfigs"
        onResponse: {
            var jsonObject
            if (method.toString() && method.toString() === "getConfigs") {
                jsonObject = JSON.parse(payload);
                console.warn("= = = = = = = = = = = = voice config : " + jsonObject.configs["system.supportVoiceRecognition"])
                if (jsonObject && typeof jsonObject.configs !== 'undefined') {
                    root.supportVoiceRecognition = jsonObject.configs["system.supportVoiceRecognition"]
                } else {
                    root.supportVoiceRecognition = false
                }
            }
        }
        function getVoiceRecognition() {
            callService({"subscribe" : true, "configNames" : ["system.supportVoiceRecognition"]})
        }
    }

    Service {
        id: surfaceManagerService
        appId: root.appId
        service: "com.webos.surfacemanager"
        method: "getForegroundAppInfo"
        onResponse: {
            var jsonObject = JSON.parse(payload);
            if (jsonObject.foregroundAppInfo.length > 0) {
                var foregroundAppInfo =  jsonObject.foregroundAppInfo.slice(-1)[0];
                root.foregroundAppId = foregroundAppInfo.appId;
                root.restrictedWindowType= (foregroundAppInfo.windowType === "_WEBOS_WINDOW_TYPE_RESTRICTED") ? true : false;
            }
            console.warn("@@@@ root.foregroundAppId", root.foregroundAppId);
        }
        function getForegroundAppInfo() {
            callService({"subscribe": true});
        }
    }

    /* Service: Get orientation */
    Service {
        id: orientationService
        appId: root.appId
        service: "com.webos.service.msc"
        method: "getOrientationInfo"
        onResponse: {
            var jsonObject = JSON.parse(payload);
            if (jsonObject)
            {
                if (jsonObject.returnValue)
                    root.orientation = jsonObject.orientation;
                else
                    root.orientation = "landscape"
            }
            else
                root.orientation = "landscape"
        }
        function getOrientationInfo() {
            callService({"subscribe": true});
        }
    }

    Service {
        id: inputService
        appId: root.appId
        service: "com.webos.surfacemanager"
        method: "getLastInputType"
        onResponse: {
            var jsonObject = JSON.parse(payload);
            if (jsonObject && jsonObject.lastInputType) {
                root.lastInputType = jsonObject.lastInputType;
            }
        }
        function getLastInputType() {
            callService({"subscribe": true});
        }
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Up) {
            hideRequested(true);
            event.accepted = true;
        }
    }

    states: [
        State {
            name: "Active"
            PropertyChanges {
                target: root
                enabled: true
                y: 0
            }
            StateChangeScript {
                script: showRequested(false)
            }
        },
        State {
            name: "Normal-Keyboard"; extend: "Active"
            when: inputSource === 1 && (contentType !== Maliit.NumberContentType && contentType !== Maliit.PhoneNumberContentType)
            PropertyChanges {
                target: normalKeyboard
                enabled: true
                y: 0
                focus: true
            }
            PropertyChanges {
                target: numberKeyboard
                enabled: false
                visible: false
            }
            PropertyChanges {
                target: hidWidget
                enabled: false
                visible: false
            }
            StateChangeScript {
                script: {
                    PluginProxy.setPanelSize(normalKeyboard.width, normalKeyboard.height);
                    if (orientation.includes("portrait")) normalKeyboard.setMovableArea();
                }
            }
        },
        State {
            name: "Number-Keyboard"; extend: "Active"
            when: inputSource === 1 && (contentType === Maliit.NumberContentType || contentType === Maliit.PhoneNumberContentType)
            PropertyChanges {
                target: numberKeyboard
                enabled: true
                y: 0
                focus: true
            }
            StateChangeScript {
                script: {
                    PluginProxy.setPanelSize(style.numberKeyboard.width, style.numberKeyboard.height);
                    if (orientation.includes("portrait")) numberKeyboard.setMovableArea();
                }
            }
        },
        State {
            name: "Hid-Prediction"; extend: "Active"
            when: inputSource === 0 && Prediction.list.length > 0 && (contentType !== Maliit.UrlContentType && contentType !== Maliit.EmailContentType)
            PropertyChanges {
                target: hidWidget
                enabled: true
                y: 0
                focus: true
            }
            StateChangeScript {
                script: {
                    PluginProxy.setPanelSize(style.hidPredWidth ,style.hidPredHight);
                    if (orientation.includes("portrait")) hidWidget.setMovableArea();
                }
            }
        },
        State {
            name: "Hide"
            when: inputSource === 0 && (Prediction.list.length === 0 || contentType === Maliit.UrlContentType || contentType === Maliit.EmailContentType)
            StateChangeScript {
                script: {
                    hideRequested(false)
                    normalKeyboard.removeMovableArea()
                }
            }
        }
    ]

    Connections {
        target: PluginProxy
        onLanguageChanged: {
            root.label = (langCode === "ko") ? "KOR" : label;
            root.langCode = langCode;
            root.keyboardColumns = data.column;
            adjustKeyboard(root.keyboardColumns);
            normalKeyboard.setLanguage(language, label, langCode, data);
        }

        onSetDefaultFocus: {
            if (state === "Normal-Keyboard") {
                normalKeyboard.setFocusOut();
                normalKeyboard.setToDefault();
            }
        }

        onShowLanguageNotification: {
            lunaService.showLanguageNotification(label)
        }

        onVisibleChanged: {
            console.warn("At visible changed, State : " + state, " visible : ", visible);
            if (!visible) {
                root.reset();
                if (state === "Normal-Keyboard")
                    normalKeyboard.setDefaultFocus();
                else if (state === "Number-Keyboard")
                    numberKeyboard.setDefaultFocus();
            } else {
                setFocusFirstAfterEnabled = Qt.binding(function(){
                    return state === "Normal-Keyboard" ? normalKeyboard.enabled : numberKeyboard.enabled;
                })
            }
        }
        onContentTypeChanged: {
            console.warn("onContentTypeChanged : ", contentType);
            root.reset();
            setFocusFirstAfterEnabled = Qt.binding(function(){
                return state === "Normal-Keyboard" ? normalKeyboard.enabled : numberKeyboard.enabled;
            })
        }

        onLanguageCountChanged: {
            normalKeyboard.activateLanguageButton = (languageCount > 1) ? true : false
        }

        onForceFocusTo: {
            switch (label) {
            case "Enter":
                setFocusToEnter();
                break;
            case "HID":
                setFoucusToHID();
                break;
            default:
                break;
            }
        }

        onResetRequested: {
            console.warn("resetRequested");
            setFocusFirstAfterEnabled = Qt.binding(function(){
                return state === "Normal-Keyboard" ? normalKeyboard.enabled : numberKeyboard.enabled;
            })
        }

        onTranslatorChanged: {
            style.setDefaultFont(PluginProxy.translatorLocale)
            if (speakLanguage == false) return;
            if (inputSource == 0 || visible == false) return; // because reading lang name through toast popup
            ttsService.speakButton(globalStringModel.getStringLangCode(langCode));
        }
        onCursorVisibleChanged: {
            console.warn("IMEManager cursor visible : " + cursorVisible);
            root.pointerVisible = cursorVisible;
            setDefaultFocusOnVirtualKeybaord();
       }
    }

    function setDefaultFocusOnVirtualKeybaord() {
        var keyboardMap = {
            "Normal-Keyboard" : normalKeyboard,
            "Number-Keyboard" : numberKeyboard
        }
        var currentKeyboard = keyboardMap[state] || normalKeyboard;
        if (root.lastInputType === 'touch' || root.lastInputType === 'mouse'){
            CommonVariables.savedFocusItem.focus = false;
            currentKeyboard.setFocusOut();
        } else {
            // key inputMode
            if (CommonVariables.savedFocusItem && CommonVariables.savedFocusItem.visible) {
                CommonVariables.savedFocusItem.focus = true;
                CommonVariables.savedFocusItem.releaseButton();
            } else if (keyboardMap[state]) {
                currentKeyboard.setDefaultFocus();
            }

        }
    }
}
