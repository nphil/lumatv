
/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "../keyboard-common"

ButtonBase {
    objectName: "symbolButton"
    signal sendText(string text)

    function checkState(text) {
        return (text.length > 0) ? "Normal" : "Disable";
    }

    state: checkState(text)
    onReleased: sendText(text)

    Connections {
        target: PluginProxy
        onKeyReleased : {
            if (isReleased && (state === "Select"))
                state = "Focus";
        }
    }
}
