/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "../keyboard-common/style-portrait"

Style {
    id: root

    property int keyboardDefaultHeight: 894 / resolution

    property var hidPreButton: QtObject {
        property int leftMargin: 114 / resolution
        property int width:      114 / resolution
        property int height:     132 / resolution
    }

    property var hidPredRow: QtObject {
        property int leftMargin: 24 / resolution
        property int cellSpace:  24 / resolution
        property int width:    1656 / resolution
        property int height:    132 / resolution
    }

    property var hidPredItem: QtObject {
        property string fontFamily: defaultFontFamily
        property int height:    132 / resolution
        property int radius:     12 / resolution
        property int wordHeight: 78 / resolution
        property var normal: QtObject {
            property color bgColor: "#42484E"
            property color fgColor: "#E6E6E6"
            property color borderColor: "#545A64"
            property int borderWidth: 4 / resolution
            property int fontSize:   78 / resolution
        }
        property var disable: QtObject {
            property color bgColor: "transparent"
            property color fgColor: "#42484E"
            property color borderColor: "#545A64"
            property int borderWidth: 4 / resolution
            property int fontSize:   38 / resolution
        }
        property var hotKey: QtObject {
            property int rightMargin: 12 / resolution
            property int height:      42 / resolution
            property int fontSize:    39 / resolution
            property color fgColor: "#ABAEB3"
        }
    }

    property var hidNextButton: QtObject {
        property int rightMargin: 114 / resolution
        property int width:       114 / resolution
        property int height:      132 / resolution
    }

    property var predictPanel : PredictionPanelStyle {resolution: root.resolution}

    // languages (ttsStrings)
    property string _Albanian: qsTr("Albanian") + PluginProxy.emptyString
    property string _Arabic: qsTr("Arabic") + PluginProxy.emptyString
    property string _Bosnian: qsTr("Bosnian") + PluginProxy.emptyString
    property string _Bulgarian: qsTr("Bulgarian") + PluginProxy.emptyString
    property string _Croatian: qsTr("Croatian") + PluginProxy.emptyString
    property string _Czech: qsTr("Czech") + PluginProxy.emptyString
    property string _Danish: qsTr("Danish") + PluginProxy.emptyString
    property string _Dutch: qsTr("Dutch") + PluginProxy.emptyString
    property string _English: qsTr("English") + PluginProxy.emptyString
    property string _Estonian: qsTr("Estonian") + PluginProxy.emptyString
    property string _Finnish: qsTr("Finnish") + PluginProxy.emptyString
    property string _French: qsTr("French") + PluginProxy.emptyString
    property string _Gaelic: qsTr("Gaelic") + PluginProxy.emptyString
    property string _German: qsTr("German") + PluginProxy.emptyString
    property string _Greek: qsTr("Greek") + PluginProxy.emptyString
    property string _Hebrew: qsTr("Hebrew") + PluginProxy.emptyString
    property string _Hindi: qsTr("Hindi") + PluginProxy.emptyString
    property string _Hungarian: qsTr("Hungarian") + PluginProxy.emptyString
    property string _Indonesian: qsTr("Indonesian") + PluginProxy.emptyString
    property string _Irish: qsTr("Irish") + PluginProxy.emptyString
    property string _Italian: qsTr("Italian") + PluginProxy.emptyString
    property string _Kazakh: qsTr("Kazakh") + PluginProxy.emptyString
    property string _Korean: qsTr("Korean") + PluginProxy.emptyString
    property string _Kurdish: qsTr("Kurdish") + PluginProxy.emptyString
    property string _Latvian: qsTr("Latvian") + PluginProxy.emptyString
    property string _Lithuanian: qsTr("Lithuanian") + PluginProxy.emptyString
    property string _Macedonian: qsTr("Macedonian") + PluginProxy.emptyString
    property string _Malay: qsTr("Malay") + PluginProxy.emptyString
    property string _Maori: qsTr("Maori") + PluginProxy.emptyString
    property string _Mongolian: qsTr("Mongolian") + PluginProxy.emptyString
    property string _Norwegian: qsTr("Norwegian") + PluginProxy.emptyString
    property string _Persian: qsTr("Persian") + PluginProxy.emptyString
    property string _Polish: qsTr("Polish") + PluginProxy.emptyString
    property string _Portuguese: qsTr("Portuguese") + PluginProxy.emptyString
    property string _Romanian: qsTr("Romanian") + PluginProxy.emptyString
    property string _Russian: qsTr("Russian") + PluginProxy.emptyString
    property string _Serbian: qsTr("Serbian") + PluginProxy.emptyString
    property string _Slovak: qsTr("Slovak") + PluginProxy.emptyString
    property string _Slovenian: qsTr("Slovenian") + PluginProxy.emptyString
    property string _Spanish: qsTr("Spanish") + PluginProxy.emptyString
    property string _Swedish: qsTr("Swedish") + PluginProxy.emptyString
    property string _Thai: qsTr("Thai") + PluginProxy.emptyString
    property string _Turkish: qsTr("Turkish") + PluginProxy.emptyString
    property string _Ukrainian: qsTr("Ukrainian") + PluginProxy.emptyString
    property string _Uzbek: qsTr("Uzbek") + PluginProxy.emptyString
    property string _Vietnamese: qsTr("Vietnamese") + PluginProxy.emptyString
}