import QtQuick 2.0

QtObject {
    id: root

    property var emptyString

    property var strings: {
        "OK": qsTr("OK") + emptyString, // i18n this is used for ok button
        "CANCEL": qsTr("CANCEL") + emptyString, // i18n this is used for cancel button
        "YES": qsTr("YES") + emptyString,   // i18n text on button
        "NO": qsTr("NO") + emptyString,   // i18n text on button
        "checked": qsTr("checked") + emptyString,  // i18n text for tts
        "unchecked": qsTr("unchecked") + emptyString,    // i18n text for tts
        "scroll up": qsTr("scroll up")  + emptyString,   // i18n scroll bar up button string for tts
        "scroll down": qsTr("scroll down") + emptyString, // i18n scroll bar up button string for tts
        "up": qsTr("up") + emptyString, // i18n button name up
        "down": qsTr("down") + emptyString, // i18n button name down
        "Do you want to go to \"Network Settings\" now to check the connection?": qsTr("Do you want to go to \"Network Settings\" now to check the connection?") + emptyString, // i18n this is content for network disconnected alert popup to make user go to network setting
        "Voice is not recognized. Try again.": qsTr("Voice is not recognized. Try again.") + emptyString, // i18n this is message for unrecognized voice error.
        "Do you want to go to \"Network Settings\" now to set up the network?": qsTr("Do you want to go to \"Network Settings\" now to set up the network?") + emptyString, // i18n this is content for network not set up alert popup to make user go to network setting
        "Speak to input text.": qsTr("Speak to input text.") + emptyString, // i18n This sentence appears when user tries to input text by voice recognition.
        "(": qsTr("(") + emptyString, // i18n left pahrenheit
        ")": qsTr(")") + emptyString, // i18n right pahrenheit
        "VOICE RECOGNITION RESULTS": qsTr("VOICE RECOGNITION RESULTS") + emptyString, // i18n this is title for voice recognition result
        "Voice recognition server is not responding. Try again.": qsTr("Voice recognition server is not responding. Try again.") + emptyString, // i18n this is error message for server side error.
        "Turn on Bluetooth and then speak to Magic remote for voice recognition.": qsTr("Turn on Bluetooth and then speak to Magic remote for voice recognition.") + emptyString, // i18n this is error message that user need to turn on bluetooth function on network setting.
        "You need to use LG Magic Remote to use voice recognition.": qsTr("You need to use LG Magic Remote to use voice recognition.") + emptyString, // i18n this is message that user need to use magic remote to use STT function.
        "To use voice recognition with the Magic Remote that you are currently using, please try again from the other TV.": qsTr("To use voice recognition with the Magic Remote that you are currently using, please try again from the other TV.") + emptyString, // i18n This is error message for unpaired mrcu on TwinMode
        "Loading": qsTr("Loading") + emptyString, // i18n for TTS to process search
        "button": qsTr("button") + emptyString, // i18n for TTS with button
        "SELECT LANGUAGE": qsTr("SELECT LANGUAGE") + emptyString, // i18n This is title for voice recognition language select popup.
        "Red Button": qsTr("Red Button") + emptyString,  // i18n remocon button red
        "Press %1%2 to change language.": qsTr("Press %1%2 to change language.") + emptyString,  // i18n - This string is guide string to make user to press red button on remote controller if he wants to change STT(Speak To Text)Language. For example, it can be translated to Korean like this "ì–¸ì–´ ë³€ê²½ì„ ì›í•˜ì‹œë©´ %1%2 ì„ ëˆŒëŸ¬ì£¼ì„¸ìš”". Thus, %1 is object in this sentence, and some html code is in %2.
        "RETRY": qsTr("RETRY") + emptyString,  // i18n Button text means retrying voice recognition.
        "Network server is not Responding. Try again.": qsTr("Network server is not Responding. Try again.") + emptyString, // i18n error sentence
        "Voice is not recognized. Keep your distance from the remote control and speak again.": qsTr("Voice is not recognized. Keep your distance from the remote control and speak again.") + emptyString, // i18n error sentence
        "Try again after update is complete.": qsTr("Try again after update is complete.") + emptyString,  // i18n error sentence
        "Speech to text": qsTr("Speech to text") + emptyString, // i18n text for tts
// Add
        "Mic connection is unstable.": qsTr("Mic connection is unstable.") + emptyString,  // i18n error sentence

//webOS4.5
        "The function is not available in the current keyboard language.": qsTr("The function is not available in the current keyboard language.") + emptyString,  // i18n error sentence
        "None": qsTr("None") + emptyString,
        "Go to 'Settings'": qsTr("Go to 'Settings'") + emptyString,

//webOS5.0
        "Network connection unavailable. Would you like to go to Network Settings to check the connection?": qsTr("Network connection unavailable. Would you like to go to Network Settings to check the connection?") + emptyString,  // i18n error sentence


//webOS25
        "Down Button": qsTr("Down Button") + emptyString,
    }

}
