import QtQuick 2.6
import WebOSServices 1.0
Item {
    id: root;
    readonly property int _VOLUMERATE_100: 100 // full percentage for volume
    property int prevMediaVolume: _VOLUMERATE_100
    property int mediaVolume: 20                        // initial percentage for volume down
    property bool ready : false
    property var audio: []

    //properties from voiceagent GlobalVars//
    property int masterVolume: 25                       // Output volume to decrease input volume(default:25)
    property bool muted: false                          // Output mute status to decrease input volume(default:false)
    property bool adjustVolume: true

    Component.onCompleted: {
        masterVolumeGetVolume.callService({"subscribe":true});
    }

    function downMediaVolume() {
        readyChanged.disconnect(downMediaVolume);
        if(root.ready)
            setMediaVolumeDown();
            //setMediaVolume(true);
        else
            readyChanged.connect(downMediaVolume);
    }
    function upMediaVolume() {
        readyChanged.disconnect(upMediaVolume);
        if(root.ready)
            setMediaVolumeUp();
            //setMediaVolume(false);
        else
            readyChanged.connect(upMediaVolume);
    }

    function playStartSound() {
        callSystemSound("voicestart");
    }

    function playConfirmSound() {
        callSystemSound("voiceconfirm");
    }

    function playCancelSound() {
        callSystemSound("voicecancel");
    }

    function printConsole(text) {
        printLog("SFX::"+text);
    }

//----------------------------------------------------------------------------------------
    function setMediaVolumeDown() {
        printLog("MEDIA_VOLUME_SETTING_DOWN")
        getAudioStatus.callService({"subscribe":true});
    }

    function setMediaVolumeUp() {
        printLog("MEDIA_VOLUME_SETTING_UP.. audio" + JSON.stringify(root.audio))
        for (var i = 0; i < root.audio.length; i++) {
            var _audioItem = root.audio.pop();
            _audioItem.volume = _VOLUMERATE_100;
            mediaVolumeController.callService(_audioItem);
        }
        getAudioStatus.cancel();
    }

    function setMediaVolume(toDown)
    {
        printConsole("==========================================================");
        var tmpJson = {
            "toDown" : toDown,
            "root.masterVolume" : root.masterVolume,
            "root.muted" : root.muted,
            "root.adjustVolume" : root.adjustVolume,
            "root.mediaVolume" : root.mediaVolume
        }
        printLog("MEDIA_VOLUME_SETTING.." + JSON.stringify(tmpJson))
        var tempVolume = _VOLUMERATE_100;
        if(toDown && !root.adjustVolume) {
            tempVolume = 0;
        } else if (toDown && root.masterVolume > 5 && root.muted === false) {
            tempVolume = root.mediaVolume;
        }

        if (prevMediaVolume !== tempVolume) {
            printLog("MEDIA_VOLUME_SETTING.. volume" + tempVolume);
            mediaVolumeController.callService({"volume":tempVolume});
            prevMediaVolume = tempVolume;
        }
    }

    function callSystemSound(soundName) {
        printLog("PLAY_SOUND_EFFECT.. soundName" + soundName);
        systemSound.callService({"name": soundName ,"sink":"pfeedback", "play":true, "override":true});
    }

    /* Service : Media Volume Control */
    Service {
        id: mediaVolumeController
        appId: "com.webos.service.ime.stt"
        service: "com.webos.service.audio"
        method: "UMI/setInputVolume"
        onResponse : printLog("RESPONSE_SETINPUTVOLUME: "+payload)
    }

    Service {
        id: getAudioStatus;
        appId: "com.webos.service.ime.stt"
        service: "com.webos.service.audio"
        method: "UMI/getStatus"
        onResponse: {
            printLog("PIPELINE: "+payload)
            if ( payload !== undefined){
                var jsonObject = JSON.parse(payload);
                if (jsonObject.returnValue && jsonObject.audio && jsonObject.audio.length) {
                    root.audio = [];
                    for (var i = 0; i < jsonObject.audio.length; i++) {
                        var _audioItem = jsonObject.audio[i];
                        for (var j = 0; j < _audioItem.pipelineInfo.length; j++) { // [QEVENTTWEN-4053] pipelineInfo 배열 처리 및 sink check 추가
                            if (_audioItem.pipelineInfo[j].sourceSinkInfo[0] && (_audioItem.pipelineInfo[j].sourceSinkInfo[0].sink === "MAIN")) {
                                var _pipeline = {
                                    "pipelineId": _audioItem.pipelineInfo[0].pipelineId,
                                    "streamType": _audioItem.streamType,
                                };
                                root.audio.push(_pipeline);
                                printLog("AUDIO_PIPELINE_INFO" + JSON.stringify(_pipeline));
                                _pipeline.volume = 0;
                                mediaVolumeController.callService(_pipeline);
                            }
                        }
                    }
                }
                else
                    printConsole("\r\n Got error to get audio status");
            }
        }
    }

    Service {
        id: systemSound;
        appId: "com.webos.service.ime.stt"
        service: "com.webos.service.audio"
        method: "systemsounds/playFeedback"
        onError: {
            printConsole("onError():");
            console.trace();
        }
    }

    /* Service : Master Volume Control */
    Service { id: masterVolumeGetVolume; appId: "com.webos.service.ime.stt"
        service: "com.webos.service.audio"
        method: "master/getVolume"
        onResponse: {
            printConsole("GetVolume.response:" + payload)
            if ( payload !== undefined){
                var jsonObject = JSON.parse(payload);
                if (jsonObject.returnValue && jsonObject.volumeStatus) {
                    /*
                        volumeStatus object:
                        {
                            "muteStatus"  : <boolean>// Mute status for the sound output device is muted or not.(true = mute false = unmute)
                            "activeStatus": <boolean>// Indicate the sound output device is active or not
                            "volume"      : <int>    // current volume level, and valid volume range is 0-100
                            "soundOutput" : < string>// target sound output device
                            "adjustVolume": <boolean> // true for changing the volume level of the sound output device, otherwise false
                            "maxVolume":<int>//Maximum volume level of the soundoutput device
                            "cause":<string>//Indicates the cause for the change in volume. Possible values are volumeUp, volumeDown , setVolume and muteVolume
                        }
                    */
                    var _volumeStatus = jsonObject.volumeStatus
                    root.muted = _volumeStatus.muteStatus;
                    root.adjustVolume = _volumeStatus.adjustVolume;
                    if(/*globalVars.supportScreenRollerMotor ||*/ !_volumeStatus.adjustVolume)
                        root.mediaVolume = 0;
                    else if (_volumeStatus.adjustVolume && _volumeStatus.volume > 0 ) { // Do not divide to 0
                        root.masterVolume = _volumeStatus.volume;
                        root.mediaVolume = 400/root.masterVolume;
                        printConsole("mediaVolume:"+root.mediaVolume);
                    } else {
                        root.mediaVolume = 0;
                    }
                    root.ready = true;
                }
                else
                    printConsole("\r\n Got error to control master volume");
            }
        }
    }
}
