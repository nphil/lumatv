/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import WebOSServices 1.0

Item {
    property var languageList : []
    property var localeInfoList: [] // {"localeCode":localeCode,"localeText":localeText}
    property bool localeStringReady: false

    Component.onCompleted: {
        printLog("=== LocaleString onCompleted ===")
        printLog("=== LocaleString CALLE getLocaleLanguage ===")
        getLocaleLanguage()
    }

    function getSTTLangList(){

        console.log(" >>>>> getSTTLangList :: localeStringReady : "+localeStringReady)

        function retrunSTTlangList(){
            localeStringReadyChanged.disconnect(retrunSTTlangList)
            return languageList
        }

        if(localeStringReady)
            return languageList
        else{
            localeStringReadyChanged.connect(retrunSTTlangList)
        }
    }

    function printLocale(localeInfo) {
        var result = "";

        printLog("***********************************************************")
        printLog(" ***** getVoiceLanguage.sttCheckList : "+JSON.stringify(getVoiceLanguage.sttCheckList))
        printLog(" ***** localeInfo : "+localeInfo)

        if((localeInfo !=="notSupported") && (getVoiceLanguage.sttCheckList[localeInfo] === "notSupported"))
            return result;

        if(localeInfo ==="notSupported"){
            result = "notSupported";
        }else{
            for(var i=0; i< localeInfoList.length; i++){
                if(localeInfoList[i].localeCode == localeInfo){
                    result = localeInfoList[i].localeText
                    break;
                }
            }
        }

        return result;
    }
    function getLocaleLanguage() {
        getLocaleString.call("luna://com.webos.settingsservice", "/getSystemSettingValues" , "{\"key\":\"locale\"}")
    }

    Service {
        id: getLocaleString
        appId: "com.webos.service.ime.stt"
        onResponse: {
            printLog("=== getLocaleString onResponse ===");
            printLog("payload : " + payload);
            var jsonObject = JSON.parse(payload);
            var sttLocaleList = jsonObject.stt;

            printLog("for(var i = 0; i < sttLocaleList.length; i++){");
            for(var i = 0; i < sttLocaleList.length; i++){
                var langElement = sttLocaleList[i];
                printLog("langElement.languageCode : " + langElement.languageCode);
                printLog("langElement.name : " + langElement.name);
                var languageName = langElement.name;

                printLog("for(var j = 0; j < langElement.countries.length; j++ ) {");
                for(var j = 0; j < langElement.countries.length; j++ ) {
                    var country = langElement.countries[j];
                    printLog("country.spec: " + country.spec);
                    printLog("country.name: " + country.name);
                    var langCode;
                    if(country.spec == "cmn-Hans-CN") langCode = "zh-Hans-CN";
                    else if(country.spec == "yue-Hant-HK") langCode = "zh-Hant-HK";
                    else if(country.spec == "cmn-Hant-TW") langCode = "zh-Hant-TW";
                    else langCode = country.spec;

                    printLog("var langCode = country.spec; " + langCode);
                    var languageString =  languageName+ " - " +country.name;
                    printLog("var languageString = languageName" + "-" +"country.name; " + languageString);

                    setLocaleString(langCode, languageString)
                }
            }
            localeStringReady = true;
        }

        function setLocaleString(localeCode, localeText){
            printLog("=== setLocaleString ===");
            printLog("localeCode: " + localeCode);
            printLog("localeText: " + localeText);

            localeInfoList.push({"localeCode":localeCode,"localeText":localeText});
            languageList.push(localeCode);
        }
    }
}
