import QtQuick 2.12
import WebOSServices 1.0

LocaleService {
    id: localeService

    property bool isRTLLocale: false
    property bool isLoaded: false

    appId: "com.webos.service.ime.stt"
    l10nDirName: "/usr/share/qml/locales/imemanager"
    l10nFileNameBase: "imemanager"
    Component.onCompleted: {
        printWarningLog("L10N - localeService.Component.onCompleted:currentLocale=" + currentLocale);
        subscribeForLocaleChange();
    }

    onError: {
        printWarningLog("localeService.onError:errorText=" + errorText);
    }

    onL10nLoadSucceeded: {
        printWarningLog("localeService.onL10nLoadSucceeded");
    }

    onL10nLoadFailed: {
        printWarningLog("localeService.onL10nLoadFailed");
    }

    onL10nInstallSucceeded: {
        printWarningLog("localeService.onL10nInstallSucceeded");
        isLoaded = true
    }

    onL10nInstallFailed: {
        printWarningLog("localeService.onL10nInstallFailed");
    }

    onCurrentLocaleChanged: {
        printWarningLog("localeService.onCurrentLocaleChanged: " + currentLocale);
        if (currentLocale && (currentLocale.indexOf("he-") > -1 || currentLocale.indexOf("ar-") > -1 || currentLocale.indexOf("ur-") > -1 ||
                              currentLocale.indexOf("ku-") > -1 || currentLocale.indexOf("fa-") > -1)) {
            isRTLLocale = true;
        } else {
            isRTLLocale = false;
        }
    }
}
