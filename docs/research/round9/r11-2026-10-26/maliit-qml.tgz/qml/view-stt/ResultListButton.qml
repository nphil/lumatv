/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import QtGraphicalEffects 1.0

MouseArea {
    id: resultListButton
    objectName: "resultListButton"

    LayoutMirroring.enabled: Qt.locale(voiceLanguage).textDirection ? true : false
    LayoutMirroring.childrenInherit: Qt.locale(voiceLanguage).textDirection ? true : false
    width: sttStyle.resultButton.width
    height: sttStyle.resultButton.height
    hoverEnabled: true
    property alias text: resultListButtonText.text
    property string textToSpeech : resultListButtonText.text
    onEntered: {
        resultListButton.forceActiveFocus()
    }

    onExited: {
        resultListButton.parent.forceActiveFocus()
    }

    onReleased: {
        onReleasedAction()
    }

    onActiveFocusChanged: {
        if(activeFocus) {
            resultListButtonTextRec.myElide = Text.ElideNone;
            if(resultListButtonTextRec.myContentWidth > resultListButtonTextRec.width)
                textAni.restart();
            remainSeconds = 30;
        } else {
            textAni.stop();
            resultListButtonTextRec.myX = 0;
            resultListButtonTextRec.myElide = Text.ElideRight;
        }
    }

    Rectangle {
        id:btnRec
        anchors.fill: parent
        color: resultListButton.activeFocus? "#E6E6E6" : "transparent"
        radius: sttStyle.resultButton.radius
    }

    DropShadow{
        anchors.fill: btnRec
        visible: resultListButton.activeFocus
        color: sttStyle.shadowColor
        horizontalOffset: sttStyle.shadowHoffset
        verticalOffset: sttStyle.shadowVoffset
        radius: sttStyle.shadowRadius
        samples: sttStyle.shadowSamples
        source: btnRec
    }

    Rectangle {
        id: resultListButtonTextRec
        objectName: "resultListButtonTextRec"
        anchors.left: parent.left
        anchors.leftMargin: sttStyle.resultListButtonText.leftMargin
        width: parent.width - sttStyle.resultListButtonText.leftMargin * 2
        height: parent.height
        color: sttStyle.resultButton.bgColor
        clip: true

        property alias myX: resultListButtonText.x
        property alias myContentWidth: resultListButtonText.contentWidth
        property alias myElide: resultListButtonText.elide

        Text {
            id: resultListButtonText
            objectName: "resultListButtonText"
            anchors.verticalCenter: parent.verticalCenter
            width: parent.width
            text: ""
            font.pixelSize: sttStyle.resultButton.fontSize
            font.family: resultListButton.activeFocus? normal600_fontFamily : normal400_fontFamily
            font.weight: resultListButton.activeFocus? normal600_fontWeight : normal400_fontWeight
            color: resultListButton.activeFocus? sttStyle.resultButton.focusFontColor : sttStyle.resultButton.fontColor
            elide: Text.ElideRight
        }
    }

    SequentialAnimation {
        id: textAni
        objectName: "textAni"
        loops: Animation.Infinite
        PropertyAction { target: resultListButtonTextRec; property: "myX"; value: 0 }
        PauseAnimation { duration: 500 }
        PropertyAnimation {
            target: resultListButtonTextRec
            property: "myX"
            to: -resultListButtonTextRec.myContentWidth+resultListButtonTextRec.width
            duration: resultListButtonTextRec.myContentWidth - resultListButtonTextRec.width < 0 ? 0 : ((resultListButtonTextRec.myContentWidth - resultListButtonTextRec.width) * 10)
        }
        PauseAnimation { duration: 500 }
    }

    function onReleasedAction() {
        if(resultListButton.text) {
            textKeyPressed(resultListButton.text);
            main.state = 'init';
        }
    }
}
