import QtQuick 2.12

Item {

    id: root

    property Flickable flickable: null
    property real xVelocity: horizontalLayout ? 1500 : 0
    property real yVelocity: horizontalLayout ? 0 :1500
    property bool horizontalLayout: false
    property bool effectEnabled: flickable && (horizontalLayout ? flickable.contentWidth > flickable.width : flickable.contentHeight > flickable.height)
    property bool atBeginning: horizontalLayout ? flickable.atXBeginning : flickable.atYBeginning
    property bool atEnd: horizontalLayout ? flickable.atXEnd : flickable.atYEnd

    signal wheel(var angleDelta)

    onWheel: {
        if (effectEnabled) {
            if (isCursorOn && !flickable.flicking) {
                if (atBeginning && angleDelta.y > 0) {
                    flickable.boundsBehavior = Flickable.OvershootBounds;
                    flickable.flick(root.xVelocity, root.yVelocity);
                } else if (atEnd && angleDelta.y < 0) {
                    flickable.boundsBehavior = Flickable.OvershootBounds;
                    flickable.flick(root.xVelocity*-1, root.yVelocity*-1);
                }
            }
        }
    }

    anchors {
        top: flickable.top
        left: flickable.left
        bottom: flickable.bottom
        right: flickable.right
    }

    Connections {
        target: flickable
        onFlickingChanged: {
            if (!flickable.flicking) {
                flickable.boundsBehavior = Flickable.StopAtBounds;
            }
        }
    }

    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.RightButton
        onWheel: {
            parent.wheel(wheel.angleDelta);
            wheel.accepted = false;

            if (flickable.flicking) {
                if (root.atBeginning && wheel.angleDelta.y > 0) {
                    wheel.accepted = true;
                } else if (root.atEnd && wheel.angleDelta.y < 0) {
                    wheel.accepted = true;
                }
            }
        }
    }
}
