/* @@@LICENSE
 *
 * Copyright (c) 2019 LG Electronics, Inc.
 *
 * Confidential computer software. Valid license from LG required for
 * possession, use or copying. Consistent with FAR 12.211 and 12.212,
 * Commercial Computer Software, Computer Software Documentation, and
 * Technical Data for Commercial Items are licensed to the U.S. Government
 * under vendor's standard commercial license.
 *
 * LICENSE@@@ */

import QtQuick 2.6
import QtGraphicalEffects 1.0

Rectangle {

    id: root

    property bool playing: false
    property bool useAntialiasing: true
    property bool useSmooth: true

    width: 75
    height: 75
    color: "transparent"
    visible: root.playing

    Rectangle {

        id: container

        anchors.centerIn: parent

        width: root.width
        height: width

        radius: width / 2
        color: "#383838"

        antialiasing: root.useAntialiasing
        smooth: root.useSmooth

        Rectangle {

            id: track

            anchors.centerIn: parent

            width: root.width * 0.8
            height: width

            radius: width / 2
            color: "#565656"

            antialiasing: root.useAntialiasing
            smooth: root.useSmooth
        }

        ConicalGradient {

            id: grad

            property real timeIdx: (result.rotation) / 360
            property real shift: {
                if(timeIdx < 0.8) {
                    return 0.95 + 0.3 * Math.sin(Math.PI * timeIdx - Math.PI);
                } else {
                    return 0.95;
                }
            }

            antialiasing: root.useAntialiasing
            smooth: root.useSmooth
            cached: true
            visible: false

            Behavior on shift {

                enabled: grad.timeIdx > 0.5

                NumberAnimation {
                    duration: rot.duration * 0.4
                    easing.type: Easing.InSine
                }
            }

            anchors.centerIn: parent

            width: root.width
            height: width

            gradient: Gradient {
                GradientStop { position: grad.shift - 0.08 * 1/grad.shift; color: Qt.rgba(1,1,1,0) }
                GradientStop { position: grad.shift; color: Qt.rgba(1,1,1,0.3) }
                GradientStop { position: 0.95; color: Qt.rgba(1,1,1,0.8) }
                GradientStop { position: 1.0; color: Qt.rgba(1,1,1,1) }
            }

            Rectangle {

                width: root.width * 0.057
                height: width

                radius: width / 2
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.top: parent.top
                anchors.topMargin: root.width * 0.111

                antialiasing: root.useAntialiasing
                smooth: root.useSmooth
            }
        }

        Rectangle {

            id: opMask

            anchors.centerIn: parent
            width: grad.width * 0.9
            height: width
            radius: width / 2
            visible: false
            antialiasing: root.useAntialiasing
            smooth: root.useSmooth
        }

        OpacityMask {

            id: result

            anchors.centerIn: parent
            width: opMask.width
            height: opMask.height
            source: grad
            maskSource: opMask
            antialiasing: root.useAntialiasing
            smooth: root.useSmooth
            cached: true

            RotationAnimation on rotation {

                id: rot

                running: root.playing

                loops: Animation.Infinite
                from: 30
                to: 330
                direction: RotationAnimation.Clockwise
                duration: 1300
                easing.type: Easing.OutSine
            }
        }

        RotationAnimation on rotation {

            running: root.playing

            loops: Animation.Infinite
            from: 330
            to: 30
            direction: RotationAnimation.Clockwise
            duration: rot.duration
            easing.type: Easing.Linear
        }
    }

    Rectangle {

        id: mask1

        anchors.centerIn: parent

        width: root.width
        height: width

        radius: width / 2

        color: "transparent"

        border.width: root.width * 0.15
        border.color: "#383838"

        antialiasing: root.useAntialiasing
        smooth: root.useSmooth
    }

    Rectangle {

        id: mask2

        anchors.centerIn: parent

        width: Math.ceil(root.width * 0.6)
        height: width

        radius: width / 2
        color: "#383838"

        antialiasing: root.useAntialiasing
        smooth: root.useSmooth
    }

    function play() {
        root.playing = true;
    }

    function stop() {
        root.playing = true;
    }
}
