/* @@@LICENSE
*
*      Copyright (c) 2013-2014 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "/usr/share/javascript/language-style/language-style.js" as LanguageStyle

QtObject {
    property real ratio: {
        if(resolution === "uhd")
            return 2;
        else if (resolution === 'qhd')
            return 4/3;
        else if(resolution === "fhd")
            return 1;
        else
            return 2/3;
    }
    property var fontFamily: QtObject {
        property string museo300: "Museo SansNormal"
        property string museo500: "Museo SansDemiBold"
        property string miso_bold: "Moon Miso Bold"
    }

    property int radiusVal : 6 * ratio
    property int shadowHoffset: 0
    property int shadowVoffset: 20 * ratio
    property int shadowRadius : 12 * ratio
    property int shadowSamples : ((shadowRadius*2)+1)
    property color shadowColor: "#4D000000"

    property var main: QtObject {
        property color color: "transparent"
        property color bgColor: "#3B4045"
        property real opacity: 1.0
        property int width:  (isPortraitMode? 1080: 1920) * ratio
        property int height:  438 * ratio
    }

    property var mic: QtObject {
        property int width: 293 * ratio
        property int height: 190 * ratio
        property color bgColor: "transparent"
        property color focusedColor: "#cf0652"
        property int micBorderWidth: 148 * ratio
        property int micImageHeight: 144 * ratio
        property int micErrorImageHeight: 144 * ratio
        property int bottomMargin: 65 * ratio
    }

    property var micBackground: QtObject {
        property int height: 144 * ratio//190 * ratio
        property color bgColor: "#000000"
    }

    property var langSelectBox: QtObject {
        property int height: 380 * ratio
        property color bgColor: "#575E66"//"#dfdfdf"
        property color fontColor: "#E6E6E6"//"#4d4d4d"
        property color lineColor: "#E6E6E6"//"#4d4d4d"
        property real bgOpacity: 0.9
    }

    property var langSelectButtonOk: QtObject {
        property int height: 54 * ratio
        property int topMargin: 26 * ratio
        property int rightMargin: 54 * ratio
        property int sideImgWidth: 50 * ratio
    }

    property var langSelectButtonCancel: QtObject {
        property int height: 54 * ratio
        property int topMargin: 26 * ratio
        property int rightMargin: 21 * ratio
        property int sideImgWidth: 50 * ratio
    }

    property var langSelectTitle: QtObject {
        property int topMargin: 25 * ratio
        property int leftMargin: 54 * ratio
        property int rightMargin: 54 * ratio
        property int fontSize: 45 * ratio
        property color fontColor: "#E6E6E6"//"#4d4d4d"
        property int lineTopMargin: 67 * ratio
        property int lineWidth: 1840 * ratio
        property int lineHeight: 1 * ratio
        property color lineColor: "#E6E6E6"//"#4d4d4d"
    }

    property var langSelectListView: QtObject {
        property int topMargin: 9 * ratio
        property int bottomMargin: 10 * ratio
        property int leftMargin: 49 * ratio
        property int rightMargin: 54 * ratio
        property int spacing: 0 * ratio
    }

    property var langSelectListItem: QtObject {
        property int itemImgleftMargin: 10 * ratio
        property int height: 78 * ratio
        property int itemTextLeftMargin: 10 * ratio
        property int itemTextRightMargin: 10 * ratio
        property int fontSize: 30 * ratio
        property color fontColor: "#E6E6E6"//"#4d4d4d"
        property color focusFontColor: "#4C5059"//"#ffffff"
        property int imgWidth: 30 * ratio //22 * ratio
        property int radius: 6 * ratio
        property color unSelectedNormalColor: "#E6E6E6"
        property color unSelectedFocusColor: "#4C5059"
        property color unSelectedBgColor: "transparent"
        property int unSelectedborderWidth: 2 * ratio
        property color selectedBgColor: "#E6E6E6"
        property color selectedborderColor: "#30AD6B"
        property int selectedborderWidth: 7 * ratio
        property int shadowHeight : 20 * ratio
        property int itemRecleftMargin: 5 * ratio
    }

    property var langSelectListScrollBar: QtObject {
        property int topMargin: 9 * ratio
        property int bottomMargin: 10 * ratio
        property int rightMargin: 36 * ratio
        property int width: 18 * ratio
        property int height: 219 * ratio
        property int barTopMargin: 10 * ratio
        property int barBottomMargin: 27 * ratio
        property int barWidth: 6 * ratio
        property int barRadius: 3 * ratio
        property color barBgColor: "#41464C"
        property color barColor: "#7E848C"
    }

    property var guideImage: QtObject {
        property int rightMargin: 15 * ratio
    }

    property var guideText: QtObject {
        property int leftMargin: 15 * ratio
        property int rightMargin: 15 * ratio
        property int topMarginReady: 65 * ratio//71 * ratio
        property int topMarginInitError: 70 * ratio
        property int bottomMargin: 5 * ratio
        property int fontSize: 33 * ratio
        property color fontColor: "#ffffff"
    }

    property var guideRetryButton: QtObject {
        property int topMargin: 24 * ratio
        property int rightMargin: 40 * ratio
    }
    property var guideLangText: QtObject {
        property int topMargin: 115 * ratio//128 * ratio
        property int fontSize: 30 * ratio
        property color fontColor: "#ffffff"
        property int keyHelpImgLeftMargin: 10 * ratio
        property int keyHelpImgRightMargin: 15 * ratio
    }

    property var resultListBox: QtObject {
        property int height: 364 * ratio
        property color bgColor: "#575E66"//"#dfdfdf"
        property real bgOpacity: 0.9
    }

    property var resultTitle: QtObject {
        property int topMargin: 30 * ratio
        property int leftMargin: 54 * ratio
        property int rightMargin: 54 * ratio
        property int fontSize: 45 * ratio
        property color fontColor: "#E6E6E6"//"#4d4d4d"
        property int lineTopMargin: 67 * ratio
        property int lineHeight: 1 * ratio//2 * ratio
        property color lineColor: "#E6E6E6"

    }
    property var resultButton: QtObject {
        property color bgColor: "transparent"
        property int lineMargin: 9 * ratio//30 * ratio
        property int spacing: 0 * ratio//9 * ratio
        property int width: 1662 * ratio
        property int height: 78 * ratio
        property int leftMargin: 54 * ratio
        property int rightMargin: 54 * ratio
        property int fontSize: 30 * ratio
        property color fontColor: "#E6E6E6"//"#4d4d4d"
        //property int textLeftMargin: 24 * ratio
        property color focusFontColor: "#4C5059"//"#ffffff"
        //property int focusTextLeftMargin: 10 * ratio
        //property int focusBorderWidth: 6 * ratio//5 * ratio
        //property color focusBorderColor: "#ff2f7d"
        property color exitColor: "transparent"
        property int radius: radiusVal
    }

    property var resultListButtonText: QtObject {
        property int leftMargin: 24 * ratio
    }

    property var sayAgainButton: QtObject {
        property color bgColor: "transparent"
        property int height: 54 * ratio
        property int rightMargin: 54 * ratio
        property int bottomMargin: 26 * ratio
        property int topMargin: 33 * ratio
        property int fontSize: 30 * ratio //33 * ratio
        property color fontColor: "#E6E6E6"//"#cccccc"
        property color focusFontColor: "#4C5059"//"#ffffff"
        property int sideImgWidth: 50 * ratio
        property int sidePadding: 24 * ratio //21 * ratio
        property int smallMinWidth: 180 * ratio
        property int radius: 6 * ratio //3 * ratio
        property color normalColor: "#7D848C"//"#383838"
        property color focusedColor: "#E6E6E6"//"#cf0652"
        property int sidefocusWidth: 27 * ratio

    }

    property var seperateLine: QtObject {
        property int initialLineTopMargin: 106 * ratio
        property int rightMargin: 60 * ratio
        property int width: 640 * ratio
        property int height: 1 * ratio
        property int boldHeight: 4 * ratio
        property color color: "#ffffff"
        property color boldColor: "#717171"
        property real opacity: 0.3
        property real boldOpacity: 1
    }

    property var spinner: QtObject {
        property int diameter: 73 * ratio
    }


    function reloadFontFamily(currentLanguage) {
        console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+currentLanguage)
        var style;
        try {
            style = LanguageStyle.getStyle(currentLanguage);
        } catch (e) {
            console.warn("invalid lang value");
            style = LanguageStyle.getStyle("en-GB");
        }

        normal300_fontFamily = style.normal300.fontFamily[0];
        normal300_fontWeight = style.normal300.qmlWeight;
        normal400_fontFamily = style.normal400.fontFamily[0];
        normal400_fontWeight = style.normal400.qmlWeight;
        normal600_fontFamily = style.normal600.fontFamily[0];
        normal600_fontWeight = style.normal600.qmlWeight;
        normal700_fontFamily = style.normal700.fontFamily[0];
        normal700_fontWeight = style.normal700.qmlWeight;

        console.log("reloadFontFamily: "+currentLanguage);
        console.log("normal300_fontFamily: "+ normal300_fontFamily);
        console.log("normal300_fontWeight: "+ normal300_fontWeight);
        console.log("normal400_fontFamily: "+ normal400_fontFamily);
        console.log("normal400_fontWeight: "+ normal400_fontWeight);
        console.log("normal600_fontFamily: "+ normal600_fontFamily);
        console.log("normal600_fontWeight: "+ normal600_fontWeight);
        console.log("normal700_fontFamily: "+ normal700_fontFamily);
        console.log("normal700_fontWeight: "+ normal700_fontWeight);
    }
}
