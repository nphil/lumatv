/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import QtGraphicalEffects 1.0

MouseArea {
    id: sayAgainButtonRec
    objectName: "sayAgainButtonRec"
    property string textToSpeech : sayAgainButtonText.text + " " + stringSet.strings["button"]
    LayoutMirroring.enabled: main.isRTL
    width: Math.max(sayAgainButtonText.width + sttStyle.sayAgainButton.sidePadding*2, sttStyle.sayAgainButton.smallMinWidth) /*+ (sayAgainButtonRec.activeFocus ? sttStyle.sayAgainButton.sidefocusWidth*2 : 0)*/
    height: (sayAgainButtonRec.activeFocus ? sttStyle.sayAgainButton.height /** 1.2*/ : sttStyle.sayAgainButton.height)
    hoverEnabled: true

    onEntered: sayAgainButtonRec.forceActiveFocus()

    onExited: sayAgainButtonRec.parent.forceActiveFocus()

    onPressed: onPressedAction()
    onReleased: onReleasedAction()

    onActiveFocusChanged: if(activeFocus) remainSeconds = 30

    // UI VARIABLES. PARENT CAN CHANGE UI USING THESE VARIABLES
    property string textFontColor : sttStyle.sayAgainButton.fontColor
    property string textFontFocusColor : sttStyle.sayAgainButton.focusFontColor

    Keys.onPressed: {
        if (event.key === extKey.key_return) {
            onPressedAction();
        }
    }

    Rectangle {
        id: buttonRec
        anchors.centerIn: parent
        width: sayAgainButtonRec.activeFocus?parent.width*1.2 : parent.width
        height: sayAgainButtonRec.activeFocus?parent.height*1.2 : parent.height
        radius: sttStyle.sayAgainButton.radius
        color: sayAgainButtonRec.activeFocus ? sttStyle.sayAgainButton.focusedColor : sttStyle.sayAgainButton.normalColor
    }

    DropShadow{
        anchors.fill: buttonRec
        visible: sayAgainButtonRec.activeFocus
        color: sttStyle.shadowColor
        horizontalOffset: sttStyle.shadowHoffset
        verticalOffset: sttStyle.shadowVoffset
        radius: sttStyle.shadowRadius
        samples: sttStyle.shadowSamples
        source: buttonRec
    }

    Text {
        id: sayAgainButtonText
        objectName: "sayAgainButtonText"
        anchors.centerIn: parent
        text: {
            if(main.state === "event_changekeyboardLang" || main.state === "event_networkdisconnection")
                return stringSet.strings["Go to 'Settings'"]
            else
                return stringSet.strings["RETRY"]// i18n Button text means retrying voice recognition.
        }
        font.pixelSize: sttStyle.sayAgainButton.fontSize
        font.family: sayAgainButtonRec.activeFocus ? normal600_fontFamily : normal400_fontFamily
        font.weight: sayAgainButtonRec.activeFocus ? normal600_fontWeight : normal400_fontWeight
        font.capitalization: Font.AllUppercase
        color: sayAgainButtonRec.activeFocus ? textFontFocusColor : textFontColor
    }

    function onPressedAction(){
    }

    function onReleasedAction() {
        if(main.state === "event_changekeyboardLang" || main.state === "event_networkdisconnection")
        {
            main.launchSettings();
        }
        else{
            main.forceActiveFocus();
            main.restartSttService();
        }
    }
}
