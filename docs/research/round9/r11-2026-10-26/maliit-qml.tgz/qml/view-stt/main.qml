/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.4
import QtQuick.Window 2.2

import WebOSServices 1.0
import QtGraphicalEffects 1.0

Rectangle {
    id: main
    objectName: "main"
    color: sttStyle.main.color
    visible: true

    signal textKeyPressed(string text)
    signal backToKeyboardPressed()
    signal canShowSTTView()
    signal sigSendText(string text)
    signal sigSendWarningText(string text)

    property string resolution: {
        if(WindowInformation.windowHeight >= 876)
            return "uhd"
        else if(WindowInformation.windowHeight >= 584)
            return "qhd"
        else if(WindowInformation.windowHeight >= 438)
            return "fhd"
        else
            return "hd"
    }
    property variant resultTextArray
    property int resultNum: 0
    property int num: 0
    property bool isShow: false
    property string currentLanguage
    property string languageParam
    property string voiceLanguage // STT Language by settings -> General -> Language -> Voice Recognition Language
    property string selectedLanguage: ""
    property int remainSeconds: 30 //storing remain seconds. default sec is 30.
    property bool translateLoaded: localeServiceLoader.isLoaded

    //variables for master volume control
    property double timeToShow:0
    property bool isCursorOn: false
    property bool isLanguagedChanged: false

    property WebOSKeyExtension extKey: WebOSKeyExtension {
        id: extKey
    }

    property bool isActivated: false
    property string startSTT_state: ""
    property string voiceTicket: ""

    /* Global variable: Fonts */
    // LG Smart UI
    property string normal300_fontFamily: "LG Smart UI"
    property int    normal300_fontWeight: Font.Light
    property string normal400_fontFamily: "LG Smart UI"
    property int    normal400_fontWeight: Font.Medium
    property string normal600_fontFamily: "LG Smart UI"
    property int    normal600_fontWeight: Font.DemiBold
    property bool   normal600_fontItalic : false
    property string normal700_fontFamily: "LG Smart UI"
    property int    normal700_fontWeight: Font.Bold

    // RTL case check variable QT.locale().textDirection -> LTR: 0, RTL: 1
    property bool isRTL: Qt.locale((selectedLanguage && selectedLanguage !== "notSupported") ? selectedLanguage : getSystemSettings.menuLanguage).textDirection ? true : false

    // DEBUG
    readonly property bool _DEBUG: true

    //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
    LayoutMirroring.enabled: isRTL

    // FOREGROUND APP ID
    property string cardTypeForegroundAppId: ""         // foreground appID of Card Type Window
    property string anyTypeForegroundAppId: ""          // foreground appID of Any Type Window

    property alias supportPortrait: configService.supportPortrait
    property alias orientation: mscService.orientation
    property alias screenRotation: mscService.screenRotation
    property bool isPortraitMode: {
        return (main.orientation.indexOf("portrait") > -1 ? true : false)
    }

    onSupportPortraitChanged: {
        if (supportPortrait) {
            mscService.callService({"subscribe":true});
        }
    }

    SttStyle {
        id: sttStyle
    }

    StringSet { id: stringSet; emptyString: localeServiceLoader.emptyString }

    TTSService{ id : ttsService
        Component.onCompleted: {
            callGetSystemSettings() // Enabled from webOS3.0 MR Major
        }
    }

    SoundEffectManager { id: soundEffectManager }
    /* C++ Instatance
                PluginProxy             - Class STTView
                WindowInformation       - Class WindowInformation
    */

    onIsShowChanged: {
        printWarningLog("$$$$$$$$$$$$$$isPortraitMode: "+isPortraitMode);
        printWarningLog("$$$$$$$$$$$$$$mscService.orientation: "+mscService.orientation);
        printWarningLog("$$$$$$$$$$$$$$windowWidth: "+WindowInformation.windowWidth+", windowHeight: "+WindowInformation.windowHeight);
        printWarningLog("====================== STATUS MONITOR ============================");
        printWarningLog("main.resolution: " + main.resolution);
        printWarningLog("main.isShow: " + main.isShow);
        printWarningLog("main.state: " + main.state);
        printWarningLog("startSTT state: " + startSTT_state); // sttResult, sessionEnd
        printWarningLog("WindowInformation.windowWidth: " + WindowInformation.windowWidth); // sttResult, sessionEnd
        printWarningLog("WindowInformation.windowHeight: " + WindowInformation.windowHeight); // sttResult, sessionEnd

        printLog("==================================================================");
        if (!main.isShow) {
            resultListButton1.text = "";
            resultListButton2.text = "";
            resultListButton3.text = "";
            guideText.text = "";
            resultTextArray = undefined;
            sayAgainButton.opacity = 0;
            checkingRemainingTimeTimer.stop();
            if(needCancelAPI())
            {
                var param = {
                    "voiceTicket": voiceTicket
                };
                printWarningLog("nlp cancel is called.   startSTT_state: " + startSTT_state);
                printWarningLog("nlp cancel is called.   voiceTicket: " + voiceTicket);
                param = JSON.stringify(param);
                sttCancelService.call("luna://com.webos.service.voiceconductor","/cancelRecognition",param);
                sttService.cancel();
            }

            //Volume Restored
            printLog("\r\nVolume Restored to 100");
            soundEffectManager.upMediaVolume();

            selectedLanguage = "";
            langSelectListModel.clear();
            isActivated = false;
            startSTT_state = "";
            main.state = "init";
            main.forceActiveFocus();
            voiceTicket = ""
            getVoiceLanguage.voiceLanguage = "";
            voiceLanguage = "";
            localeString.localeStringReady = false;
            localeString.languageList = [];
            localeString.localeInfoList = [];
        } else {
            timeToShow = Date.now();
            main.state = "init";
            getVoiceLanguage.voiceLanguage = "";
            startSTTPlugin();
        }
    }
    onCurrentLanguageChanged: {
        printLog("=== onCurrentLanguageChanged ===")
        printLog("currentLanguage: " + currentLanguage)
        sttStyle.reloadFontFamily(currentLanguage) // do job to load font here
        updateGuideLangText();
    }
    onSelectedLanguageChanged: {
        printWarningLog("=== onSelectedLanguageChanged ===")
        printWarningLog("selectedLanguage: " + selectedLanguage)
        printWarningLog("WindowInformation.windowWidth: " + WindowInformation.windowWidth); // sttResult, sessionEnd
        printWarningLog("WindowInformation.windowHeight: " + WindowInformation.windowHeight); // sttResult, sessionEnd

        if (selectedLanguage !== "notSupported"){
            localeServiceLoader.changeCurrentLocale(selectedLanguage)
        }
    }
    onVoiceLanguageChanged: { // this is called only when STT plugin is activated
        printLog("voiceLanguage : " + voiceLanguage);
    }

    LocaleString {
        id: localeString
    }

    Timer {
        id: checkingRemainingTimeTimer
        interval: 1000; running: false; repeat: true
        onTriggered: {
            remainSeconds--;
            printLog("remainSeconds : " + remainSeconds);
            if(remainSeconds === 0) {
                running = false;
                backToKeyboardPressed();
            }
        }
    }

    Loader {
        id: localeServiceLoader

        property bool isLoaded: false
        property var emptyString: item.emptyString

        onLoaded: {
            printWarningLog('LocaleServiceFile is loaded')
            isLoaded = true
        }

        function changeCurrentLocale(locale){
            item.currentLocale = locale
        }
    }

    Rectangle{
        id: mainBg
        anchors.left: parent.left
        width: sttStyle.main.width
        height: sttStyle.main.height
        color: "transparent"

        Rectangle {
            id:bgRec
            anchors{
                bottom: parent.bottom
                horizontalCenter: parent.horizontalCenter
            }
            width: parent.width
            height: sttStyle.main.height
            color: sttStyle.main.bgColor
            radius: sttStyle.radiusVal
            opacity: sttStyle.main.opacity
        }

        DropShadow {
                anchors.fill: bgRec
                source: bgRec
                color: sttStyle.shadowColor
                horizontalOffset: sttStyle.shadowHoffset
                verticalOffset: sttStyle.shadowVoffset
                radius: sttStyle.shadowRadius
                samples: sttStyle.shadowSamples
                visible: bgRec.visible
        }

        /* RESULT LIST */
        Item {
            id: resultListBox
            objectName: "resultListBox"
            anchors.fill: bgRec
            width: bgRec.width
            height: bgRec.height
            visible: false

            function focusInit () {
                printLog("=== resultListBox focusInit() ===");
                printLog("isCursorOn: " + isCursorOn)
                focusOut();
            }
            function focusOut() {
                if(ttsService.audioGuidanceEnable || !isCursorOn)
                    resultListButton1.forceActiveFocus();
            }

            Rectangle {
                id:resultListBoxBgRec
                anchors.fill: parent
                color: sttStyle.resultListBox.bgColor
                opacity: sttStyle.resultListBox.bgOpacity
                radius: sttStyle.radiusVal
            }

            DropShadow {
                    anchors.fill: resultListBoxBgRec
                    source: resultListBoxBgRec
                    color: sttStyle.shadowColor
                    horizontalOffset: sttStyle.shadowHoffset
                    verticalOffset: sttStyle.shadowVoffset
                    radius: sttStyle.shadowRadius
                    samples: sttStyle.shadowSamples
                    visible: resultListBoxBgRec.visible
            }

            Text {
                id: resultTitle
                objectName: "resultTitle"
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.leftMargin: sttStyle.resultTitle.leftMargin
                anchors.topMargin: sttStyle.resultTitle.topMargin
                font.pixelSize: sttStyle.resultTitle.fontSize
                font.family: normal400_fontFamily
                font.weight: normal400_fontWeight
                color: sttStyle.resultTitle.fontColor
                text: stringSet.strings["VOICE RECOGNITION RESULTS"]
                opacity: 1
                //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
                LayoutMirroring.enabled: isRTL
                property string textToSpeech : ""
                onVisibleChanged: {
                    if(visible) {
                        var result = text;
                        result += ", " + resultListButton1.text;
                        if(resultListButton2.text)
                            result += ", " + resultListButton2.text;
                        if(resultListButton3.text)
                            result += ", " + resultListButton3.text;
                        textToSpeech = result;
                    }
                }
            }

            Rectangle {
                id: resultTitleLine
                objectName: "resultTitleLine"
                anchors.top: resultTitle.bottom
                anchors.topMargin: sttStyle.resultTitle.lineTopMargin
                anchors.left: parent.left
                anchors.leftMargin: sttStyle.resultTitle.leftMargin
                anchors.right: parent.right
                anchors.rightMargin: sttStyle.resultTitle.rightMargin
                height: sttStyle.resultTitle.lineHeight
                color: sttStyle.resultTitle.lineColor

                //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
                LayoutMirroring.enabled: isRTL
            }

            ResultListButton {
                id: resultListButton1
                objectName: "resultListButton1"
                anchors.top: resultTitleLine.bottom
                anchors.left: parent.left
                anchors.topMargin: sttStyle.resultButton.lineMargin
                anchors.leftMargin: sttStyle.resultButton.leftMargin
                anchors.right: parent.right
                anchors.rightMargin: sttStyle.resultButton.rightMargin
                text: ""
                opacity:1
                onActiveFocusChanged: {
                    if(activeFocus) {
                        if(resultTitle.textToSpeech) {
                            ttsService.speakByAudioGuidance(resultTitle.textToSpeech,currentLanguage);
                            resultTitle.textToSpeech = "";
                        } else
                            ttsService.speakByAudioGuidance(textToSpeech,currentLanguage);
                    }
                }
                Keys.onReleased: {
                    printLog("=== resultListButton1 Keys.onReleased: === " + event.key)
                    switch(event.key){
                    case extKey.key_up:     // UP
                        sayAgainButton.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_right:  // RIGHT -> LTR : sayAgainButton, RTL: OWN
                        if(!isRTL) // normal(LTR) case
                            sayAgainButton.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_down:   // DOWN -> resultListButton2
                        if(resultListButton2.opacity)
                            resultListButton2.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_left:   // LEFT -> LTR: OWN.  RTL: sayAgainButton
                        if(isRTL) // RTL case
                            sayAgainButton.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_return:
                        resultListButton1.onReleasedAction();
                        event.accepted = true;
                        break;
                    }
                }
            }


            ResultListButton {
                id: resultListButton2
                objectName: "resultListButton2"
                anchors.top: resultListButton1.bottom
                anchors.left: parent.left
                anchors.topMargin: sttStyle.resultButton.spacing
                anchors.leftMargin: sttStyle.resultButton.leftMargin
                anchors.right: parent.right
                anchors.rightMargin: sttStyle.resultButton.rightMargin
                text: ""
                opacity:0
                onActiveFocusChanged:if(activeFocus)ttsService.speakByAudioGuidance(textToSpeech,currentLanguage)
                Keys.onReleased: {
                    printLog("=== resultListButton2 Keys.onReleased: === " + event.key)
                    switch(event.key){
                    case extKey.key_up:     // UP -> resultListButton1
                        resultListButton1.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_down:   // DOWN -> resultListButton3
                        if(resultListButton3.opacity)
                            resultListButton3.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_left:   // LEFT -> LTR: OWN, RTL: sayAgainButton
                        if(isRTL) // RTL case
                            sayAgainButton.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_right:  // RIGHT -> LTR : sayAgainButton, RTL: OWN
                        if(!isRTL) // normal(LTR) case
                            sayAgainButton.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_return:
                        onReleasedAction();
                        event.accepted = true;
                        break;
                    }
                }
            }

            ResultListButton {
                id: resultListButton3
                objectName: "resultListButton3"
                anchors.top: resultListButton2.bottom
                anchors.left: parent.left
                anchors.topMargin: sttStyle.resultButton.spacing
                anchors.leftMargin: sttStyle.resultButton.leftMargin
                anchors.right: parent.right
                anchors.rightMargin: sttStyle.resultButton.rightMargin
                text: ""
                opacity:0
                onActiveFocusChanged:if(activeFocus)ttsService.speakByAudioGuidance(textToSpeech,currentLanguage)
                Keys.onReleased: {
                    printLog("=== resultListButton3 Keys.onReleased: === " + event.key)
                    switch(event.key){
                    case extKey.key_up:     // UP -> resultListButton2
                        resultListButton2.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_left:   // LEFT -> LTR: OWN, RTL: sayAgainButton
                        if(isRTL) // RTL case
                            sayAgainButton.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_right:  // RIGHT -> LTR : sayAgainButton, RTL: OWN
                        if(!isRTL) // normal(LTR) case
                            sayAgainButton.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_down:   // DOWN -> resultListButton3
                        resultListButton3.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_return:
                        onReleasedAction();
                        event.accepted = true;
                        break;
                    }
                }
            }


            SayAgainButton {
                id: sayAgainButton
                objectName: "sayAgainButton"
                anchors.top: parent.top
                anchors.right: parent.right
                anchors.topMargin: sttStyle.sayAgainButton.topMargin
                anchors.rightMargin: sttStyle.sayAgainButton.rightMargin
                opacity:0

                onActiveFocusChanged:if(activeFocus)ttsService.speakByAudioGuidance(textToSpeech,currentLanguage)
                Keys.onReleased: {
                    printLog("=== sayAgainButton Keys.onReleased: === " + event.key)
                    switch(event.key){
                    case extKey.key_up:     // UP
                        forceActiveFocus()
                        event.accepted = true;
                        break;
                    case extKey.key_down:   // DOWN
                        resultListButton1.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_left:   // LEFT -> LTR: resultListButton1. RTL -> OWN
                        if(!isRTL)
                            resultListButton1.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_right:  // RIGHT -> LTR: OWN, RTL: resultListButton1
                        if(isRTL)
                            resultListButton1.forceActiveFocus();
                        break;
                    case extKey.key_return:
                        sayAgainButton.onReleasedAction();
                        event.accepted = true;
                        break;
                    }
                }
            }
            Keys.onReleased: {
                printLog("=== resultBox Keys.onReleased: === " + event.key)
                switch(event.key){
                case extKey.key_up:
                    sayAgainButton.forceActiveFocus()
                    event.accepted = true;
                    break;
                case extKey.key_right:
                    if(isRTL) {
                        resultListButton1.forceActiveFocus();
                    } else {
                        sayAgainButton.forceActiveFocus();
                    }
                    event.accepted = true;
                    break;
                case extKey.key_down:
                    resultListButton1.forceActiveFocus();
                    event.accepted = true;
                    break;
                case extKey.key_left:
                    if(isRTL) {
                        sayAgainButton.forceActiveFocus();
                    } else {
                        resultListButton1.forceActiveFocus();
                    }
                    event.accepted = true;
                    break;
                }
            }
        }

        MicImage {
            id: micRec
            objectName: "micRec"
            anchors{
                bottom: bgRec.bottom
                bottomMargin: sttStyle.mic.bottomMargin
            }
            opacity:1
            property string textToSpeech : stringSet.strings["Speech to text"] + " " + stringSet.strings["button"]
            onEntered: {
                printLog("=== micRec's onEntered ===")
                if(main.state === "event_error") {
                    micRec.forceActiveFocus()
                }
            }
            onExited: {
                printLog("=== micRec's onExited ===")
                main.forceActiveFocus()
            }
            onClicked: onClickedAction()
            onActiveFocusChanged: {
                if(micRec.activeFocus){
                    remainSeconds = 30
                    ttsService.speakByAudioGuidance(textToSpeech, currentLanguage)
                }
            }
            Keys.onReleased: {
                printLog("=== micRec Keys.onReleased: === " + event.key)
                switch(event.key){
                case extKey.key_up:
                    guideRetryButton.forceActiveFocus()
                    event.accepted = true;
                    break;
                case extKey.key_left:
                case extKey.key_right:
                case extKey.key_down:
                    forceActiveFocus();
                    event.accepted = true;
                    break;
                case extKey.key_return:
                    micRec.onClickedAction();
                    event.accepted = true;
                    break;
                }
            }
            function onClickedAction() {
                printLog("=== micRec's onClickedAction ===")
                printLog("main.state: " + main.state)
                if(main.state === "event_error"){
                    printLog("restart STT")
                    main.forceActiveFocus();
                    restartSttService();
                }
            }
        }

        Text {
            id: guideLangText
            objectName: "guideLangText"
            anchors.top: bgRec.top
            anchors.topMargin: sttStyle.guideLangText.topMargin
            anchors.horizontalCenter: parent.horizontalCenter

            font.family: normal400_fontFamily
            font.weight: normal400_fontWeight
            font.pixelSize: sttStyle.guideLangText.fontSize
            color: sttStyle.guideText.fontColor
            property string imgString: {
                if(resolution === "uhd")
                    return "\u202A<img src=\"images/stt_icon_keyhelp_down_4k.png\">\u202C"
                else
                    return "\u202A<img src=\"images/stt_icon_keyhelp_down.png\">\u202C"
            }
            property string imgStringName: stringSet.strings["Down Button"]
            text: stringSet.strings["Press %1%2 to change language."].arg(imgString).arg("")
            property string textToSpeech: stringSet.strings["Press %1%2 to change language."].arg(imgStringName).arg("")
        }

        Image {
            id: guideImage
            objectName: "guideImage"
            anchors.right: guideText.left
            anchors.rightMargin: sttStyle.guideImage.rightMargin
            anchors.verticalCenter: guideText.verticalCenter
            source: "images/nlp_sequence_error_icon.png"
            visible: false
            LayoutMirroring.enabled: isRTL
        }

        Text {
            id: guideText
            objectName: "guideText"
            anchors {
                left: parent.left; leftMargin: sttStyle.guideText.leftMargin
                right: parent.right; rightMargin: sttStyle.guideText.rightMargin
                top: bgRec.top
                topMargin: {
                    if(guideLangText.visible)
                        return sttStyle.guideText.topMarginReady
                    else if (guideRetryButton.visible)
                        return (parent.height - (guideText.contentHeight + guideRetryButton.height + guideRetryButton.anchors.topMargin))/2
                    else {
                        return sttStyle.guideText.topMarginInitError
                    }
                }
            }
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            font.pixelSize: sttStyle.guideText.fontSize
            font.family: normal400_fontFamily
            font.weight: normal400_fontWeight
            color: sttStyle.guideText.fontColor
            text: ""
            property string textToSpeech: text
            onVisibleChanged: {
                if(visible) callTTS();
                else text = "";
            }
            onTextToSpeechChanged: callTTS()
            function callTTS() {
                if(!(text && visible)) return;
                if(!guideLangText.visible)
                    ttsService.speakByAudioGuidance(textToSpeech, currentLanguage);
                else{
                        if(main.state ==="event_unsupportedLang"){
                            ttsService.speakByAudioGuidance(textToSpeech+" "+guideLangText.textToSpeech, currentLanguage);
                        }

                }

                if (main.state === "event_error" || main.state === "event_changekeyboardLang" || main.state ==="event_networkdisconnection") {
                    guideRetryButton.clearPrevSpeech = false;
                    if(ttsService.audioGuidanceEnable||!isCursorOn)
                        guideRetryButton.forceActiveFocus();
                }
            }
        }

        // Button OK
        SayAgainButton {
            id: guideRetryButton
            objectName: "guideRetryButton"
            anchors.top: guideText.bottom
            anchors.topMargin: sttStyle.guideRetryButton.topMargin
            anchors.horizontalCenter: parent.horizontalCenter
            visible: false
            textFontColor : "#a6a6a6"
            textFontFocusColor : sttStyle.sayAgainButton.focusFontColor
            property bool clearPrevSpeech: true

            onActiveFocusChanged: {
                if (activeFocus) {
                    ttsService.speakByAudioGuidance(textToSpeech,currentLanguage, clearPrevSpeech);
                    clearPrevSpeech = true;
                }
            }

            Keys.onReleased: {
                printLog("=== guideRetryButton Keys.onReleased: === " + event.key)
                switch(event.key){
                case extKey.key_up:
                case extKey.key_left:
                case extKey.key_right:
                case extKey.key_down:
                    forceActiveFocus()
                    event.accepted = true;
                    break;
                case extKey.key_return:
                    sayAgainButton.onReleasedAction();
                    event.accepted = true;
                    break;
                }
            }
        }
        // LANGUAGE SELECT BOX
        Item {
            id: langSelectBox
            objectName: "langSelectBox"
            anchors.fill: bgRec
            visible: false

            property string textToSpeech : ""

            function focusInit (bIsInit) {
                printLog("=== langSelectBox focusInit() ===");
                focusOut(bIsInit);
            }
            function focusOut (bIsInit) {
                printLog("=== langSelectBox ===");
                forceActiveFocus();
                langSelectListView.initialize(bIsInit);
            }

            Rectangle {
                id:langSelectBoxBgRec
                anchors.fill: parent
                color: sttStyle.langSelectBox.bgColor
                opacity: sttStyle.langSelectBox.bgOpacity
                radius: sttStyle.radiusVal
            }

            DropShadow {
                    anchors.fill: langSelectBoxBgRec
                    source: langSelectBoxBgRec
                    color: sttStyle.shadowColor
                    horizontalOffset: sttStyle.shadowHoffset
                    verticalOffset: sttStyle.shadowVoffset
                    radius: sttStyle.shadowRadius
                    samples: sttStyle.shadowSamples
                    visible: langSelectBoxBgRec.visible
            }

            //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
            LayoutMirroring.enabled: isRTL

            property real deltaContentY: 0

            onActiveFocusChanged: if(activeFocus)remainSeconds = 30;
            onVisibleChanged: {
                if(visible) {
                    var result = langSelectTitle.text;
                    for(var i=0; i<langSelectListModel.count; i++) {
                        if(langSelectListModel.get(i).isSelected){
                            result += " " + langSelectListModel.getLanguageName(i) + " " + stringSet.strings["checked"];
                            langSelectListView.currentIndex = i;
                        }
                    }
                    textToSpeech = result;

                } else
                    langSelectListView.currentIndex = langSelectListView._NOT_ON_THE_LIST;
            }

            MouseArea {
                anchors.fill: parent
                acceptedButtons: Qt.NoButton
                onWheel: {
                    var deltaY = wheel.angleDelta.y;
                    if(!((langSelectListView.atYBeginning && deltaY > 0)||(langSelectListView.atYEnd && deltaY < 0)))
                        langSelectListView.flick(0, deltaY * 15);
                }
            }

            Text {
                id: langSelectTitle
                objectName: "langSelectTitle"
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.topMargin: sttStyle.langSelectTitle.topMargin
                anchors.leftMargin: sttStyle.langSelectTitle.leftMargin
                anchors.rightMargin: sttStyle.langSelectTitle.rightMargin
                font.pixelSize: sttStyle.langSelectTitle.fontSize
                font.family: normal400_fontFamily
                font.weight: normal400_fontWeight
                color: sttStyle.langSelectTitle.fontColor
                text: stringSet.strings["SELECT LANGUAGE"]

                //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
                LayoutMirroring.enabled: isRTL

            }

            Rectangle {
                id: langSelectTitleLine
                objectName: "langSelectTitleLine"
                anchors.top: langSelectTitle.bottom
                anchors.topMargin: sttStyle.langSelectTitle.lineTopMargin
                anchors.left: langSelectTitle.left
                anchors.right: langSelectTitle.right
                height: sttStyle.langSelectTitle.lineHeight
                color: sttStyle.langSelectTitle.lineColor

                //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
                LayoutMirroring.enabled: isRTL
            }
            ListView {
                id: langSelectListView
                objectName: "langSelectListView"
                anchors.top: langSelectTitleLine.bottom
                anchors.left: parent.left
                anchors.right: scrollBar.left
                anchors.topMargin: sttStyle.langSelectListView.topMargin
                anchors.leftMargin: sttStyle.langSelectListView.leftMargin
                anchors.rightMargin: sttStyle.langSelectListView.rightMargin
                height: sttStyle.langSelectListItem.height * 3 + sttStyle.langSelectListItem.shadowHeight * 3
                anchors.bottomMargin: sttStyle.langSelectListView.bottomMargin
                contentHeight: langSelectListModel.count*(sttStyle.langSelectListItem.shadowHeight + sttStyle.langSelectListItem.height)
                model: langSelectListModel
                currentIndex: _NOT_ON_THE_LIST
                highlightFollowsCurrentItem: true
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                property variant targetScrollBar : scrollBar

                //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
                LayoutMirroring.enabled: isRTL
                LayoutMirroring.childrenInherit: isRTL

                readonly property int _NOT_ON_THE_LIST: -1

                function initialize(bIsInit) {
                    currentIndex = _NOT_ON_THE_LIST;

                    if(bIsInit){
                        for(var i=0; i<langSelectListModel.count; i++) {
                            if(langSelectListModel.get(i).isSelected){
                                currentIndex = i;
                            }
                        }
                    }

                    if(ttsService.audioGuidanceEnable || !isCursorOn) {
                        if(!bIsInit)
                            langSelectListView.focusToTopItem();
                        langSelectListView.forceActiveFocus();
                    }
                    scrollBar.updateAll();
                }
                function focusToTopItem(){
                    printLog("=== langSelectListView focusToTopItem() ===");
                    printLog("contentY: " + contentY);
                    printLog("contentY + sttStyle.langSelectListItem.height/2 : " + contentY + sttStyle.langSelectListItem.height/2);
                    var i;
                    // find Item from top
                    for(i = 1; i < langSelectListModel.count; i++) {
                        currentIndex = indexAt(0,contentY + (sttStyle.langSelectListItem.height/2) * i );
                        if(currentIndex != _NOT_ON_THE_LIST)
                            break;
                    }
                    positionViewAtIndex(currentIndex, ListView.Beginning);
                    printLog("currentIndex = indexAt(0,contentY + (sttStyle.langSelectListItem.height/2) * i; " + currentIndex);
                }
                function focusToBottomItem(){
                    printLog("=== langSelectListView focusToBottomItem() ===")
                    // find Item from bottom
                    var i;
                    for(i = 1; i < langSelectListModel.count; i++) {
                        currentIndex = indexAt(0, contentY + height - (sttStyle.langSelectListItem.height/2) * i);
                        if(currentIndex != _NOT_ON_THE_LIST)
                            break;
                    }
                    printLog("currentIndex = indexAt(0, contentY + height - sttStyle.langSelectListItem.height/2); " + currentIndex)
                    positionViewAtIndex(currentIndex, ListView.End);
                }
                onCurrentIndexChanged: {
                    printLog("=== onCurrentIndexChanged ===")
                    printLog("langSelectListView.currentIndex: " + currentIndex)

                }

                delegate: Item {
                    id: langSelectListItemUI // this is the LIST ITEM COMPONENT developer thinks. It has full width and check image
                    objectName: "langSelectListItemUI"
                    width: parent.width
                    height: sttStyle.langSelectListItem.height + sttStyle.langSelectListItem.shadowHeight
                    property ListView parentListObject: langSelectListView
                    property int itemIndex: index
                    property real centerY : y + (height-sttStyle.langSelectListItem.shadowHeight)/2
                    property string textToSpeech : langItemText.text

                    property string stateToSpeech : {
                        if(isSelected)
                            return stringSet.strings["checked"];
                        else
                            return stringSet.strings["unchecked"];
                    }

                    property string textCode: (langSelectListModel.get(itemIndex).code === "notSupported")?currentLanguage:langSelectListModel.get(itemIndex).code

                    function checkedFocus(){
                        printLog("=== checkedFocus() index " + itemIndex + "===")

                        if(langSelectListView.currentIndex === itemIndex){
                            langSelectListItem.forceActiveFocus()
                            printLog("langSelectListItem.activeFocus " + langSelectListItem.activeFocus)
                        }
                    }

                    Component.onCompleted: {
                        langSelectListView.onCurrentIndexChanged.connect(checkedFocus)
                    }
                    Component.onDestruction: {
                        langSelectListView.onCurrentIndexChanged.disconnect(checkedFocus)
                    }

                    // UI object that has actual width and height
                    Item {
                        id: langSelectListItemActualUI
                        objectName: "langSelectListItemActualUI"
                        anchors.left: parent.left
                        width: langSelectListItem.width + sttStyle.langSelectListItem.imgWidth + sttStyle.langSelectListItem.itemImgleftMargin*2
                        height: parent.height - sttStyle.langSelectListItem.shadowHeight
                        Rectangle{
                            id: itemRec
                            anchors.fill: parent
                            anchors.leftMargin: sttStyle.langSelectListItem.itemRecleftMargin
                            color: langSelectListItem.activeFocus? "#E6E6E6" : "transparent"
                            radius: sttStyle.langSelectListItem.radius
                        }
                        DropShadow{
                            anchors.fill: itemRec
                            visible: langSelectListItem.activeFocus
                            color: sttStyle.shadowColor
                            horizontalOffset: sttStyle.shadowHoffset
                            verticalOffset: sttStyle.shadowVoffset
                            radius: sttStyle.shadowRadius
                            samples: sttStyle.shadowSamples
                            source: itemRec
                        }
                        // select image
                        Item {
                            id: langItemImg

                            anchors.left: parent.left
                            anchors.leftMargin: sttStyle.langSelectListItem.itemImgleftMargin
                            anchors.verticalCenter: parent.verticalCenter
                            width: sttStyle.langSelectListItem.imgWidth
                            height: sttStyle.langSelectListItem.imgWidth

                            Rectangle{
                                id:unSelectedRec
                                anchors.fill: langItemImg
                                radius: langItemImg.width/2
                                color: sttStyle.langSelectListItem.unSelectedBgColor
                                border.color: langSelectListItem.activeFocus?sttStyle.langSelectListItem.unSelectedFocusColor:sttStyle.langSelectListItem.unSelectedNormalColor
                                border.width: sttStyle.langSelectListItem.unSelectedborderWidth
                                visible: !isSelected
                            }

                            Rectangle{
                                id:selectedRec
                                anchors.fill: langItemImg
                                radius: langItemImg.width/2
                                color: sttStyle.langSelectListItem.selectedBgColor
                                border.color: sttStyle.langSelectListItem.selectedborderColor
                                border.width: sttStyle.langSelectListItem.selectedborderWidth
                                visible: isSelected
                            }
                        }

                        MouseArea {
                            id: langSelectListItem // this is the LIST ITEM COMPONENT user thinks. It has only focusable area.
                            objectName: "langSelectListItem"
                            anchors.left: langItemImg.right
                            anchors.leftMargin: sttStyle.langSelectListItem.itemImgleftMargin
                            width: sttStyle.langSelectListItem.itemTextLeftMargin + langItemText.width + sttStyle.langSelectListItem.itemTextRightMargin
                            height: sttStyle.langSelectListItem.height
                            hoverEnabled: true
                            onEntered: {
                                printLog("=== langSelectListItem onEntered() ===")
                                if( (langSelectListItemUI.centerY >= langSelectListView.contentY) && (langSelectListItemUI.centerY <= langSelectListView.contentY + langSelectListView.height) ){
                                    if(langSelectListView.currentIndex != itemIndex)
                                        langSelectListView.currentIndex = itemIndex
                                    else{
                                        langSelectListView.currentIndex = langSelectListView._NOT_ON_THE_LIST
                                        langSelectListView.currentIndex = itemIndex
                                    }
                                }
                            }
                            onExited: {
                                langSelectListView.currentIndex = langSelectListView._NOT_ON_THE_LIST
                                langSelectBox.forceActiveFocus()
                            }
                            onClicked: {
                                onClickedAction()
                            }
                            onActiveFocusChanged:{
                                if(activeFocus){
                                    if(langSelectBox.textToSpeech) {
                                        ttsService.speakByAudioGuidance(langSelectBox.textToSpeech, currentLanguage);
                                        langSelectBox.textToSpeech = "";
                                    } else
                                    {
                                        ttsService.speakByAudioGuidance(langSelectListItemUI.textToSpeech, langSelectListItemUI.textCode);
                                        ttsService.speakByAudioGuidance(langSelectListItemUI.stateToSpeech, currentLanguage, false);
                                    }
                                    remainSeconds = 30;
                                }
                            }
                            Text {
                                id: langItemText
                                objectName: "langItemText"
                                anchors.left: parent.left
                                anchors.leftMargin: sttStyle.langSelectListItem.itemTextLeftMargin
                                anchors.verticalCenter: parent.verticalCenter
                                color: langSelectListItem.activeFocus? sttStyle.langSelectListItem.focusFontColor : sttStyle.langSelectListItem.fontColor
                                font.pixelSize: sttStyle.langSelectListItem.fontSize
                                font.family: langSelectListItem.activeFocus ? normal600_fontFamily : normal400_fontFamily
                                font.weight: langSelectListItem.activeFocus ? normal600_fontWeight : normal400_fontWeight
                                text: langSelectListModel.getLanguageName(index)
                            }
                        }
                    }
                    function onClickedAction(){
                        langSelectListModel.setSelected(index)
                        ttsService.speakByAudioGuidance(langSelectListItemUI.textToSpeech,langSelectListItemUI.textCode)//currentLanguage
                        ttsService.speakByAudioGuidance(langSelectListItemUI.stateToSpeech, currentLanguage,false);
                    }
                    //                onIsSelectedChanged : ttsService.speakByAudioGuidance(langSelectListItemUI.textToSpeech,currentLanguage)

                    Keys.onReleased: {
                        printLog("=== langSelectListView ITEM Keys.onReleased: === " + event.key)
                        switch(event.key){
                        case extKey.key_left:
                            if(isRTL) {
                                parentListObject.currentIndex = parentListObject._NOT_ON_THE_LIST;
                                langSelectButtonCancel.forceActiveFocus();
                            }
                            event.accepted = true;
                            break;
                        case extKey.key_right:
                            if(!isRTL) {
                                parentListObject.currentIndex = parentListObject._NOT_ON_THE_LIST;
                                langSelectButtonCancel.forceActiveFocus();
                            }
                            event.accepted = true;
                            break;
                        case extKey.key_return:
                            onClickedAction();
                            event.accepted = true;
                            break;
                        }
                    }
                }

                Keys.onReleased: {
                    printLog("=== langSelectListView Keys.onReleased: === " + event.key)
                    switch(event.key){
                    case extKey.key_up:     // UP -> Upper Item
                        printLog("case extKey.key_up:     // UP -> Upper Item")
                        printLog("langSelectListView.currentIndex: " + langSelectListView.currentIndex)
                        if((langSelectListView.currentIndex - 1)  < 0) { // TOP OF THE LIST -> langSelectButtonCancel
                            langSelectListView.positionViewAtIndex(langSelectListView.currentIndex, ListView.Beginning);
                            langSelectListView.currentIndex = langSelectListView._NOT_ON_THE_LIST;
                            langSelectButtonCancel.forceActiveFocus();
                        }
                        else {// OTHERS
                            langSelectListView.decrementCurrentIndex()
                        }
                        event.accepted = true;
                        break;
                    case extKey.key_down:   // DOWN -> Lower Item
                        if((langSelectListView.currentIndex + 1) < langSelectListModel.count){
                            langSelectListView.incrementCurrentIndex();
                        }
                        event.accepted = true;
                        break;
                    case extKey.key_left:   // LEFT -> OWN
                        event.accepted = true;
                        break;
                    }
                }

                ListEndIndicator {
                    flickable: langSelectListView
                    horizontalLayout: false
                }
            }


            // Button OK
            MouseArea {
                id: langSelectButtonOk
                objectName: "langSelectButtonOk"
                anchors.top: parent.top
                anchors.right: parent.right
                anchors.topMargin: sttStyle.langSelectButtonOk.topMargin
                anchors.rightMargin: sttStyle.langSelectButtonOk.rightMargin
                width: Math.max(langSelectButtonOkText.width + sttStyle.sayAgainButton.sidePadding*2, sttStyle.sayAgainButton.smallMinWidth)
                height: sttStyle.langSelectButtonOk.height
                hoverEnabled: true
                property string textToSpeech : langSelectButtonOkText.text + " " + stringSet.strings["button"]
                //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
                LayoutMirroring.enabled: isRTL

                onEntered: langSelectButtonOk.forceActiveFocus()
                onExited: langSelectButtonOk.parent.forceActiveFocus()
                onClicked: onClickedAction()

                onActiveFocusChanged: {
                    if(activeFocus){
                        ttsService.speakByAudioGuidance(textToSpeech,currentLanguage)
                        remainSeconds = 30;
                    }
                }

                Rectangle {
                    id: okButtonRec
                    anchors.centerIn: parent
                    width: langSelectButtonOk.activeFocus?parent.width*1.2 : parent.width
                    height: langSelectButtonOk.activeFocus?parent.height*1.2 : parent.height
                    radius: sttStyle.sayAgainButton.radius
                    color: langSelectButtonOk.activeFocus ? sttStyle.sayAgainButton.focusedColor : sttStyle.sayAgainButton.normalColor
                }

                DropShadow{
                    anchors.fill: okButtonRec
                    visible: langSelectButtonOk.activeFocus
                    color: sttStyle.shadowColor
                    horizontalOffset: sttStyle.shadowHoffset
                    verticalOffset: sttStyle.shadowVoffset
                    radius: sttStyle.shadowRadius
                    samples: sttStyle.shadowSamples
                    source: okButtonRec
                }

                Text {
                    id: langSelectButtonOkText
                    objectName: "langSelectButtonOkText"
                    anchors.centerIn: parent
                    text: stringSet.strings["OK"]
                    font.pixelSize: sttStyle.sayAgainButton.fontSize
                    font.family: langSelectButtonOk.activeFocus ?  normal600_fontFamily : normal400_fontFamily
                    font.weight: langSelectButtonOk.activeFocus ?  normal600_fontWeight : normal400_fontWeight
                    font.capitalization: Font.AllUppercase
                    color: langSelectButtonOk.activeFocus ? sttStyle.sayAgainButton.focusFontColor : sttStyle.sayAgainButton.fontColor
                }

                Keys.onReleased: {
                    printLog("=== langSelectButtonOk Keys.onReleased: === " + event.key)
                    switch(event.key){
                    case extKey.key_up:     // UP -> OWN
                        forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_down:
                        langSelectListView.focusToTopItem();
                        event.accepted = true;
                        break;
                    case extKey.key_left:   // LEFT -> LTR: langSelectButtonCancel, RTL: OWN
                        if(!isRTL)
                            langSelectButtonCancel.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_right:  // RIGHT -> LTR: OWN, RTL: langSelectButtonCancel
                        if(isRTL)
                            langSelectButtonCancel.forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_return:
                        onClickedAction();
                        event.accepted = true;
                        break;
                    }
                }
                function onClickedAction(){
                    main.forceActiveFocus()
                    loadLanguageText()
                    selectedLanguage = langSelectListModel.getSelectedItem().code
                    restartSttService()
                }
            }
            // Button Cancel
            MouseArea {
                id: langSelectButtonCancel
                objectName: "langSelectButtonCancel"
                anchors.top: parent.top
                anchors.right: langSelectButtonOk.left
                anchors.topMargin: sttStyle.langSelectButtonCancel.topMargin
                anchors.rightMargin: sttStyle.langSelectButtonCancel.rightMargin
                width: Math.max(langSelectButtonCancelText.width + sttStyle.sayAgainButton.sidePadding*2, sttStyle.sayAgainButton.smallMinWidth)
                height: sttStyle.langSelectButtonCancel.height
                hoverEnabled: true
                property string textToSpeech : langSelectButtonCancelText.text + " " + stringSet.strings["button"]
                //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
                LayoutMirroring.enabled: isRTL

                onEntered: langSelectButtonCancel.forceActiveFocus()
                onExited: langSelectButtonCancel.parent.forceActiveFocus()
                onClicked: onClickedAction()
                onActiveFocusChanged:{
                    if(activeFocus){
                        ttsService.speakByAudioGuidance(textToSpeech,currentLanguage)
                        remainSeconds = 30;
                    }
                }
                Rectangle {
                    id: cancelButtonRec
                    anchors.centerIn: parent
                    width: langSelectButtonCancel.activeFocus?parent.width*1.2 : parent.width
                    height: langSelectButtonCancel.activeFocus?parent.height*1.2 : parent.height
                    radius: sttStyle.sayAgainButton.radius
                    color: langSelectButtonCancel.activeFocus ? sttStyle.sayAgainButton.focusedColor : sttStyle.sayAgainButton.normalColor
                }

                DropShadow{
                    anchors.fill: cancelButtonRec
                    visible: langSelectButtonCancel.activeFocus
                    color: sttStyle.shadowColor
                    horizontalOffset: sttStyle.shadowHoffset
                    verticalOffset: sttStyle.shadowVoffset
                    radius: sttStyle.shadowRadius
                    samples: sttStyle.shadowSamples
                    source: cancelButtonRec
                }
                Text {
                    id: langSelectButtonCancelText
                    objectName: "langSelectButtonCancelText"
                    anchors.centerIn: parent
                    text: stringSet.strings["CANCEL"]
                    font.pixelSize: sttStyle.sayAgainButton.fontSize
                    font.family: langSelectButtonCancel.activeFocus ?  normal600_fontFamily : normal400_fontFamily
                    font.weight: langSelectButtonCancel.activeFocus ?  normal600_fontWeight : normal400_fontWeight
                    font.capitalization: Font.AllUppercase
                    color: langSelectButtonCancel.activeFocus ? sttStyle.sayAgainButton.focusFontColor : sttStyle.sayAgainButton.fontColor
                }

                Keys.onReleased: {
                    printLog("=== langSelectButtonCancel Keys.onReleased: === " + event.key)
                    switch(event.key){
                    case extKey.key_up:     // UP -> OWN
                        forceActiveFocus();
                        event.accepted = true;
                        break;
                    case extKey.key_right:  // RIGHT -> LTR: langSelectButtonOk, RTL: langSelectListView
                        if(isRTL)
                            langSelectListView.focusToTopItem();
                        else {
                            langSelectButtonOk.forceActiveFocus();
                        }
                        event.accepted = true;
                        break;
                    case extKey.key_down:
                        langSelectListView.focusToTopItem();
                        event.accepted = true;
                        break;
                    case extKey.key_left:   // LEFT -> LTR: langSelectListView, RTL: langSelectButtonOk
                        if(isRTL)
                            langSelectButtonOk.forceActiveFocus();
                        else
                            langSelectListView.focusToTopItem();
                        event.accepted = true;
                        break;
                    case extKey.key_return:
                        onClickedAction();
                        event.accepted = true;
                        break;
                    }
                }
                function onClickedAction() {
                    main.forceActiveFocus();
                    restartSttService();
                }
            }

            Item {
                id: scrollBar
                objectName: "scrollBar"
                anchors.top: langSelectListView.top
                anchors.right: parent.right
                anchors.rightMargin: sttStyle.langSelectListScrollBar.rightMargin
                anchors.bottom: langSelectListView.bottom
                anchors.topMargin: sttStyle.langSelectListScrollBar.barTopMargin
                anchors.bottomMargin: sttStyle.langSelectListScrollBar.barBottomMargin
                width: sttStyle.langSelectListScrollBar.width

                //for LayoutMirroring. QT.locale().textDirection -> LTR: 0, RTL: 1
                LayoutMirroring.enabled: isRTL

                property ListView targetListView: langSelectListView

                Rectangle{
                    anchors{
                        top : parent.top
                        bottom: parent.bottom
                    }
                    width: sttStyle.langSelectListScrollBar.barWidth
                    radius: sttStyle.langSelectListScrollBar.barRadius
                    color: sttStyle.langSelectListScrollBar.barBgColor
                    opacity: scrollMidBarImg.opacity
                }

                function showScrollMoving() {
                    scrollMidBarImg.opacity = 1
                    hideScrollTimer.start()
                }

                function isAtTop() {
                    return (targetListView.contentY === 0)? true : false;
                }
                function isAtBottom() {
                    return (targetListView.contentY + targetListView.height === targetListView.contentHeight)? true : false
                }
                function needScroll() {
                    return (targetListView.contentHeight <= targetListView.height) ? false : true;
                }
                function updateAll() {
                    scrollMidBar.update()
                }

                Connections {
                    target: langSelectListView
                    onContentYChanged: {
                        scrollBar.showScrollMoving();
                    }
                }

                Timer {
                    id: hideScrollTimer
                    interval: 500; running: false; repeat: false
                    onTriggered: scrollMidBarImg.opacity = 0
                }

                MouseArea {
                    id: scrollMidBar
                    objectName: "scrollMidBar"
                    anchors.top: parent.top
                    anchors.bottom: parent.bottom
                    width: parent.width
                    hoverEnabled: true
                    opacity: scrollMidBar.isDimmed ? 0.3 : 1

                    property bool isDimmed: false

                    drag {
                        target: scrollMidBarImg
                        minimumY: 0
                        maximumY: (scrollMidBar.height - scrollMidBarImg.height)
                        axis: Drag.YAxis
                    }
                    onClicked: { langSelectListView.contentY = (mouse.y / scrollMidBar.height * (langSelectListView.contentHeight - langSelectListView.height)) }

                    function update(){
                        printLog("=== scrollMidBar update ===");
                        if(!scrollBar.needScroll()) // is whole List height is equal to View height, there is no need to scroll
                            scrollMidBar.isDimmed = true;
                        else
                            scrollMidBar.isDimmed = false;
                    }
                    Item {
                        id: scrollMidBarImg
                        objectName: "scrollMidBarImg"
                        anchors.left: parent.left
                        anchors.right: parent.right
                        opacity: 0

                        Rectangle{
                            anchors{
                                top : parent.top
                                bottom: parent.bottom
                            }
                            width: sttStyle.langSelectListScrollBar.barWidth
                            radius: sttStyle.langSelectListScrollBar.barRadius
                            color: sttStyle.langSelectListScrollBar.barColor
                            height: paintedHeight
                        }
                        Behavior on opacity { NumberAnimation { duration: 200 } }
                    }
                }
            }

            PropertyAnimation {
                id: moveContentYAni
                objectName: "moveContentYAni"
                target: langSelectListView
                property: "contentY"
                to: langSelectListView.contentY + langSelectBox.deltaContentY
                duration: 300
                easing.type: Easing.InOutQuad
                onRunningChanged: if(!running) {langSelectListView.returnToBounds()}
            }
            /*
              Key Focusable Object
              langSelectListView
              langSelectButtonOk
              langSelectButtonCancel
              scrollUp
              scrollDown
              */
            Keys.onReleased: {
                printLog("=== langSelectBox Keys.onReleased: === " + event.key)
                switch(event.key){
                case extKey.key_up:     // UP -> langSelectButtonCancel
                    langSelectButtonCancel.forceActiveFocus();
                    break;
                case extKey.key_right:  // RIGHT -> LTR: langSelectButtonCancel, RTL: langSelectListView
                    if(isRTL)
                        langSelectListView.forceActiveFocus();
                    else
                        langSelectButtonCancel.forceActiveFocus();

                    event.accepted = true;
                    break;
                case extKey.key_down:   // DOWN -> langSelectListView
                    langSelectListView.focusToTopItem();
                    break;
                case extKey.key_left:   // LEFT -> LTR: langSelectListView, RTL: langSelectButtonCancel
                    if(isRTL)
                        langSelectButtonCancel.forceActiveFocus();
                    else
                        langSelectListView.focusToTopItem();
                    event.accepted = true;
                    break;
                }
            }
        }

        Binding {
            target: scrollMidBarImg
            property: "y"
            value:{
                var tempVal = langSelectListView.contentY * scrollMidBar.drag.maximumY / (langSelectListView.contentHeight - langSelectListView.height)

                if(tempVal<0)
                    return 0;
                else if(tempVal+scrollMidBarImg.height > scrollBar.height)
                    return (scrollBar.height - scrollMidBarImg.height);
                else
                    return tempVal;
            }
            when: (!scrollMidBar.drag.active)
        }

        Binding {
            target: langSelectListView
            property: "contentY"
            value: (scrollMidBarImg.y * (langSelectListView.contentHeight - langSelectListView.height) / scrollMidBar.drag.maximumY)
            when: (scrollMidBar.drag.active || scrollMidBar.pressed)
        }

        ListModel {
            id: langSelectListModel
            objectName: "langSelectListModel"
            function add(sttLanguage){
                // isInList
                for (var i =0; i < langSelectListModel.count; i++) {
                    if(langSelectListModel.get(i).code === sttLanguage)
                        return;
                }

                // is valid locale language
                var localeText = localeString.printLocale(sttLanguage);
                printLog("var localeText = localeString.printLocale("+ sttLanguage +"); " + localeText)
                if(localeText === "")
                    return;

                langSelectListModel.append({
                                               index: langSelectListModel.count,
                                               code: sttLanguage,
                                               languageName : localeText,
                                               isSelected: false
                                           });
            }

            function getLanguageName(i){
                var langName = langSelectListModel.get(i).languageName;

                if(langName === "notSupported")
                    return stringSet.strings["None"]
                else
                    return langName
            }

            function setSelectedByLangCode(langCode){
                for (var i = 0; i < langSelectListModel.count; i++){
                    var item = langSelectListModel.get(i);
                    if(item.code === langCode){
                        item.isSelected = true;
                    } else {
                        item.isSelected = false;
                    }
                }
            }

            function setSelected(index){
                for (var i = 0; i < langSelectListModel.count; i++){
                    var item = langSelectListModel.get(i);
                    if(i === index){
                        item.isSelected = true;
                    } else {
                        item.isSelected = false;
                    }
                }
            }
            function clearSelected(){
                for (var i = 0; i < langSelectListModel.count; i++){
                    var item = langSelectListModel.get(i);
                    item.isSelected = false;
                }

            }
            function restoreSelection(languageCode){
                for (var i = 0; i < langSelectListModel.count; i++){
                    var item = langSelectListModel.get(i);
                    item.isSelected = (item.code === languageCode);

                }
            }
            function getSelectedItem() {
                for (var i = 0; i < langSelectListModel.count; i++){
                    var item = langSelectListModel.get(i);
                    if(item.isSelected){
                        return item;
                    }
                }
                return null;
            }
        }

        Spinner {
            id: spinner
            anchors.fill: parent
            //visible: false
            opacity: 0
        }

        Timer {
            id: spinnerTimer
            interval: 100
            onTriggered: {
                if(main.state === "event_sttStart" || main.state === "event_energyLevel" || main.state === "event_error" ||
                        main.state === "event_langSelect" || main.state === "sttConnecting"||
                        main.state === 'event_unsupportedLang'|| main.state === 'event_changekeyboardLang'|| main.state ==="event_networkdisconnection") {
                    printLog("stopSpinner();")
                    stopSpinner();
                } else {
                    restart();
                }
            }
        }
    }

    Service {
        id: connectionmanagerService
        appId: "com.webos.service.ime.stt"
        service: "com.webos.service.connectionmanager"
        method: "getStatus"
        property bool isInternetConnectionAvailable: false  // store internet connection status
        property bool isReceiveResponse: false

        Component.onCompleted: {
            callService({"subscribe":true});
        }
        onResponse: {

            var response = JSON.parse(payload);

            if (!response.returnValue) {
                printWarningLog(" ##### returnValue is not true :: response.returnValue : " + response.returnValue);
                isReceiveResponse = true;
                return;
            }

            if (response.isInternetConnectionAvailable !== undefined) {
                isInternetConnectionAvailable = response.isInternetConnectionAvailable;
                isReceiveResponse = true;
                printWarningLog(" connectionmanagerService: isInternetConnectionAvailable = " + isInternetConnectionAvailable);
            }

        }
    }

    Service { id: getAppIdService
        appId: "com.webos.service.ime.stt"
        onResponse: {
            var jsonObject = JSON.parse(payload)
            if(!jsonObject.returnValue) { console.exception(payload); return; }
            printLog("getAppIdService", payload)
            if ( jsonObject.foregroundAppInfo !== undefined){
                cardTypeForegroundAppId = ""
                anyTypeForegroundAppId = ""
                var foregroundAppList = jsonObject.foregroundAppInfo
                for(var i = 0; i < foregroundAppList.length; i++) {
                    var object = foregroundAppList[i]
                    if(object.windowType === "_WEBOS_WINDOW_TYPE_CARD") { // always exist
                        // Only CARD TYPE App is returned using getForegroundInfo API without extraInfo.
                        // Thus, this is general foreground app.
                        cardTypeForegroundAppId = object.appId
                    }else{// if exist _WEBOS_WINDOW_TYPE_POPUP,_WEBOS_WINDOW_TYPE_OVERLAY => if not exist, anyTypeForegroundAppId === ""
                        anyTypeForegroundAppId  = object.appId
                    }
                    printLog("=== getAppIdService return == cardTypeForegroundAppId :" + cardTypeForegroundAppId + " : anyTypeForegroundAppId : " + anyTypeForegroundAppId)
                }
            }

            // START VOICE RECOGNITION
            //            canShowSTTView();
            //            guideText.text = qsTr("Speak to input text.")+qsTr("(")+localeString.printLocale(selectedLanguage)+qsTr(")") + PluginProxy.emptyString; // i18n This sentence appears when user tries to input text by voice recognition.
            callSttService();
            isActivated = true;
        }

        onError: {
            printLog("onError():");
            console.trace();
        }
    }

    /* Service: Check MRCU connection status*/
    /* luna://com.webos.service.mrcu/getConnectionStatus '{"subscribe":true}'
       luna://com.webos.service.mrcu/getConnectionStatus '{}'
    1) disconnect
    {
        "connected": false,
        "returnValue": true
    }
    2) connect
    {
        "connected": true,
        "returnValue": true
    }
    */
    Service {
        id: checkMRCUPairService
        appId: "com.webos.service.ime.stt"
        onResponse: {
            printWarningLog("checkMRCUPairService Response : " + payload);
            var jsonObject = JSON.parse(payload);
            if(!jsonObject.returnValue) {
                printLog(jsonObject.errorCode + " " + jsonObject.errorText);
                goToInitialError();
                handleErrors("", stringSet.strings["You need to use LG Magic Remote to use voice recognition."]);
                return;
            }
            if(jsonObject.isFalseActive){
                goToInitialError();
                handleErrors("", stringSet.strings["To use voice recognition with the Magic Remote that you are currently using, please try again from the other TV."]);
                return;
            }
            if(jsonObject.connected) {
                callGetAppIdService();
            } else {
                goToInitialError();
                handleErrors("", stringSet.strings["You need to use LG Magic Remote to use voice recognition."]);
            }
            cancel()
        }
    }

    /* Service: Check Bluetooth Setting(atsc is always on) */
    /*
    luna-send -f -n 1 luna://com.webos.service.bluetooth2/adapter/getStatus '{}'
    {
        "subscribed": false,
        "adapters": [
            {
                "powered": true,
                "discoveryTimeout": 20,
                "pairing": false,
                "discoverableTimeout": 120,
                "name": "[LG] webOS TV WEBOS4.0",
                "adapterAddress": "30:a9:de:a7:c7:db",
                "discovering": false,
                "discoverable": false,
                "pairable": false,
                "pairableTimeout": 0
            }
        ],
        "returnValue": true
    }
    */

    Service { // change from bluetooth to bluetooth2 API (QEVENTSEVT-17660)
        id: checkBluetoothService
        appId: "com.webos.service.ime.stt"

        onResponse: {
            printWarningLog("checkBluetoothService Response : " + payload)
            var jsonObject = JSON.parse(payload)
            if(!jsonObject.returnValue){
                goToInitialError()
                handleErrors("", stringSet.strings["Turn on Bluetooth and then speak to Magic remote for voice recognition."]); // // only dvb has bluetooth setting
                return;
            }
            if(jsonObject.adapters.length > 0 && jsonObject.adapters[0].powered)
                callCheckMRCUPairService();
            else {
                goToInitialError()
                handleErrors("", stringSet.strings["Turn on Bluetooth and then speak to Magic remote for voice recognition."]); // only dvb has bluetooth setting
            }
            cancel()
        }
    }

    Service {
        id: getVoiceLanguage
        appId: "com.webos.service.ime.stt"
        service: "com.webos.service.voiceconductor"
        method: "system/getSupportedLanguages"
        property string voiceLanguage: ""
        property var sttCheckList: null
        property var retVal
        onResponse: {
            printWarningLog("[getVoiceLanguage] getVoiceLanguage Response : " + payload);
            var jsonObject = JSON.parse(payload);
            retVal = payload;
            if (getSystemSettings.menuLanguage)
                getVoiceLanguage.voiceLanguage = jsonObject.voiceLanguages[getSystemSettings.menuLanguage];
            else
                getVoiceLanguage.voiceLanguage = "notSupported";
            getVoiceLanguage.sttCheckList = jsonObject.voiceLanguages
        }
    }

    Service {
        id: getSystemSettings
        appId: "com.webos.service.ime.stt"
        service: "com.webos.settingsservice"
        method: "getSystemSettings"
        property string menuLanguage: ""
        Component.onCompleted: callService({"keys":["localeInfo"], "subscribe":true})
        onResponse: {

            function getSystemSettingsFunc(){
                localeString.localeStringReadyChanged.disconnect(getSystemSettingsFunc)

                var param ;

                printWarningLog("getSystemSettings Response : " + payload);
                getSystemSettings.menuLanguage = JSON.parse(payload).settings.localeInfo.locales.UI;
                param = {
                            "languageCodes": localeString.languageList,
                            "subscribe":true
                        };
                param.languageCodes.push(getSystemSettings.menuLanguage);

                printWarningLog("[getSystemSettings] getSystemSettings.menuLanguage : " + getSystemSettings.menuLanguage);
                getVoiceLanguage.cancel();
                getVoiceLanguage.callService(param);
            }

            if(localeString.localeStringReady){
                getSystemSettingsFunc()
            }else{
                localeString.localeStringReadyChanged.connect(getSystemSettingsFunc)
            }

        }
    }

    Service {
        id: configService
        appId: "com.webos.service.ime.stt"
        service: "com.webos.service.config"
        method: "getConfigs"
        property bool ready: false
        property bool supportPortrait: false             // profile.list value
        property bool supportTouch: false                // profile.list value

        Component.onCompleted: {
            var params = {
                "configNames": [
                    "profile.list"
                ],
                "subscribe": true
            };

            callService(params)
        }
        onResponse: {
            var response = JSON.parse(payload);

            if (!response.returnValue) {
                console.exception(payload);
                return;
            }

            if (response.configs) {
                if (response.configs["profile.list"] !== undefined) {
                    var profileList = response.configs["profile.list"];
                    if (profileList.indexOf("screenPortrait") > -1)
                        supportPortrait = true;
                    if (profileList.indexOf("touchScreen") > -1)
                        supportTouch = true;
                    printWarningLog("configService: supportPortrait = " + supportPortrait);
                    printWarningLog("configService: supportTouch = " + supportTouch);
                }
            }
            ready = true;
        }

        onError: {
            printWarningLog("onError():");
            console.trace();
        }
    }

    Service {
        id: mscService
        appId: "com.webos.service.ime.stt"
        service: "com.webos.service.msc"
        method: "getOrientationInfo"
        property bool ready: false
        property string orientation: "landscape"
        property int screenRotation: 0
        //Component.onCompleted: callService({"subscribe":true})

        function updateScreenRotation(orientation) {
            if (orientation === "landscape")
                screenRotation = 0;
            else if (orientation === "portrait")
                screenRotation = -90;
            else if (orientation === "reversed_landscape")
                screenRotation = 180;
            else if (orientation === "reversed_portrait")
                screenRotation = 90;
            printWarningLog(" $$$$$$$$$$$$$$$$$$$$$ mscService: screenRotation = " + screenRotation);
        }

        onResponse: {
            var response = JSON.parse(payload);

            printWarningLog(" $$$$$$$$$$$$$$$$$$$$$ payload :"+payload)

            if (!response.returnValue) {
                console.exception(payload);
                return;
            }

            if (response.orientation !== undefined) {
                orientation = response.orientation;
                printWarningLog("$$$$$$$$$$$$$$$$$$$$$ mscService: orientation = " + orientation);
                updateScreenRotation(response.orientation);
            }
            ready = true;
        }
    }

    Service {
        id: launchEULA
        appId: "com.webos.service.ime.stt"
        onResponse: cancel()
    }

    Service {
        id: sttService
        appId: "com.webos.service.ime.stt"
        onResponse: {
           // printWarningLog("payload: " + payload)
            var jsonObject = JSON.parse(payload);
            debugText.text = jsonObject.event + ">>";
            if((jsonObject.returnValue !== undefined) && !jsonObject.returnValue) {
                printWarningLog("=========================================================== ERROR: " + jsonObject.errorCode)
                main.state = 'event_error';
                handleErrors(jsonObject.errorCode, jsonObject.errorText);
                debugText.text = debugText.text + jsonObject.errorCode + " not in Event ";
                cancel();
            } else {
               // printWarningLog("=========================================================== EVENT: " + jsonObject.event)
                if(jsonObject.event === undefined)
                    startSTT_state = "undefined"
                else
                    startSTT_state = jsonObject['event']

                if(!isShow && jsonObject.event !== "sessionEnd") { // defense code : NCVTDEFECT-4855
                    var param = {
                        "voiceTicket": voiceTicket
                    };
                    param = JSON.stringify(param);

                    printWarningLog("voiceconductor cancelRecognition is called.   startSTT_state: " + startSTT_state);
                    sttCancelService.call("luna://com.webos.service.voiceconductor","/cancelRecognition",param);
                    sttService.cancel();
                    return;
                }

               // printWarningLog("################ jsonObject : "+ JSON.stringify(jsonObject))
                //if (jsonObject.event === "error") {
                if (jsonObject.event === "sttError") {
                    main.state = 'event_error';
                    handleErrors(jsonObject.errorCode, jsonObject.errorText);
                    debugText.text = debugText.text + jsonObject.errorCode + " in Error Event";
                    return;
                } else if (jsonObject.event === "sttStart") {
                    voiceTicket = jsonObject.voiceTicket;
                    printWarningLog("********** voiceTicket : "+voiceTicket);
                    main.forceActiveFocus();
                    debugText.text = "";
                    main.state = 'event_sttStart';
                    guideText.text = stringSet.strings["Speak to input text."] + stringSet.strings["("] + localeString.printLocale(selectedLanguage) + stringSet.strings[")"];
                    checkBeforeShow()
                    // Volume Down
                    soundEffectManager.downMediaVolume();
                    soundEffectManager.playStartSound();
                    if(isLanguagedChanged)
                        stopSpinner();
                } else if (jsonObject.event === "sttVoiceLevel") {

                    if(main.state !== 'event_sttConnecting')
                    {
                        main.state = 'event_energyLevel';
                        micRec.energyLevel = jsonObject.level;
                    }

                } else if (jsonObject.event === "sttConnecting") {
                    main.state = 'event_sttConnecting';
                    guideText.text = "";
                } else if (jsonObject.event === "sttResult") {
                    //AUI : processing
                    soundEffectManager.playConfirmSound();
                    //Volume Restored
                    printLog("\r\nVolume Restored to 100");
                    soundEffectManager.upMediaVolume();
                    if (jsonObject.text[0] !== undefined) {
                        var temp = jsonObject.text;
                        resultTextArray = temp;
                    }
                    for (var i = 0; i < 3; i++) {
                        if (resultTextArray[i] !== undefined) {
                            if (i === 0)
                                resultListButton1.text = resultTextArray[i];
                            else if (i === 1)
                                resultListButton2.text = resultTextArray[i];
                            else if (i === 2)
                                resultListButton3.text = resultTextArray[i];
                        } else {
                            break;
                        }
                    }
                    if(i === 0) {
                        main.state = 'event_sessionEnd_0';
                        resultListBox.focusInit();
                    } else if (i === 1) {
                        main.state = 'event_sessionEnd_1';
                        resultListBox.focusInit();
                        textKeyPressed(resultListButton1.text);
                    } else if (i === 2) {
                        main.state = 'event_sessionEnd_2';
                        resultListBox.focusInit();
                        remainSeconds = 30;
                        checkingRemainingTimeTimer.start();
                    } else if (i === 3) {
                        main.state = 'event_sessionEnd_3';
                        resultListBox.focusInit();
                        remainSeconds = 30;
                        checkingRemainingTimeTimer.start();
                    } else{
                        main.state = 'event_error';
                    }
                } else if (jsonObject.event === "sessionEnd") {
                    soundEffectManager.upMediaVolume();
                    cancel();
                    debugText.text = debugText.text + "[" + main.state + "]";
                }
            }
        }
        onError: console.warn("STT plugin Error")
    }

    Service {
        id: sttCancelService
        appId: "com.webos.service.ime.stt"
        onResponse: cancel()
    }

    Service {
        id: createAlertService
        appId: "com.webos.service.ime.stt"
        onResponse: cancel()
    }

    /* Key Handler */
    Keys.onReleased: {
        printLog("=== main Keys.onReleased: === " + event.key)
        printLog("event.key: " + event.key);
        var keyInterval = Date.now() - timeToShow;
        if( keyInterval > 0 && keyInterval <= 800 ){
            console.warn("========================================== interval:" + keyInterval + "Too fast key click!! returns!\r\n");
            return;
        }

        switch(event.key){
        case extKey.key_down:
            printWarningLog("Down key is Clicked")
            if(main.state === "event_sttStart" || main.state === "event_energyLevel" || main.state === "event_unsupportedLang"){
                soundEffectManager.playCancelSound();
                soundEffectManager.upMediaVolume();
                main.state = "event_langSelect"
                langSelectBox.focusInit(true);
                checkingRemainingTimeTimer.restart();
                if(needCancelAPI())
                {
                    var param = {
                        "voiceTicket": voiceTicket
                    };
                    param = JSON.stringify(param);
                    sttCancelService.call("luna://com.webos.service.voiceconductor","/cancelRecognition",param);
                    printLog("nlp cancel is called.   startSTT_state: " + startSTT_state);
                    sttService.cancel();
                }
            }
            break;
        case extKey.webOS_Voice:
            printLog("voice key is Clicked")
            // When user got multi results, if user press voice key then user can speak to use STT again.
            if(main.state === 'event_sessionEnd_2' || main.state === 'event_sessionEnd_3'||
                    main.state === 'event_error'|| main.state === 'event_langSelect'||
                    main.state === 'event_unsupportedLang'|| main.state === 'event_changekeyboardLang'|| main.state ==="event_networkdisconnection") {
                playSpinner();
                restartSttService();
            } else {
                soundEffectManager.playCancelSound();
                backToKeyboardPressed();
            }

            break;
        case extKey.webOS_Back:
            printLog("back key is Clicked")
            debugText.text = "key Event ::Back" + event.key;
            if(main.state === 'event_sessionEnd_2' || main.state === 'event_sessionEnd_3'|| main.state === 'event_error' || main.state === "event_langSelect" ||
                    main.state === 'initial_error'||main.state === 'event_unsupportedLang'|| main.state === 'event_changekeyboardLang'|| main.state ==="event_networkdisconnection") {
                backToKeyboardPressed();
            } else {
                soundEffectManager.playCancelSound();
                backToKeyboardPressed();
            }
            break;
        case extKey.key_up:
        case extKey.key_down:
        case extKey.key_left:
        case extKey.key_right:
            if(guideRetryButton.visible)
                guideRetryButton.forceActiveFocus()
            break;
        default:
            // Do nothing
            debugText.text = "Default key Event ::Voice" + event.key;
            break;
        }
    }

    /* Debug text */
    Text{
        visible: false
        id: debugText
        x: 30; y: 30
        text: currentLanguage
        color: sttStyle.seperateLine.boldColor
    }
    function goToInitialError(){
        main.state = "initial_error"
        main.forceActiveFocus();
    }
    function printLog(str){
        if(_DEBUG)
            sigSendText(str)
    }
    function printWarningLog(str){
        if(_DEBUG)
            sigSendWarningText(str)
    }
    function startSTTPlugin(){ // this is the start point to activate stt Plugin.
        if(!main.isShow) return;

        printWarningLog("connectionmanagerService.isReceiveResponse: " + connectionmanagerService.isReceiveResponse);
        printWarningLog("connectionmanagerService.isInternetConnectionAvailable: " + connectionmanagerService.isInternetConnectionAvailable);
        printWarningLog("main.isActivated: " + main.isActivated);

        printWarningLog("localeString.languageList.length : " + localeString.languageList.length);
        printWarningLog('LocaleService Load Start')
        if (!translateLoaded)
            localeServiceLoader.setSource('./LocaleService.qml')

        if(main.isActivated && selectedLanguage) {
            /* Retry case */
                resultListButton1.text = "";
                resultListButton2.text = "";
                resultListButton3.text = "";
                resultTextArray = undefined;
                main.state = "init";
                checkingRemainingTimeTimer.stop();
                if(selectedLanguage === "notSupported")
                {
                    stopSpinner();
                    currentLanguage =  getSystemSettings.menuLanguage;
                    main.state = "event_unsupportedLang";
                    checkingRemainingTimeTimer.restart();
                    guideText.text = stringSet.strings["The function is not available in the current keyboard language."];
                }
                else
                    currentLanguage = selectedLanguage;
                langSelectListModel.restoreSelection(selectedLanguage);
                isLanguagedChanged = false;
                if(selectedLanguage !== "notSupported")
                    callSttService();
        } else {

            function afterCheckLocaleString(){
                localeString.localeStringReadyChanged.disconnect(afterCheckLocaleString)

                printWarningLog("[afterCheckLocaleString] voiceLanguage: " + getVoiceLanguage.voiceLanguage);
                if(getVoiceLanguage.voiceLanguage) {
                    processing();
                } else {
                    getVoiceLanguage.voiceLanguageChanged.connect(processing);
                    printWarningLog("[afterCheckLocaleString] getSystemSettings.menuLanguage : " + getSystemSettings.menuLanguage);
                    if(getSystemSettings.menuLanguage) {
                        var param = {
                                    "languageCodes": localeString.languageList,
                                    "subscribe":true
                                };
                        param.languageCodes.push(getSystemSettings.menuLanguage);


                        getVoiceLanguage.cancel();
                        getVoiceLanguage.callService(param);

                    } else {
                        getSystemSettings.cancel();
                        getSystemSettings.callService({"keys":["localeInfo"], "subscribe":true});
                    }
                }
            }

            if(localeString.localeStringReady){
                afterCheckLocaleString()
            }else{
                localeString.getLocaleLanguage()
                localeString.localeStringReadyChanged.connect(afterCheckLocaleString)
            }
        }

        function processing() {
            getVoiceLanguage.voiceLanguageChanged.disconnect(processing);

            /* Activation case */
            voiceLanguage = getVoiceLanguage.voiceLanguage;

            // List set
            setLangSelectList();

            // set voice recognition language set on Settings app
//            if(voiceLanguage === "cmn-Hans-CN") voiceLanguage = "zh-Hans-CN";
//            else if(voiceLanguage === "yue-Hant-HK") voiceLanguage = "zh-Hant-HK";
//            else if(voiceLanguage === "cmn-Hant-TW") voiceLanguage = "zh-Hant-TW";

            // set selection to voiceLanguage
            selectedLanguage = voiceLanguage;

            if(selectedLanguage === "notSupported")
                currentLanguage =  getSystemSettings.menuLanguage;
            else
                currentLanguage = selectedLanguage;

            langSelectListModel.setSelectedByLangCode(selectedLanguage);

            // set selected language on stt plugin
            printWarningLog("selectedLanguage: " + selectedLanguage);

            printLangSelectList();

            main.forceActiveFocus();

            if(connectionmanagerService.isReceiveResponse){
                networkCheckFunc();
            }
            else{
                connectionmanagerService.isReceiveResponseChanged.connect(networkCheckFunc);
            }

            function networkCheckFunc(){
                connectionmanagerService.isReceiveResponseChanged.disconnect(networkCheckFunc);
                if(connectionmanagerService.isInternetConnectionAvailable){
                    if(selectedLanguage === "notSupported")
                    {
                        if(langSelectListModel.count == 1)
                        {
                            main.state = "event_changekeyboardLang"
                        }
                        else
                            main.state = "event_unsupportedLang";
                    }
                    else
                        main.state = "init";
                }else{
                    main.state = "event_networkdisconnection"
                }

                if(main.state === "init")
                    callCheckBluetoothService();
                else{
                    checkingRemainingTimeTimer.restart();
                    if(main.state == "event_networkdisconnection")
                        guideText.text = stringSet.strings["Network connection unavailable. Would you like to go to Network Settings to check the connection?"];
                    else
                        guideText.text = stringSet.strings["The function is not available in the current keyboard language."];
                    isActivated = true;
                    checkBeforeShow()
                }
            }
        }
    }

    function checkBeforeShow(){
        if (translateLoaded) {
            printWarningLog('########## localeServiceLoader. already Loaded')
            printWarningLog('########## show the STTView')
            canShowSTTView()
        } else {
            printWarningLog('########## localeServiceLoader. not Loaded yet')
            translateLoadedChanged.connect(canShowSTTView)
        }
    }

    function calculateHandleHeight() {

        if(langSelectListView != undefined) {
            if(langSelectListView.contentHeight === 0)
                return;
            if(langSelectListView.height < langSelectListView.contentHeight) {
                var heightRatio = langSelectListView.height / langSelectListView.contentHeight;
                scrollMidBarImg.height = Math.max (20, (heightRatio * scrollMidBar.height));
            } else {
                scrollMidBarImg.height = scrollMidBar.height;
            }
        }
    }
    function restartSttService() {
        if(needCancelAPI())
        {
            var param = {
                "voiceTicket": voiceTicket
            };
            param = JSON.stringify(param);
            printWarningLog("restartSttService");
            printWarningLog("voiceTicket: " + voiceTicket);
            sttCancelService.call("luna://com.webos.service.voiceconductor","/cancelRecognition",param);
            printWarningLog("nlp cancel is called.   startSTT_state: " + startSTT_state);
            sttService.cancel();
        }
        startSTTPlugin();
    }


    /* Call Service Method */

    /* Call Service Method */
    function callGetAppIdService() {
        printWarningLog("callGetAppIdService()")
        getAppIdService.call("luna://com.webos.service.applicationmanager","/getForegroundAppInfo","{\"extraInfo\": true}")
    }

    function callCheckBluetoothService() {
        printWarningLog("callCheckBluetoothService()")
        checkBluetoothService.call("luna://com.webos.service.bluetooth2/adapter", "/getStatus", "{}");
    }
    function callCheckMRCUPairService() {
        printWarningLog("callCheckMRCUPairService()")
        checkMRCUPairService.call("luna://com.webos.service.mrcu","/getConnectionStatus", "{}");
    }

    function callSttService() {
        printWarningLog("callSttService()")
        printWarningLog("selectedLanguage: " + selectedLanguage);
        var targetSttLang;
        var param = {};

        if (selectedLanguage) {
//            if(selectedLanguage == "zh-Hans-CN") targetSttLang = "cmn-Hans-CN";
//            else if(selectedLanguage == "zh-Hant-HK") targetSttLang = "yue-Hant-HK";
//            else if(selectedLanguage == "zh-Hant-TW") targetSttLang = "cmn-Hant-TW";
//            else targetSttLang = selectedLanguage;

            targetSttLang = selectedLanguage;

            param = {
                "subscribe": true,
                "language": targetSttLang,
                "runVoiceUi": false
            }

            param = JSON.stringify(param);

            sttService.call("luna://com.webos.service.voiceconductor", "/system/recognizeVoiceWithDetails", param);
        } else {
            param = {
                "subscribe": true,
                "language": "en-US",
                "runVoiceUi": false
            }
            param = JSON.stringify(param);
            sttService.call("luna://com.webos.service.voiceconductor", "/system/recognizeVoiceWithDetails", param);
        }
    }
    function launchEula() {
        launchEULA.call("luna://com.webos.service.applicationmanager", "/launch", "{\"id\": \"com.webos.app.firstuse-overlay\", \"params\": {\"target\": \"eula\",\"context\": \"voice\"}}")
    }

    function launchSettings() {
        if(main.state === "event_networkdisconnection")
            launchAppService.call("luna://com.webos.service.applicationmanager", "/launch", "{\"id\": \"com.webos.app.firstuse-overlay\", \"params\": {\"target\": \"network\"}}")
        else
            launchAppService.call("luna://com.webos.service.applicationmanager", "/launch", "{\"id\": \"com.palm.app.settings\", \"params\": {\"target\": \"Language\"}}")

        backToKeyboardPressed();
    }

    Service {
        id: launchAppService;
        appId: "com.webos.service.ime.stt"

        onError: {
            printLog("onError():");
            console.trace();
        }
    }

    function createAlert(title, message, buttons) {
        message = message.replace(/\"/g,"\\\"");
        title = title.replace(/\"/g,"\\\"");
        createAlertService.call("palm://com.webos.notification","/createAlert","{\"title\":\"" + title + "\",\"message\":\"" + message + "\",\"buttons\":" + buttons + "}");

    }
    function needCancelAPI() {
        if(main.state === "event_unsupportedLang")
            return false;
        else
            return true;
    }

    function loadLanguageText() {
        printLog("=== loadLanguageText() ===");
        playSpinner();
    }
    function playSpinner() {
        spinner.play();
        spinnerTimer.start();
    }
    function stopSpinner() {
        spinner.stop();
    }

    function setLangSelectList() {
        printLog("=== setLangSelectList() ===");

        printLog("getSystemSettings.menuLanguage: " + getSystemSettings.menuLanguage);
        printLog("getVoiceLanguage.voiceLanguage: " + getVoiceLanguage.voiceLanguage);
        printLog("getVoiceLanguage.retVal: " + getVoiceLanguage.retVal);

        printLog("voiceLanguage: " + voiceLanguage);
        printLog("getLanguageName(voiceLanguage): " + getLanguageName(voiceLanguage));
        printLog("PluginProxy.vkbLangList: " + PluginProxy.vkbLangList.toString());
        addSttLanguage(getLanguageName(voiceLanguage));

        for(var i=0; i<PluginProxy.vkbLangList.length;i++){
            addSttLanguage(PluginProxy.vkbLangList[i])
        }

        calculateHandleHeight();
    }

    // voiceLanguage has country code and language name (ex. en-US)
    // vkbLanguage has only language name -> no need to call this function (ex. en, ko, es, ...)
    function getLanguageName(countryLangCode){
        printLog("=== getLanguageName ===");
        printLog("countryLangCode: " + countryLangCode);
        if(countryLangCode == "cmn-Hans-CN") return "zh-Hans";
        else if(countryLangCode == "yue-Hant-HK") return "zh-Hant";
        else if(countryLangCode == "cmn-Hant-TW") return "zh-Hant";
        else if(countryLangCode == "notSupported") return "notSupported";
        else return countryLangCode.slice(0,2);
    }
    function addSttLanguage(vkbLanguage) {

        if(vkbLanguage === undefined || vkbLanguage === "")
            return;
        //TODO
        // uz-Latn(there is no one matched in STT Language List), zh-Hans, zh-Hant, ja( jp-JP in STT Language List)
        // may be it needs to changed to switch-case routine
        console.log(" >>>>> addSttLanguage :: localeString.localeStringReady : "+localeString.localeStringReady)

        var sttLangList = localeString.getSTTLangList()

         console.log(" >>>>> addSttLanguage :: sttLangList.length : "+sttLangList.length)
        for (var i = 0; i < sttLangList.length; i++) {
            var langCode = sttLangList[i];
            var lang, region;

            if(langCode === "zh-Hans-CN" || langCode === "cmn-Hans-CN"){
                lang = "zh-Hans";
                region = "CN";
            } else if(langCode === "zh-Hant-TW" || langCode === "cmn-Hant-TW") {
                lang = "zh-Hant";
                region = "TW";
            } else if(langCode === "zh-Hant-HK" || langCode === "yue-Hant-HK") {
                lang = "zh-Hant";
                region = "HK";
            } else {
                lang = langCode.slice(0,2);
                region = langCode.slice(3);
            }

            printLog(" @@@@@@@@@@@@@@@@@@@@@@@@@@@@ addSttLanguage vkbLanguage : "+vkbLanguage+"  lang : "+lang)
            if(vkbLanguage === "notSupported"){
                printLog("add not supported ");
                langSelectListModel.add(vkbLanguage);
                break;
            }else if(vkbLanguage === lang) {
                printLog("add this to LangSelectList : " + langCode);
                langSelectListModel.add(langCode);
            }
        }
    }
    function printLangSelectList() {
        for( var i = 0; i< langSelectListModel.count; i++){
            printLog("langSelectListModel.get(" + i + ").code : " + langSelectListModel.get(i).code);
            printLog("langSelectListModel.get(" + i + ").languageName : " + langSelectListModel.get(i).languageName);
            printLog("langSelectListModel.get(" + i + ").isSelected : " + langSelectListModel.get(i).isSelected);
        }
    }

    // check whether previous selected language is on the list or not.
    // on the list : return index
    // not on the list : return 0 (it means voice recognition language set on Settings App.
    function checkPrevSelectedLang(selectedLang) {
        for (var i = 0; i < langSelectListModel.count; i++) {
            var item = langSelectListModel.get(i);
            if(selectedLang === item.code) {
                return item.index;
            }
        }
        return -1;
    }

    function updateGuideLangText() {
        printLog("=== updateGuideLangText ===")
        printLog("guideLangText.spacing: \""+ guideLangText.spacing + "\"")
        printLog("guideLangText.imgString: " + guideLangText.imgString)

        guideLangText.imgString = ""

        if(resolution === "uhd")
            guideLangText.imgString = "\u202A<img src=\"images/stt_icon_keyhelp_down_4k.png\">\u202C"
        else
            guideLangText.imgString = "\u202A<img src=\"images/stt_icon_keyhelp_down.png\">\u202C"
    }
    function handleErrors(errorCode, errorText) {
        printLog("=== handleErrors ===")
        var title;
        var message;
        var leftButton;
        var rightButton;
        var buttons;
        var onClick;
        var params;

        guideText.text = "";

        switch(errorCode) {
        case "6040" :
            guideText.text = stringSet.strings["Try again after update is complete."];
            break;
        case "6020" : // "STT Mic device connection fail"
            guideText.text = stringSet.strings["Mic connection is unstable."];
            break;
        case "6021" : // "STT Network server is not respoding"
        case "6023" : // "STT Network unreachable"
        case "6032" : // errorText: NLP service not initialized
            guideText.text = stringSet.strings["Network server is not Responding. Try again."];
            break;
        case "6022" : // "STT Voice recognition server is not responding"
            guideText.text = stringSet.strings["Voice recognition server is not responding. Try again."];
            break;
        case "6027" : // "STT No results"
            guideText.text = stringSet.strings["Voice is not recognized. Try again."];
            break;
        case "6045" : // errorText : "Voice is loudly"
            guideText.text = stringSet.strings["Voice is not recognized. Keep your distance from the remote control and speak again."];
            break;
        case "6034" : // errorText: Wired lan cable connection needed
        case "6035" : // errorText: Wireless connection unstable
        case "6036" : // errorText: Network configuration needed
            title = "";
            message = stringSet.strings["Do you want to go to \"Network Settings\" now to check the connection?"];
            leftButton = "{\"position\":\"left\",\"label\":\"" + stringSet.strings["NO"] + "\"}";
            rightButton = "{\"position\":\"left\",\"label\":\"" + stringSet.strings["YES"] + "\"," + "\"onclick\": " + "\"palm://com.webos.service.applicationmanager/launch\"" + "," + "\"params\": " + "{\"id\":\"com.palm.app.settings\",\"params\":{\"target\":\"network\"}}" + "}";
            buttons = "[" + leftButton + "," + rightButton + "]";
            createAlert(title, message, buttons);
            break;
        case "6038" : // errorText: End-User license agreement needed
            launchEula();
            break;
        default :
            guideText.text = errorText;
            break;
        }

        if (0 < guideText.text.length){
            checkBeforeShow()
        }

        remainSeconds = 30;
        checkingRemainingTimeTimer.restart();
    }

    /// SLOT ///
    function slotCursorOn() {
        printWarningLog("=== slotCursorOn() ===")
        isCursorOn = true;
        switch(state){
        case "event_networkdisconnection":
        case "event_changekeyboardLang":
        case "event_error":
            main.forceActiveFocus();
            break;
        case "event_langSelect":
            langSelectBox.focusOut();
            break;
        case "event_sessionEnd_0":
        case "event_sessionEnd_2":
        case "event_sessionEnd_3":
            resultListBox.focusOut();
            break;
        default:
            printWarningLog("Cursor on state : " + state)
        }
    }
    function slotCursorOff() {
        printWarningLog("=== slotCursorOff() ===")
        isCursorOn = false;
        switch(state){
        case "event_networkdisconnection":
        case "event_changekeyboardLang":
            guideRetryButton.forceActiveFocus();
            break;
        case "event_error":
            main.forceActiveFocus();
            break;
        case "event_sessionEnd_0":
        case "event_sessionEnd_2":
        case "event_sessionEnd_3":
            resultListBox.focusInit();
            break;
        default:
            printWarningLog("Cursor on state : " + state)
        }
    }

    // FUNCTION called when language loading is completed
    function slotLanguageChanged() {
        printLog("=== slotLanguageChanged() ===")
        if(main.state === "event_energyLevel" || main.state === "event_error" ||
                main.state === "sttConnecting") {
            printLog("stopSpinner();")
            stopSpinner();
        } else {
            isLanguagedChanged = true;
            spinnerTimer.restart();
        }
    }

    states: [
        State {
            name: "init"
            PropertyChanges { target: micRec; state: "off" }
            PropertyChanges { target: guideText; visible: false}
            PropertyChanges { target: guideLangText; visible: false}
        },
        State {
            name: "off"
            PropertyChanges { target: micRec; state: "off" }
            PropertyChanges { target: sayAgainButton; opacity: 0 }
            PropertyChanges { target: guideText; visible: true}
            PropertyChanges { target: guideLangText; visible: true}
            PropertyChanges { target: guideRetryButton; visible: false}
        },
        State {
            name: "initial_error"
            PropertyChanges { target: micRec; state: "error" }
            PropertyChanges { target: sayAgainButton; opacity: 1 }
            PropertyChanges { target: guideImage; visible: false }
            PropertyChanges { target: guideText; visible: true}
            PropertyChanges { target: guideRetryButton; visible: false}
            PropertyChanges { target: guideLangText; visible: false}
        },
        State {
            name: "event_error"
            PropertyChanges { target: micRec; state: "hide" }
            PropertyChanges { target: sayAgainButton; opacity: 1 }
            PropertyChanges { target: guideImage; visible: false }
            PropertyChanges { target: guideText; visible: true}
            PropertyChanges { target: guideRetryButton; visible: true}
            PropertyChanges { target: guideLangText; visible: false}
        },
        State {
            name: "event_sttStart"
            PropertyChanges { target: micRec; state: "ready" }
            PropertyChanges { target: sayAgainButton; opacity: 0}
            PropertyChanges { target: guideText; visible: true}
            PropertyChanges { target: guideLangText; visible: true}
        },
        State {
            name: "event_unsupportedLang"
            PropertyChanges { target: micRec; state: "error" }
            PropertyChanges { target: sayAgainButton; opacity: 0}
            PropertyChanges { target: guideText; visible: true}
            PropertyChanges { target: guideLangText; visible: true}
        },
        State {
            name: "event_changekeyboardLang"
            PropertyChanges { target: micRec; state: "hide" }
            PropertyChanges { target: sayAgainButton; opacity: 1 }
            PropertyChanges { target: guideImage; visible: false }
            PropertyChanges { target: guideText; visible: true}
            PropertyChanges { target: guideRetryButton; visible: true}
            PropertyChanges { target: guideLangText; visible: false}
        },
        State {
            name: "event_networkdisconnection"
            PropertyChanges { target: micRec; state: "hide" }
            PropertyChanges { target: sayAgainButton; opacity: 1 }
            PropertyChanges { target: guideImage; visible: false }
            PropertyChanges { target: guideText; visible: true}
            PropertyChanges { target: guideRetryButton; visible: true}
            PropertyChanges { target: guideLangText; visible: false}
        },
        State {
            name: "event_langSelect"
            PropertyChanges { target: micRec; state: "langSelect"; opacity: 0.0 }
            PropertyChanges { target: sayAgainButton; opacity: 0}
            PropertyChanges { target: guideText; visible: false}
            PropertyChanges { target: guideLangText; visible: false}
            PropertyChanges { target: langSelectBox; visible: true}

        },
        State {
            name: "event_energyLevel"
            PropertyChanges { target: micRec; state: "energyLevel" }
            PropertyChanges { target: sayAgainButton; opacity: 0}
            PropertyChanges { target: guideText; visible: true}
            PropertyChanges { target: guideLangText; visible: true}
        },
        State {
            name: "event_sttConnecting"
            PropertyChanges { target: micRec; state: "processing" }
            PropertyChanges { target: guideLangText; visible: false}
        },
        State {
            name: "event_sttResult"
            PropertyChanges { target: micRec; state: "hide" }
        },
        State {
            name: "event_sessionEnd_0"
            PropertyChanges { target: micRec; state: "error" }
            PropertyChanges { target: guideText; visible: true}
            PropertyChanges { target: guideLangText; visible: true}
            PropertyChanges { target: sayAgainButton; opacity: 1 }
        },
        State {
            name: "event_sessionEnd_1"
            PropertyChanges { target: resultListBox; visible: true }
            PropertyChanges { target: micRec; state: "hide" }
            PropertyChanges { target: guideText; visible: 0}
            PropertyChanges { target: guideLangText; visible: false}
            PropertyChanges { target: sayAgainButton; opacity: 1 }
        },
        State {
            name: "event_sessionEnd_2"
            PropertyChanges { target: resultListBox; visible: true }
            PropertyChanges { target: resultTitle; opacity: 1 }
            PropertyChanges { target: resultListButton1; opacity: 1 }
            PropertyChanges { target: resultListButton2; opacity: 1 }
            PropertyChanges { target: sayAgainButton; opacity: 1 }

            PropertyChanges { target: micRec; state: "hide" }
            PropertyChanges { target: guideText; visible: false}
            PropertyChanges { target: guideLangText; visible: false}
        },
        State {
            name: "event_sessionEnd_3"
            PropertyChanges { target: resultListBox; visible: true }
            PropertyChanges { target: resultTitle; opacity: 1 }
            PropertyChanges { target: resultListButton1; opacity: 1 }
            PropertyChanges { target: resultListButton2; opacity: 1 }
            PropertyChanges { target: resultListButton3; opacity: 1 }
            PropertyChanges { target: sayAgainButton; opacity: 1 }

            PropertyChanges { target: micRec; state: "hide" }
            PropertyChanges { target: guideText; visible: false}
            PropertyChanges { target: guideLangText; visible: false}

        }
    ]
    transitions: [
        Transition {
            to: "event_sttConnecting"
            ScriptAction {
                script: {
                    ttsService.speakByAudioGuidance(stringSet.strings["Loading"], currentLanguage);
                }
            }
        }
    ]
}
