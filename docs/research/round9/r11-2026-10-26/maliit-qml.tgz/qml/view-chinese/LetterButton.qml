/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "../keyboard-common"

ButtonBase {
    id: letterButton
    objectName: "letterButton"
    property string mode: "Normal"
    property string mainChar    /* display character */
    property string shiftedChar
    property string symbolChar
    property string rawcode        /* code sening to engine */
    property string shiftRawcode
    signal sendKey(string rawcode, bool shift, int eventType)
    signal sendText(string text)

    function checkState(text) {
        return (text.length > 0) ? "Normal" : "Disable";
    }

    text: getCurrentText(mode)
    state: checkState(text)
    onTextChanged: state = checkState(text)

    onReleased: {
        switch (mode) {
        case "Normal":
            sendKey(rawcode, false, eventType);
            break;
        case "Normal-Shift":
            sendKey(shiftRawcode, true, eventType);
            break;
        case "Symbol":
            sendText(text);
            break;
        default:
            console.warn("Error! main.mode is " + main.mode);
        }
    }

    function getCurrentText(mode) {
        var t;

        switch (mode) {
        case "Normal":
            t = mainChar;
            break;
        case "Normal-Shift":
            t = shiftedChar;
            break;
        case "Symbol":
            t = symbolChar;
            break;
        default:
            t = "";
        }

        return (t !== undefined) ? t : "";
    }

    Connections {
        target: PluginProxy
        onKeyReleased : {
            if (isReleased && (letterButton.state === "Select"))
                letterButton.state = "Focus";
        }
    }
}
