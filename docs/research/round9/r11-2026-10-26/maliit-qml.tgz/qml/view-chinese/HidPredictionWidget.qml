/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import com.meego.maliit 1.0
import "../keyboard-common"
import "languages.js" as Languages

Rectangle {
    id: root
    objectName: "hidPredictionWidget"
    property variant predictions: Suggestion.list
    property variant predictionSlice
    property int maxLengthChar: 50
    property int lengthChar
    property int maxCnt: 8
    property int pageCnt: 1
    property int head: 0
    property int cnt: 0
    property int reminder: 0

    property bool isNext: Suggestion.next
    property bool isPrevious: Suggestion.previous
    property string currentLanguage: ""

    signal orientationChanged(string orientation)

    color: style.bgColor
    radius: style.radius

    function setFocusItem(item,x,y) {
        focusRect.image = "";
        focusRect.visible = true;
        focusRect.width =  item.state === "Select"? focusRect.width  * focusRect.focusStyle.selectRatio : item.width  + focusRect.focusStyle.widthOffset;
        focusRect.height = item.state === "Select"? focusRect.height * focusRect.focusStyle.selectRatio : item.height + focusRect.focusStyle.heightOffset;
        focusRect.x = x - (focusRect.width - item.width)/2;
        focusRect.y = y - (focusRect.height - item.height)/2;
        focusRect.focusTxt = item.wordText;
        focusRect.hotKeyText = item.hotKeyText;
        focusRect.fontSize = item.fontSize;
    }

    function focusOut() {
        focusRect.visible = false;
        focusRect.focusTxt = "";
        focusRect.hotKeyText = "";
        focusRect.image = "";
    }

    function updateHeight() {
        Keyboard.setPanelSize(style.hidPredWidth, style.hidPredHight);
        height = style.hidPredHight;
    }

    function setMovableArea() {
        Keyboard.setMovableArea(Maliit.MovableAreaLeft, 0, 0, 0, 0);
        Keyboard.setMovableArea(Maliit.MovableAreaTop, 0, 0, 0, 0);
        Keyboard.setMovableArea(Maliit.MovableAreaRight, 0, 0, 0, 0);
        Keyboard.setMovableArea(Maliit.MovableAreaBottom, 0, 0, 0, 0);
    }

    onPredictionsChanged: splitSlice()

    onOrientationChanged: {
        if (orientation.includes("portrait"))
        {
            setMovableArea();
            root.maxCnt = 5;
            maxLengthChar = 30;
            Suggestion.noSuggestions = 5;
        }
        else
        {
            maxCnt = 8;
            maxLengthChar = 50;
            Suggestion.noSuggestions = 8;
        }
        updateHeight();
        splitSlice();
        focusOut();
    }

    ListModel {
        id: cntArray
    }

    HidPredictionItem {
        id: prevButton
        objectName: "prevButton"
        anchors.top: parent.top
        anchors.topMargin: style.hidTopMargin
        anchors.left: parent.left
        anchors.leftMargin: style.hid.hidPreButton.leftMargin
        width: style.hid.hidPreButton.width
        height: style.hid.hidPreButton.height
        wordText: "<"   // FIXME: this should be replaced with image file.
        hotKeyText: "F10"
        onReleased: showPrevSuggestion()

        onStateChanged: {
            switch(state) {
                case "Focus":
                case "Select":
                    focusRect.focusStyle = style.panelFocus;
                    root.setFocusItem(prevButton, prevButton.x,prevButton.y);
                    break;
                case "Disable":
                    root.focusOut();
                    break;
                default:
                    break;
            }
        }
        onExited: root.focusOut()
    }

    Row {
        id: predictionRow
        objectName: "predictionRow"
        anchors.top: parent.top
        anchors.topMargin: style.hidTopMargin
        anchors.left: prevButton.right
        anchors.leftMargin: style.hid.hidPredRow.leftMargin
        spacing:style.hid.hidPredRow.cellSpace
        width:  style.hid.hidPredRow.width
        height: style.hid.hidPredRow.height

        Repeater {
            id: predictionRepeater
            objectName: "predictionRepeater"
            model: predictions
            onItemRemoved: item.removed = true
            HidPredictionItem {
                width: cntArray && cntArray.get(pageCnt-1)
                       ? (
                             (((cntArray.get(pageCnt) && (cntArray.get(pageCnt).cnt === 0)) || pageCnt === cntArray.count) && cntArray.get(pageCnt-1).cnt !== maxCnt)
                             ? (wordWidth + 2 * style.hid.hidPredRow.leftMargin)
                             : (predictionRow.width + style.hid.hidPredRow.cellSpace - style.hid.hidPredRow.cellSpace * cntArray.get(pageCnt-1).cnt) * (predictions[index].length + 2) / cntArray.get(pageCnt-1).lengthChar
                         )
                       : 0
                height: style.hid.hidPredItem.height
                wordText: modelData
                hotKeyText: "F" + (index + 1)
                onReleased: selectSuggestion(index)
                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            focusRect.focusStyle = style.panelFocus;
                            root.setFocusItem(predictionRepeater.itemAt(index), predictionRepeater.itemAt(index).x + prevButton.width +  style.hid.hidPreButton.leftMargin + style.hid.hidPredRow.leftMargin,
                                              predictionRepeater.itemAt(index).y + style.hidTopMargin);
                            break;
                        default:
                            break;
                    }
                }
                onExited: root.focusOut()
            }
        }
    }

    HidPredictionItem {
        id: nextButton
        objectName: "nextButton"
        anchors.top: parent.top
        anchors.topMargin: style.hidTopMargin
        anchors.left:predictionRow.right
        anchors.leftMargin: style.hid.hidNextButton.leftMargin
        width:  style.hid.hidNextButton.width
        height: style.hid.hidNextButton.height
        wordText: ">"   // FIXME: this should be replaced with image file.
        hotKeyText: "F11"
        borderPosition: 0
        onReleased: showNextSuggestion()

        onStateChanged: {
            switch(state) {
                case "Focus":
                case "Select":
                    focusRect.focusStyle = style.panelFocus;
                    root.setFocusItem(nextButton, nextButton.x,nextButton.y);
                    break;
                case "Disable":
                    root.focusOut();
                    break;
                default:
                    break;
            }
        }
        onExited: root.focusOut()
    }

    HidPredictionItem {
        id: hidModeButton
        objectName: "hidModeButton"
        anchors.top: parent.top
        anchors.topMargin: style.hidTopMargin
        anchors.right: parent.right
        anchors.rightMargin: style.hid.hidModeButton.rightMargin
        width:  style.hid.hidModeButton.width
        height: style.hid.hidModeButton.height
        wordText: getInputModeString()
        hotKeyText: "F12"
        borderPosition: 0
        onReleased: modeButtonPressed()
        onStateChanged: {
            switch(state) {
                case "Focus":
                case "Select":
                    focusRect.focusStyle = style.panelFocus;
                    root.setFocusItem(hidModeButton, hidModeButton.x,hidModeButton.y);
                    break;
                case "Disable":
                    root.focusOut();
                    break;
                default:
                    break;
            }
        }
        onExited: root.focusOut()
    }

    FocusPanel {
        id: focusRect
        objectName: "focusRect"
        focusStyle: style.focus
        visible: false
    }

    function onSendKey(keycode) {

        if (keycode === Qt.Key_F12) {
            modeButtonPressed();
            return;
        }

        if (keycode < Qt.Key_F1 || Qt.Key_F12 < keycode)
            return;

        if (keycode === Qt.Key_F10)
            showPrevSuggestion();
        else if (keycode === Qt.Key_F11)
            showNextSuggestion();
        else {
            var selectedIndex = keycode - Qt.Key_F1;
            selectSuggestion(selectedIndex);
        }
    }

    function modeButtonPressed() {
       Suggestion.onModeButtonPressed();
    }

    function setLanguage(language) {
        currentLanguage = language;
        if (language === Languages.SIMPLIFIED_CHINESE)
            hidModeButton.state = "Disable";
        else
            hidModeButton.state = "Normal";
    }

    function setFocusToHID() {
        root.focus = true;
    }

    function getInputModeString() {
        if (currentLanguage === Languages.SIMPLIFIED_CHINESE)
            return Languages.HID_PINYIN_INPUT_MODE;
        else if (currentLanguage === Languages.TRADITIONAL_CHINESE)
            return Keyboard.shifted ? Languages.HID_ZHUYIN_INPUT_MODE : Languages.HID_CANJIE_INPUT_MODE;
        else
            return Keyboard.shifted ? Languages.HID_CANJIE_INPUT_MODE : Languages.HID_ZHUYIN_INPUT_MODE;
    }

    onIsNextChanged: checkButtonState()
    onIsPreviousChanged: checkButtonState()

    function showNextSuggestion() {
        Suggestion.onNext();
    }

    function showPrevSuggestion() {
        Suggestion.onPrevious();
    }

    function selectSuggestion(index) {
        if (index >= 0 && index < predictions.length) {
            Suggestion.onSelected(index);
            head = 0;
        }
    }

    function splitSlice() {
        pageCnt = 1;
        head = 0;
        var i;
        var indexArray =0;
        var cnt = 0;
        var lengthChar = 0;
        reminder = predictions.length;
        i = cntArray.count-1;
        while (i>=0) {
            cntArray.setProperty(i, "cnt", 0);
            cntArray.setProperty(i, "lengthChar", 0);
            i--;
        }
        for (i=0; i<predictions.length; i++) {
            cnt++;
            lengthChar += (predictions[i].length +2);
            if (lengthChar + cnt < maxLengthChar && cnt < maxCnt) {
                if (cnt !== reminder)
                    continue;
            } else if (lengthChar + cnt >= maxLengthChar && cnt <= maxCnt) {
                cnt--;
                lengthChar -= (predictions[i--].length +2);
                reminder -= cnt;
            } else if (cnt === maxCnt) {
                reminder -= cnt;
            }
            if (cntArray.get(indexArray) && cntArray.get(indexArray).cnt === 0) {
                cntArray.setProperty(indexArray, "cnt", cnt);
                cntArray.setProperty(indexArray, "lengthChar", lengthChar);
            } else {
                cntArray.append({"cnt" : cnt, "lengthChar" : lengthChar});
            }
            indexArray++;
            lengthChar = 0;
            cnt = 0;
            continue;
        }
        if (cntArray.get(0)) {
            cnt = cntArray.get(0).cnt;
            checkButtonState();
        }
    }

    function checkButtonState() {
        // prev button
        if (isPrevious)
            prevButton.state = "Normal";
        else
            prevButton.state = "Disable";
            
        // next button
        if (isNext)
            nextButton.state = "Normal";
        else
            nextButton.state = "Disable";
    }
}
