/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import com.meego.maliit 1.0

import "../keyboard-common" as Common
import "languages.js" as Languages
import "../keyboard-common/commonvariables.js" as CommonVariables

Rectangle {
    id: root
    objectName: "normalKeyboard"
    color: style.bgColor
    opacity: style.opacity
    radius: style.radius

    property alias mode: leftFunctionArea.state
    property alias currLanguage: leftFunctionArea.currLanguage
    property alias enableVoiceButton: rightFunctionArea.enableVoiceButton
    property alias noWords: predictionArea.noWords
    property int enterKeyType: 0
    property int totalRowCount: 0
    property QtObject chineseStyle: []

    signal ttsService(string text)
    signal keyPressed(string rawcode, bool shift, int eventType)
    signal switchContext()
    signal shiftPressed(string state)
    signal textKeyPressed(string text)
    signal symbolPressed(string state)
    signal activateSTT()
    signal clearAllPressed()
    signal meetTopBoundary()
    signal meetBottomBoundary()
    signal orientationChanged(string orientation)

    onEnabledChanged: {
        if (enabled) {
           CommonVariables.savedFocusItem = getFirstItem();
        }
    }

    onOrientationChanged: {
        updateHeight();
        setNumberOfSuggestions();
        if (orientation.includes("portrait"))
            setMovableArea();
        else
            removeMovableArea();

        middleLayoutArea.updateLayoutData();
        strokeLayoutArea.updateStrokeLayout();
        bottomArea.updateBottomLayout();
        predictionArea.updatePredictLayout();

        updateFocusItem();
    }

    function updateHeight() {
        var newHeight = style.keyboardDefaultHeight + (noWords?0:style.predictPanel.height);
        Keyboard.setPanelSize(normalKeyboard.width, newHeight);
        height = newHeight;
    }

    function setMovableArea() {
        var marginTop = noWords ? 0 : style.predictPanel.height;
        var right_area_w = style.keyboardDefaultWidth - style.left.leftMargin - style.left.width - style.middle.leftMargin
                         - style.middle.width - style.right.leftMargin - style.right.width;
        var right_area_x = style.keyboardDefaultWidth - right_area_w;
        var bottom_area_y = normalKeyboard.height - style.bottom.bottomMargin;

        Keyboard.setMovableArea(Maliit.MovableAreaLeft, 0, marginTop, style.left.leftMargin, style.keyboardDefaultHeight);
        Keyboard.setMovableArea(Maliit.MovableAreaTop, 0, marginTop, style.keyboardDefaultWidth, style.middle.topMargin);
        Keyboard.setMovableArea(Maliit.MovableAreaRight, right_area_x, marginTop, right_area_w, style.keyboardDefaultHeight);
        Keyboard.setMovableArea(Maliit.MovableAreaBottom, 0, bottom_area_y, style.keyboardDefaultWidth, style.bottom.bottomMargin);
    }

    function removeMovableArea() {
        Keyboard.setMovableArea(Maliit.MovableAreaLeft, 0, 0, 0, 0);
        Keyboard.setMovableArea(Maliit.MovableAreaTop, 0, 0, 0, 0);
        Keyboard.setMovableArea(Maliit.MovableAreaRight, 0, 0, 0, 0);
        Keyboard.setMovableArea(Maliit.MovableAreaBottom, 0, 0, 0, 0);
    }

    function updateFocusItem()
    {
        var item = focusRect.focusedItem;
        if (focusRect.visible && item)
        {
            var xOffset = 0;
            var yOffset = 0;

            if (focusRect.focusedArea === "bottomRow")
            {
                xOffset = style.left.leftMargin;
                yOffset = style.left.topMargin + style.middle.height + style.bottom.topMargin;
            }
            else if (focusRect.focusedArea === "navButtons")
            {
                xOffset = style.left.leftMargin + style.left.width + style.middle.leftMargin + style.middle.width + style.right.leftMargin;
                yOffset = style.left.topMargin + style.middle.height + style.bottom.topMargin;
            }
            else if (focusRect.focusedArea === "chineseLeftColumn")
            {
                xOffset = style.left.leftMargin;
                yOffset = style.middle.topMargin;
            }
            else if (focusRect.focusedArea === "middleGrid" || focusRect.focusedArea === "numberGrid")
            {
                xOffset = style.left.leftMargin + style.left.width + style.middle.leftMargin;
                yOffset = style.middle.topMargin;
            }
            else if (focusRect.focusedArea === "strokeGrid")
            {
                xOffset = style.left.leftMargin + style.left.width + style.middle.leftMargin;
                yOffset = style.middle.topMargin + style.middle.cellHeight + style.middle.cellSpace;
            }
            else if (focusRect.focusedArea === "xcharGrid")
            {
                xOffset = style.left.leftMargin + style.left.width + style.middle.leftMargin;
                yOffset = style.middle.topMargin + 3 * style.middle.cellHeight + 2 * style.middle.cellSpace;
            }
            else if (focusRect.focusedArea === "rightColumn")
            {
                xOffset = style.left.leftMargin + style.left.width + style.middle.leftMargin + style.middle.width + style.right.leftMargin;
                yOffset = style.middle.topMargin;
            }
            else if (focusRect.focusedArea === "predictionBar")
            {
                if (!item.parent)
                {
                    setFocusOut();
                    return;
                }
                xOffset = predictionArea.xOffset;
                yOffset = -((style.predictPanel.height - style.predictPanel.panelButton.height) / 2 + style.predictPanel.panelButton.height);
            }

            if (item.state === "Select") {
                var selectWidth  = (item.width  + focusRect.focusStyle.widthOffset)  * focusRect.focusStyle.selectRatio;
                var selectHeight = (item.height + focusRect.focusStyle.heightOffset) * focusRect.focusStyle.selectRatio;
                focusRect.width  = selectWidth  < item.width  ? item.width  : selectWidth;
                focusRect.height = selectHeight < item.height ? item.height : selectHeight;
            } else {
                focusRect.width  = item.width  + focusRect.focusStyle.widthOffset;
                focusRect.height = item.height + focusRect.focusStyle.heightOffset;
            }

            focusRect.x = xOffset + item.x - (focusRect.width - item.width)/2;
            focusRect.y = yOffset + item.y - (focusRect.height - item.height)/2 + (predictionArea.visible?predictionArea.height:0);
        }
        else
        {
            setFocusOut();
        }
    }

    function setFocusItem(item,x,y) {
        focusRect.image = "";
        focusRect.visible = true;
        focusRect.dotVisible = false;

        focusRect.focusedArea = item.parent.objectName;
        focusRect.focusedItem = item;
        // Space-bar "selection state" width will become lesser than its original width
        // if selection ratio directly applied.
        if (item.state === "Select") {
            var selectWidth  = focusRect.width  * focusRect.focusStyle.selectRatio;
            var selectHeight = focusRect.height * focusRect.focusStyle.selectRatio;
            focusRect.width  = selectWidth  < item.width  ? item.width  : selectWidth;
            focusRect.height = selectHeight < item.height ? item.height : selectHeight;
        } else {
            focusRect.width  = item.width  + focusRect.focusStyle.widthOffset;
            focusRect.height = item.height + focusRect.focusStyle.heightOffset;
        }

        focusRect.x = x - (focusRect.width - item.width)/2
        focusRect.y = y - (focusRect.height - item.height)/2 + (predictionArea.visible?predictionArea.height:0);
        focusRect.focusTxt = item.text;
        focusRect.fontSize = item.fontSize;
    }

    function setFocusOut() {
        focusRect.visible = false;
        focusRect.focusTxt = "";
        focusRect.image = "";
    }

    PredictionPanel {
        id: predictionArea
        objectName: "predictionArea"
        visible: !noWords
        anchors.left: parent.left
        anchors.top: parent.top
        height: style.predictPanel.height
        buttonStyle: style.predictPanel.panelButton
        width: root.width
        buttonHeight: style.predictPanel.panelButton.height
        constantPrediction: false
        onSendKey: root.keyPressed(keycode, shift, eventType)
        onTtsService: root.ttsService(text)
        onPredictionSlected: {
            root.getMiddleItem().focus = true;
        }

        onFocusItem: {
            focusRect.focusStyle = style.panelFocus;
            root.setFocusItem(item,x,y);
        }
        onFocusOut: root.setFocusOut()
        onMeetBottomBoundary: strokeLayoutArea.enabled? strokeLayoutArea.setKeyNavigation(0,0):
                                                        middleLayoutArea.setKeyNavigation(0,0)
        onMeetTopBoundary: root.meetTopBoundary()
        onVisibleChanged: {
            if (focusRect.visible) {
                if (visible) {
                    focusRect.y = focusRect.y+style.predictPanel.height;
                } else {
                    focusRect.y = focusRect.y-style.predictPanel.height;
                }
            }
        }
    }

    LeftFunctionArea {
        id: leftFunctionArea
        objectName: "leftFunctionArea"
        anchors.top: noWords? parent.top : predictionArea.bottom
        anchors.topMargin: style.left.topMargin
        anchors.left: parent.left
        anchors.leftMargin: style.left.leftMargin
        width: style.left.width
        height: style.left.height
        enabled: true

        Component.onCompleted: {
            languageButtonPressed.connect(switchContext);
            shiftClicked.connect(shiftPressed);
            symbolClicked.connect(symbolPressed);
        }

        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y)
        }
        onFocusOut: root.setFocusOut()

        onMeetRightBoundary: {
            if (strokeLayoutArea.enabled) {
                if (row == 2) row = 1
                strokeLayoutArea.setKeyNavigation(row,0)
            }
            else
                middleLayoutArea.setKeyNavigation(row, 0)
        }
        onMeetBottomBoundary: bottomArea.setKeyNavigation(1)
        onMeetLeftBoundary: rightFunctionArea.setKeyNavigation(row, "Left")
        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(1) :root.meetTopBoundary()
    }

    MiddleLayout {
        id: middleLayoutArea
        objectName: "middleLayoutArea"
        mode: root.mode
        anchors.top: noWords? parent.top : predictionArea.bottom
        anchors.topMargin: style.middle.topMargin
        anchors.left: leftFunctionArea.right
        anchors.leftMargin: style.middle.leftMargin
        width: style.middle.width
        height: style.middle.cellHeight*totalRowCount // add row count for spacing
        enabled: true
        z:1
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusOut: root.setFocusOut()
        onSendKey: root.keyPressed(rawcode, shift, eventType)
        onSendText: root.textKeyPressed(text)
        onMeetLeftBoundary: leftFunctionArea.setKeyNavigation(row)
        onMeetRightBoundary: rightFunctionArea.setKeyNavigation(row)
        onMeetBottomBoundary: bottomArea.setKeyNavigation(1)
        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(2) :root.meetTopBoundary()
    }

    StrokeLayout {
        id: strokeLayoutArea
        objectName: "strokeLayoutArea"
        mode: root.mode
        anchors.top: noWords? parent.top : predictionArea.bottom
        anchors.topMargin: style.middle.topMargin
        anchors.left: leftFunctionArea.right
        anchors.leftMargin: style.middle.leftMargin
        width: style.middle.width
        height: style.middle.cellHeight*totalRowCount
        enabled: false
        visible: enabled
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusOut: root.setFocusOut()
        onSendKey: root.keyPressed(rawcode, shift, eventType)
        onSendText: root.textKeyPressed(text)
        onMeetLeftBoundary: leftFunctionArea.setKeyNavigation(row)
        onMeetRightBoundary: {
            if(row === 2) row = 3;
            rightFunctionArea.setKeyNavigation(row)
        }
        onMeetBottomBoundary: bottomArea.setKeyNavigation(1)
        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(2) :root.meetTopBoundary()
    }

    Common.RightFunctionArea {
        id: rightFunctionArea
        objectName: "rightFunctionArea"
        anchors.left: middleLayoutArea.right
        anchors.leftMargin: style.right.leftMargin
        anchors.top: noWords? parent.top : predictionArea.bottom
        anchors.topMargin: style.right.topMargin
        width: style.right.width
        height: style.right.height
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusImage: focusRect.image = img
        onFocusOut: root.setFocusOut()

        Component.onCompleted: {
            clickVoiceButton.connect(activateSTT);
            clickClearAllButton.connect(clearAllPressed);
            sendKey.connect(keyPressed);
        }

       onMeetLeftBoundary: {
            if (row > 3) bottomArea.setKeyNavigation(1);
            else if(strokeLayoutArea.enabled)
                strokeLayoutArea.setKeyNavigation(row,-1)
            else
                middleLayoutArea.setKeyNavigation(row, -1)
        }
        onMeetRightBoundary: {
            if (row < 4) {
                leftFunctionArea.setKeyNavigation(row)
            } else {
               bottomArea.setKeyNavigation(-1);
            }
        }
        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(3) :root.meetTopBoundary()
        onMeetBottomBoundary:  bottomArea.setKeyNavigation(-2)
    }

    Common.BottomArea {
        id: bottomArea
        objectName: "bottomArea"
        anchors.left: root.left
        anchors.leftMargin: style.bottom.leftMargin
        anchors.top: leftFunctionArea.bottom
        anchors.topMargin: style.bottom.topMargin
        height: style.bottom.height
        width:  middleLayoutArea.width
        onSendKey: root.keyPressed(keycode === 57?89:keycode, shift, eventType)
        onTtsService: root.ttsService(text)
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusImage: focusRect.image = img
        onFocusOut: root.setFocusOut()

        onMeetTopBoundary: {
            if (column === -1)
                leftFunctionArea.setKeyNavigation(3);
            else if (column === -2)
                rightFunctionArea.setKeyNavigation(-1);
            else {
                if (strokeLayoutArea.enabled)
                    strokeLayoutArea.setKeyNavigation(3,5);
                else
                    middleLayoutArea.setKeyNavigation(-1, column, "Up");
            }
        }
        onMeetBottomBoundary: root.meetBottomBoundary()
    }

    Item {
        id: dragIconArea
        objectName:"dragIconArea"
        anchors.left: rightFunctionArea.right
        anchors.top: noWords? parent.top : predictionArea.bottom
        width: style.right.rightMargin
        height: noWords? parent.height : parent.height - predictionArea.height
        visible:  isPortrait

        Image {
            id: dragIcon
            source: style.getImage("ic_drag");
            smooth: true
            anchors.centerIn: dragIconArea
        }
    }

    Common.FocusPanel {
        id: focusRect
        objectName: "focusRect"
        focusStyle: style.focus
        visible: true
        z: 1
    }

    function setLanguage(language, data, resetFocus) {
        currLanguage = language;
        drawLayout(language, data);
        if (language === Languages.SIMPLIFIED_CHINESE)
            drawStrokeLayout(language,data);
        if (resetFocus) {
            root.setFocusOut();
            focusTimer.start();
        }
        mode = "Normal";
        gc();
    }

    function drawLayout(language, data) {

        var length = data.length;
        var column = data.column;
        var row = data.row;
        totalRowCount = data.row;

        // set layout to grid
        middleLayoutArea.setLayoutData(row, column, data.keys);
    }

    function drawStrokeLayout(language, data) {
        var length = data.length;
        var column = data.column;
        var row = data.row;
        var strokeColumn = 5;
        totalRowCount = data.row;

        state = "Normal-Shift";

        var numModel = [];
        for (var i = 0; i < column; i++) {
            numModel[i] = data.keys[i];
        }
        strokeLayoutArea.setNumGridData(column,numModel);

        var strokeModel = [];
        var sCount = strokeColumn + column;
        for (var j = 0; i < sCount; i++,j++) {
            strokeModel[j] = data.keys[i];
        }
        strokeLayoutArea.setStrokeGridData(strokeColumn,strokeModel);

        var xCharModel = [];
        var unUsedKeys = 5;
        var xCount = column + strokeColumn + column + unUsedKeys;
        i += unUsedKeys;
        for (var k = 0; i < xCount; i++,k++) {
            xCharModel[k] = data.keys[i];
        }
        strokeLayoutArea.setXcharGridData(column,xCharModel);
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Up || event.key === Qt.Key_Down)
            Keyboard.onHideRequested(false);
    }

    function setDefaultFocus() {
        if( middleLayoutArea.defaultFocus !== undefined ){
            CommonVariables.savedFocusItem.focus = false;
            CommonVariables.savedFocusItem = getFirstItem();
        }
    }

    function setFocusToEnter() {
        rightFunctionArea.setFocusTo("Enter");
    }

    function getFirstItem() {
        return strokeLayoutArea.enabled ? strokeLayoutArea.getFirstItem() : middleLayoutArea.getFirstItem();
    }

    function getMiddleItem() {
        return strokeLayoutArea.enabled ? strokeLayoutArea.getMiddleItem() : middleLayoutArea.getMiddleItem();
    }

    onModeChanged: {
        if (currLanguage === Languages.SIMPLIFIED_CHINESE && mode === "Normal-Shift") {
            strokeLayoutArea.enabled = true;
            middleLayoutArea.enabled = false;
            strokeLayoutArea.z = 1;
            middleLayoutArea.z = 0;
            CommonVariables.savedFocusItem = strokeLayoutArea.getMiddleItem()
        } else {
            middleLayoutArea.enabled = true;
            strokeLayoutArea.enabled = false;
            middleLayoutArea.z = 1;
            strokeLayoutArea.z = 0;
            CommonVariables.savedFocusItem = middleLayoutArea.getMiddleItem()
        }
    }

    Timer {
        id: focusTimer
        interval: 100
        repeat: true
        onTriggered: {
            var item = getFirstItem();
            item.focus = true;
            middleLayoutArea.setFocusIn(item, item.x, item.y);
            focusTimer.stop();
        }
    }
}
