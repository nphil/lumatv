/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

var SIMPLIFIED_CHINESE = "中文－简体";
var TRADITIONAL_CHINESE = "中文－繁體";
var TRADITIONAL_CHINESE_TW = "中文-台灣";
var PINYIN = "拼音";
var STROKE = "笔画";
var CANGJIE = "倉頡";
var ZHUYIN = "注音"; 

var HID_PINYIN_INPUT_MODE = "拼音";
var HID_CANJIE_INPUT_MODE = "倉頡";
var HID_ZHUYIN_INPUT_MODE = "注音";
