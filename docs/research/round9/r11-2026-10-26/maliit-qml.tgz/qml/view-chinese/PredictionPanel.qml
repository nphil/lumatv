/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "../keyboard-common"

Rectangle {
    id: root
    objectName: "predictionArea"
    property variant preColumn: "defaultIndex"
    property variant components: StrokeComponent.list
    property variant words: Suggestion.list
    property bool noWords: words == undefined || words.length <=0

    property var buttonStyle: style.predictPanel.panelButton
    property int buttonWidth
    property int buttonHeight
    property bool constantPrediction: false

    property bool isNext: Suggestion.next
    property bool isPrevious: Suggestion.previous

    property int xOffset: predictionBar.x

    signal predictionSlected()
    signal ttsService(string text)
    signal sendKey(int keycode, bool shift, int eventType)
    signal selectPrediction(int index, string word)
    signal focusItem(var item, int x, int y)
    signal focusOut()
    signal pressNext()
    signal pressPrev()
    signal meetLeftBoundary()
    signal meetRightBoundary()
    signal meetTopBoundary()
    signal meetBottomBoundary()

    color: style.predictPanel.bgColor
    opacity: style.predictPanel.opacity
    radius: style.predictPanel.radius

    function setFocusIn(item) {
        var xOffset = (root.width - predictionBar.width)/2;
        var yOffset = root.height - root.buttonStyle.focusOffset;
        root.focusItem(item, item.x + xOffset, item.y - yOffset);
    }

    function updatePredictLayout() {
        predictionBar.forceLayout();
    }

    onIsNextChanged: checkButtonState()
    onIsPreviousChanged: checkButtonState()

    function checkButtonState() {
        // prev button
        if (isPrevious)
            leftBtn.state = "Normal";
        else
            leftBtn.state = "Disable";

        // next button
        if (isNext)
            rightBtn.state = "Normal";
        else
            rightBtn.state = "Disable";
    }

    function setKeyNavigation(column) {
        if (column === 1) {
            predictionRepeater.itemAt(0).focus = true;
        } else
        if (column === 2) {
            predictionRepeater.itemAt(words.length/2).focus = true;
        } else
        if (column === 3) {
            predictionRepeater.itemAt(words.length-1).focus = true;
        }
    }

    // prediction words
    Row {
        id: predictionBar
        objectName: "predictionBar"
        visible: !predictionMode
        property int predictionIndex: -1
        spacing: style.predictPanel.cellSpace
        anchors.horizontalCenter: root.horizontalCenter
        anchors.verticalCenter : root.verticalCenter

        ButtonBase {
            id: leftBtn
            objectName: "leftBtn"
            buttonStyle: style.navButton
            anchors.verticalCenter : predictionBar.verticalCenter
            width:  style.predictPanel.navButton.width
            height: root.buttonHeight
            text: "<"
            noBorder:true
            state: "Disable"
            onReleased: {
                Suggestion.onPrevious();
                if (!Suggestion.previous) {
                    root.predictionSlected();
                }
            }

            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(leftBtn);
                        break;
                    case "Disable":
                        root.focusOut();
                    default:
                        break;
                }
            }
            Keys.onPressed: {
                if (event.key === Qt.Key_Right) {
                    predictionRepeater.itemAt(0).focus = true;
                    event.accepted = true;
                }
            }
        }

        Repeater {
            id: predictionRepeater
            objectName: "predictionRepeater"
            model: words
            ButtonBase {
                buttonStyle: root.buttonStyle
                borderPosition: 1
                text: modelData
                disableShadow: true
                height: root.buttonHeight
                width: {
                    if (constantPrediction) {
                        return root.buttonWidth;
                    } else {
                        return (contentWidth + style.predictPanel.minMargin) < style.predictPanel.constWidth?
                               style.predictPanel.constWidth: contentWidth + style.predictPanel.minMargin;
                    }
                }
                fontfamily: root.buttonStyle.fontFamily
                onReleased: {
                    root.predictionSlected();
                    Suggestion.onSelected(index);
                }

                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            root.setFocusIn(predictionRepeater.itemAt(index));
                            break;
                        default:
                            break;
                    }
                }
                KeyNavigation.right: predictionRepeater.itemAt(index + 1)
                KeyNavigation.left: predictionRepeater.itemAt(index - 1)
                Keys.onPressed: {
                    if (event.key === Qt.Key_Right && index === predictionRepeater.count - 1) {
                        if (rightBtn.state !== "Disable") {
                            rightBtn.focus = true;
                            event.accepted = true;
                        }
                    } else
                    if (event.key === Qt.Key_Left && index === 0) {
                        if (leftBtn.state !== "Disable") {
                            leftBtn.focus = true;
                            event.accepted = true;
                        }
                    }
                }
            }
            onItemRemoved: item.removed = true
        }

        ButtonBase {
            id: rightBtn
            objectName: "rightBtn"
            buttonStyle: style.navButton
            width:  style.predictPanel.navButton.width
            height: root.buttonHeight
            text: ">"
            noBorder:true
            state: "Disable"
            onReleased: {
                Suggestion.onNext();
                if (!Suggestion.next) {
                    root.predictionSlected();
                }
            }
            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(rightBtn);
                        break;
                    case "Disable":
                        root.focusOut();
                    break;
                    default:
                        break;
                }
            }

            KeyNavigation.left: predictionRepeater.itemAt(predictionRepeater.count-1)
            Keys.onPressed: {
                if (event.key === Qt.Key_Right && components.length > 0) {
                    componentRepeater.itemAt(0).focus = true;
                    event.accepted = true;
                }
            }
        }

        Repeater {
            id: componentRepeater
            objectName: "componentRepeater"
            model: components
            ButtonBase {
                buttonStyle: root.buttonStyle
                borderPosition: 1
                text: modelData
                disableShadow: true
                height: root.buttonHeight
                width: {
                    if (constantPrediction) {
                        return root.buttonWidth;
                    } else {
                        return (contentWidth + style.predictPanel.minMargin) < style.predictPanel.constWidth?
                               style.predictPanel.constWidth: contentWidth + style.predictPanel.minMargin;
                    }
                }
                fontfamily: root.buttonStyle.fontFamily
                onReleased: {
                    root.predictionSlected();
                    StrokeComponent.onSelected(index);
                }
                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            root.setFocusIn(componentRepeater.itemAt(index));
                            break;
                        default:
                            break;
                    }
                }
                KeyNavigation.right: componentRepeater.itemAt(index + 1)
                KeyNavigation.left: componentRepeater.itemAt(index - 1)
                Keys.onPressed: {
                    if (event.key === Qt.Key_Left && index === 0) {
                        if (rightBtn.state !== "Disable") {
                            rightBtn.focus = true;
                            event.accepted = true;
                        } else
                        if (predictionRepeater.itemAt(predictionRepeater.count - 1).state !== "Disable") {
                            predictionRepeater.itemAt(predictionRepeater.count - 1).focus = true;
                            event.accepted = true;
                        }
                    }
                }
            }
            onItemRemoved: item.removed = true
        }
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Down) {
            meetBottomBoundary();
            event.accepted = true;
        }
    }
}
