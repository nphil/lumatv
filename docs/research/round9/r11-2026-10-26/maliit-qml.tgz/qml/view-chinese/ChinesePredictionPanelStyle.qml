/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "../keyboard-common/style"

PredictionPanelStyle {
    id: root

    property int constWidth: 178 / resolution
    property int minMargin:   42 / resolution
    property int topMargin:   26 / resolution
    property int leftMargin:  26 / resolution
    property int cellWidth:  228 / resolution
    property int cellHeight:  70 / resolution
    property int fontSize:    38 / resolution

    property string defaultFontFamily: "LG Smart UI"

    property var navButton: QtObject {
        property int width: 74 / resolution
    }

    property var panelButton: PredictionItemStyle {resolution: root.resolution}
}

