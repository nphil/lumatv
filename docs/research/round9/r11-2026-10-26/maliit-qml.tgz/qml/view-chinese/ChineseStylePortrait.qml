/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "../keyboard-common/style-portrait"

Style {
    id: root

    predictPanel : ChinesePredictionPanelStyle {resolution: root.resolution}

    property var navButton : NavButtonStyle {resolution: root.resolution}

    property var suggestion : QtObject {
        property int cellWidth: 174 / resolution
        property int arrowWidth: 120 / resolution
    }

    property var component : QtObject {
        property int cellWidth: 136 / resolution
    }

    property var hid: QtObject{
        property int hidTopMargin:   66 / resolution
        property int hidPredHight:  264 / resolution

        property var hidPreButton: QtObject {
            property int leftMargin: 114 / resolution
            property int width:      114 / resolution
            property int height:     132 / resolution
        }

        property var hidPredRow: QtObject {
            property int leftMargin: 24 / resolution
            property int cellSpace:  24 / resolution
            property int width:    1412 / resolution
            property int height:    132 / resolution
        }

        property var hidPredItem: QtObject {
            property string fontFamily: defaultFontFamily
            property int height:    132 / resolution
            property int radius:     12 / resolution
            property var normal: QtObject {
                property color bgColor: "#42484E"
                property color fgColor: "#E6E6E6"
                property color borderColor: "#545A64"
                property int borderWidth: 4 / resolution
                property int fontSize:   78 / resolution
            }
            property var disable: QtObject {
                property color bgColor: "transparent"
                property color fgColor: "grey"
                property color borderColor: "#545A64"
                property int borderWidth: 4 / resolution
                property int fontSize:   38 / resolution
            }
            property var hotKey: QtObject {
                property int rightMargin: 12 / resolution
                property int height:      42 / resolution
                property int fontSize:    36 / resolution
                property color fgColor: "#ABAEB3"
            }
            property var word: QtObject {
                property int height:      78 / resolution
            }
        }

        property var hidNextButton: QtObject {
            property int leftMargin:  24 / resolution
            property int width:      114 / resolution
            property int height:     132 / resolution
        }

        property var hidModeButton: QtObject {
            property int rightMargin: 114 / resolution
            property int width:       220 / resolution
            property int height:      132 / resolution
        }
    }
}
