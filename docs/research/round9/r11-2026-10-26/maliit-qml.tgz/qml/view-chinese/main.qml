/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import QtQuick.Window 2.2
import PmLog 1.0

import com.meego.maliit 1.0
import WebOSServices 1.0

import "../keyboard-common"
import "../keyboard-common/style"
import "../keyboard-common/commonvariables.js" as CommonVariables
import "languages.js" as Languages

Rectangle {
    id: root
    objectName: "mainCnPlugin"
    enabled: false
    y: Screen.height + 1000

    // Keyboard App Id for Luna Service
    property string appId: "com.webos.service.ime.globalplugin"

    property real resolution : {
        if ((Screen.width >= 3840 && Screen.height >= 2160) || (Screen.height >= 3840 && Screen.width >= 2160)) return style.resolution_4k;
	if ((Screen.width >= 2560 && Screen.height >= 1440) || (Screen.height >= 2560 && Screen.width >= 1440)) return style.resolution_QHD;
        if ((Screen.width >= 1920 && Screen.height >= 1080) || (Screen.height >= 1920 && Screen.width >= 1080)) return style.resolution_2k;
        return style.resolution_HD;
    }

    property string orientation: "landscape"
    property bool isPortrait : { return orientation.includes("portrait"); }

    property QtObject style_landscape: ChineseStyle {id: commonStyle; resolution: root.resolution}
    property QtObject style_portrait: ChineseStylePortrait {id: commonStylePortrait; resolution: root.resolution}
    property QtObject style: isPortrait ? style_portrait : style_landscape
    property bool supportVoiceRecognition: false
    property bool pointerVisible: false
    property bool setFocusFirstAfterEnabled: false
    property int contentType: Keyboard.contentType
    property bool hiddenText: Keyboard.hiddenText
    property int inputSource: Keyboard.inputSource
    property int enterKeyType: Keyboard.enterKeyType
    property int windowWidth: style.keyboardDefaultWidth
    property int windowHeight: style.keyboardDefaultHeight
    property string foregroundAppId: ''
    property alias pmLog: pmLog
    property bool restrictedWindowType: false

    signal keyPressed(string rawcode, bool shift, int eventType)
    signal textKeyPressed(string text)
    signal switchContext()
    signal activateSTT()
    signal clearAllPressed()
    signal showRequested(bool reset)
    signal hideRequested(bool reset)
    signal shiftPressed(string state)
    signal symbolPressed(string state)
    signal meetTopBoundary()
    signal meetBottomBoundary()
    signal moveCursorPosition(int direction, int eventType)
    color: 'transparent'

    onSetFocusFirstAfterEnabledChanged: {
        console.warn("onSetFocusAfterEnabledChanged : " + setFocusFirstAfterEnabled);
        if (setFocusFirstAfterEnabled){
            setDefaultFocusOnVirtualKeybaord();
            setFocusFirstAfterEnabled = false;
        }
    }

    onStateChanged: {
        setNumberOfSuggestions();
    }

    onOrientationChanged: {
        if (root.orientation.includes("portrait"))
        {
            root.style = root.style_portrait;
        }
        else
        {
            root.style = root.style_landscape;
            normalKeyboard.removeMovableArea();
        }

        triggerOrientationChanged();
    }

    Component.onCompleted: {
        orientationService.getOrientationInfo();
    }

    function setFocusToEnter() {
        if (state === "Normal-Keyboard")
            normalKeyboard.setFocusToEnter();
        else if (state === "Number-Keyboard")
            numberKeyboard.setFocusToEnter();
    }

    function setFocusToHID() {
        hidWidget.setFocusToHID();
    }

    PmLog {
        id: pmLog
        context: root.appId

        function printNormalLog(messageId, value) {
            pmLog.info(messageId, value);
        }
    }

    // Normal Keyboard
    NormalKeyboard {
        id: normalKeyboard
        objectName: "normalKeyboard"
        enterKeyType: root.enterKeyType
        width: style.keyboardDefaultWidth
        height: style.keyboardDefaultHeight
        anchors.horizontalCenter: parent.horizontalCenter
        enabled: false
        y: windowHeight
        enableVoiceButton: root.restrictedWindowType ? false :((hiddenText || !supportVoiceRecognition) ? false : true)

        // slots
        onKeyPressed: root.keyPressed(rawcode, shift, eventType)
        onTextKeyPressed: root.textKeyPressed(text)
        onSwitchContext: root.switchContext()
        onActivateSTT: root.activateSTT()
        onClearAllPressed: root.clearAllPressed()
        onShiftPressed: root.shiftPressed(state)
        onSymbolPressed: root.symbolPressed(state)
        onNoWordsChanged: {
            updateHeight();
            if (root.orientation.includes("portrait"))
                setMovableArea()
        }
        onMeetTopBoundary: hideRequested(true)
        onMeetBottomBoundary: hideRequested(true)
    }

    // Number Keyboard
    NumberKeyboard {
        id: numberKeyboard
        objectName: "numberKeyboard"
        width: style.numberKeyboard.width
        height: style.numberKeyboard.height
        anchors.left: parent.left
        enabled: false
        y: windowHeight

        // slots
        onSendKey: root.keyPressed(keycode, shift, eventType)
        onSendText: root.textKeyPressed(text)

        onTtsService: ttsService.speakButton(text)
        onMeetTopBoundary: hideRequested(true)
        onMeetBottomBoundary: hideRequested(true)
    }

    // HID Prediction
    HidPredictionWidget {
        id: hidWidget
        objectName: "hidWidget"
        width: style.hidPredWidth
        height: style.hidPredHight
        anchors.left: parent.left
        enabled: false
        y: windowHeight
        Keys.onPressed: onSendKey(event.key)
    }

    /* Service : Voice Recognition */
    Service {
        id: voiceService
        appId: root.appId
        service: "com.webos.service.config"
        method: "getConfigs"
        onResponse: {
            var jsonObject
            if (method.toString() && method.toString() === "getConfigs") {
                jsonObject = JSON.parse(payload);
                console.warn("= = = = = = = = = = = = voice config 3: " + jsonObject.configs["system.supportVoiceRecognition"])
                if (jsonObject && typeof jsonObject.configs !== 'undefined') {
                    root.supportVoiceRecognition = jsonObject.configs["system.supportVoiceRecognition"]
                } else {
                    root.supportVoiceRecognition = false
                }
            }
        }
        function getVoiceRecognition() {
            callService({"subscribe" : true, "configNames" : ["system.supportVoiceRecognition"]})
        }
    }

    Service {
        id: surfaceManagerService
        appId: root.appId
        service: "com.webos.surfacemanager"
        method: "getForegroundAppInfo"
        onResponse: {
            var jsonObject = JSON.parse(payload);
            if (jsonObject.foregroundAppInfo.length > 0) {
                var foregroundAppInfo =  jsonObject.foregroundAppInfo.slice(-1)[0];
                root.foregroundAppId = foregroundAppInfo.appId;
                root.restrictedWindowType= (foregroundAppInfo.windowType === "_WEBOS_WINDOW_TYPE_RESTRICTED") ? true : false;
            }
            console.warn("@@@@ root.foregroundAppId", root.foregroundAppId);
        }
        function getForegroundAppInfo() {
            callService({"subscribe": true});
        }
    }

    /* Service: Get orientation */
    Service {
        id: orientationService
        appId: root.appId
        service: "com.webos.service.msc"
        method: "getOrientationInfo"
        onResponse: {
            var jsonObject = JSON.parse(payload);
            root.orientation = jsonObject && jsonObject.orientation;
        }
        function getOrientationInfo() {
            callService({"subscribe": true});
        }
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Cancel || event.key === Qt.Key_Up) {
            hideRequested(true);
            event.accepted = true;
        }
    }

    onMeetTopBoundary: hideRequested(true);
    onMeetBottomBoundary: hideRequested(true);

    states: [
        State {
            name: "Active"
            PropertyChanges {
                target: root
                enabled: true
                y: 0
            }
            StateChangeScript {
                script: showRequested(false)
            }
        },
        State {
            name: "Normal-Keyboard"; extend: "Active"
            when: inputSource === 1 && (contentType !== Maliit.NumberContentType && contentType !== Maliit.PhoneNumberContentType)
            PropertyChanges {
                target: normalKeyboard
                enabled: true
                y: 0
                focus: true
            }
            PropertyChanges {
                target: numberKeyboard
                enabled: false
                visible: false
            }
            PropertyChanges {
                target: hidWidget
                enabled: false
                visible: false
            }
            StateChangeScript {
                script: {
                    Keyboard.setPanelSize(normalKeyboard.width, normalKeyboard.height);
                    if (orientation.includes("portrait")) normalKeyboard.setMovableArea();
                }
            }
        },
        State {
            name: "Hid-Suggestion"; extend: "Active"
            when: inputSource === 0 && Suggestion.list.length > 0
            PropertyChanges {
                target: hidWidget
                enabled: true
                y: 0
                focus: true
            }
            StateChangeScript {
                script: {
                    Keyboard.setPanelSize(hidWidget.width, hidWidget.height);
                    if (orientation.includes("portrait")) {
                        numberKeyboard.setMovableArea();
                        hidWidget.maxCnt = 5;
                        hidWidget.maxLengthChar = 30;
                        // Suggestion.noSuggestions = 5;
                    }
                    else {
                        hidWidget.maxCnt = 8;
                        hidWidget.maxLengthChar = 50;
                        // Suggestion.noSuggestions = 8;
                    }
                }
            }
        },
        State {
            name: "Number-Keyboard"; extend: "Active"
            when: inputSource === 1 && (contentType === Maliit.NumberContentType || contentType === Maliit.PhoneNumberContentType)
            PropertyChanges {
                target: numberKeyboard
                enabled: true
                y: 0
                focus: true
            }
            StateChangeScript {
                script: {
                    Keyboard.setPanelSize(numberKeyboard.width, numberKeyboard.height);
                    if (orientation.includes("portrait")) numberKeyboard.setMovableArea();
                }
            }
        },
        State {
            name: "Hide"
            when: inputSource === 0 && Suggestion.preedit.length === 0 && Suggestion.list.length === 0
            StateChangeScript {
                script: {
                    hideRequested(true)
                    normalKeyboard.removeMovableArea();
                }
            }
        }
    ]

    Connections {
        target: Keyboard

        onLanguageChanged: {
            voiceService.getVoiceRecognition();
            surfaceManagerService.getForegroundAppInfo();
            // set the default fonts
            if (language === Languages.SIMPLIFIED_CHINESE)
                style.setDefaultFont("zh-Hans");
            else
                style.setDefaultFont("zh-Hant");

            normalKeyboard.setLanguage(language, data, resetFocus);
            hidWidget.setLanguage(language);
        }

        onShiftLabelChanged: {
            setNumberOfSuggestions();
        }

        onVisibleChanged: {
            console.warn("IMEManager CN visible : " + visible);
            if (!visible) {
                if (state === "Normal-Keyboard")
                    normalKeyboard.setDefaultFocus();
                else if (state === "Number-Keyboard")
                    numberKeyboard.setDefaultFocus();
            } else {
                setFocusFirstAfterEnabled = Qt.binding(function(){
                    return state === "Normal-Keyboard" ? normalKeyboard.enabled : numberKeyboard.enabled;
                })
            }
        }

        onContentTypeChanged: {
            console.warn("onContentTypeChanged : ", contentType);
            setFocusFirstAfterEnabled = Qt.binding(function(){
                return state === "Normal-Keyboard" ? normalKeyboard.enabled : numberKeyboard.enabled;
            })
        }

        onCursorVisibleChanged: {
            root.pointerVisible = cursorVisible;
            setDefaultFocusOnVirtualKeybaord();
        }

       onForceFocusTo: {
           switch (label) {
           case "Enter":
               setFocusToEnter();
               break;
           case "HID":
               setFocusToHID();
               break;
           default:
               break;
           }
       }
    }

    function setDefaultFocusOnVirtualKeybaord() {
        if (root.pointerVisible) {
            if (CommonVariables.savedFocusItem)
                CommonVariables.savedFocusItem.focus = false;
        }
        else if (CommonVariables.savedFocusItem && CommonVariables.savedFocusItem.visible)
            CommonVariables.savedFocusItem.focus = true;
        else if (state == "Normal-Keyboard")
            normalKeyboard.setDefaultFocus();
        else if (state == "Number-Keyboard")
            numberKeyboard.setDefaultFocus();
    }

    function setNumberOfSuggestions()
    {
        if (root.orientation.includes("portrait") &&
            Keyboard.languageLabel === Languages.SIMPLIFIED_CHINESE &&
            Keyboard.shiftLabel === Languages.STROKE)
            Suggestion.noSuggestions = 3;
        else if (root.orientation.includes("portrait"))
            Suggestion.noSuggestions = 5;
        else
            Suggestion.noSuggestions = 8;
    }

    function triggerOrientationChanged()
    {
        if (state === "Normal-Keyboard")
        {
            normalKeyboard.orientationChanged(root.orientation);
        }
        else if (state === "Number-Keyboard")
        {
            numberKeyboard.orientationChanged(root.orientation);
        }
        else if (state === "Hid-Suggestion")
        {
            hidWidget.orientationChanged(root.orientation);
        }
        else
        {
            normalKeyboard.height = style.keyboardDefaultHeight;
            normalKeyboard.removeMovableArea();
        }
    }
}
