/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "../keyboard-common"
import "languages.js" as Languages
import "../keyboard-common/commonvariables.js" as CommonVariables

Item {
    id: root
    objectName: "leftFunctionArea"
    state: "Normal"

    property string currLanguage: Languages.SIMPLIFIED_CHINESE
    property string previousState
    signal languageButtonPressed()
    signal shiftClicked(string state)
    signal symbolClicked(string state)
    signal meetLeftBoundary(int row)
    signal meetRightBoundary(int row)
    signal meetTopBoundary(int column)
    signal meetBottomBoundary(int column)
    signal focusItem(var item, int x, int y)
    signal focusImage(url img)
    signal focusOut()

    function setFocusIn(item) {
        root.focusItem(item, item.x + style.left.leftMargin, item.y + style.left.topMargin);
    }

    function setKeyNavigation(row) {
        if (row === 0) languageChangeButton.focus = true;
        else if (row === 1) symbolButton.focus = true;
        else if (row === 2) shiftButton.focus = true;
        else shiftButton.focus = true;
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Up) {
            meetTopBoundary(0);
            event.accepted = true;
        } else if (event.key === Qt.Key_Down) {
            meetBottomBoundary(0);
            event.accepted = true;
        } else if (event.key === Qt.Key_Left) {
            meetLeftBoundary(CommonVariables.savedFocusItem.row);
            event.accepted = true;
        } else if (event.key === Qt.Key_Right) {
            meetRightBoundary(CommonVariables.savedFocusItem.row);
            event.accepted = true;
        }
    }

    Column {
        id: chineseLeftColumn
        objectName: "chineseLeftColumn"
        spacing: style.left.cellSpace

        /* Language Button */
        ButtonBase {
            id: languageChangeButton
            objectName: "languageChangeButton"
            property int row: 0
            text: Keyboard.languageLabel
            buttonStyle: style.panelButton

            onReleased: {
                languageButtonPressed();
            }

            width: root.width
            height: style.left.cellHeight

            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(languageChangeButton);
                        break;
                    default:
                        break;
                }
            }
            onExited: root.focusOut()
            KeyNavigation.down: symbolButton
        }

        /* Symbol Button */
        ButtonBase {
            id: symbolButton
            objectName: "symbolButton"
            buttonStyle: style.panelButton
            property int row: 1
            text: (root.state === "Symbol") ? (currLanguage !== Languages.SIMPLIFIED_CHINESE) ? "漢" : "中" : "$%^"
            onReleased: {
                switch (root.state) {
                case "Normal":
                    previousState = "Normal";
                    root.state = "Symbol";
                    break;
                case "Normal-Shift":
                    previousState = "Normal-Shift";
                    root.state = "Symbol";
                    break;
                case "Symbol":
                    root.state = previousState;
                    break;
                default:
                    break;
                }
                symbolClicked(root.state);
            }
            width: root.width
            height: style.left.cellHeight

            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(symbolButton);
                        break;
                    default:
                        break;
                }
            }
            onExited: root.focusOut()
            KeyNavigation.up: languageChangeButton
            KeyNavigation.down: shiftButton
        }

        /* Shift Button */
        ButtonBase {
            id: shiftButton
            objectName: "shiftButton"
            buttonStyle: style.panelButton
            property int row: 2
            text: Keyboard.shiftLabel

            onReleased: {
                switch (root.state) {
                case "Normal":
                    root.state = "Normal-Shift";
                    break;
                case "Normal-Shift":
                    root.state = "Normal";
                    break;
                case "Symbol":
                    root.state = "Normal-Shift";
                    break;
                default:
                    break;
                }
                shiftClicked(root.state);
            }
            width: root.width
            height: style.left.cellHeight

            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(shiftButton);
                        break;
                    default:
                        break;
                }
            }
            onExited: root.focusOut()
            KeyNavigation.up: symbolButton
        }

        ButtonBase {
            id: spacingButton1
            visible: true
            state: "Disable"
            text: ""
            width: true ? root.width :0
            height: commonStyle.left.cellHeight
        }
    }

    states: [
        State {
            name: "Normal"
            when: !Keyboard.shifted
            StateChangeScript {
                script: CommonVariables.savedFocusItem = shiftButton
            }
        },
        State {
            name: "Normal-Shift"
            when: Keyboard.shifted
            StateChangeScript {
                script: CommonVariables.savedFocusItem = shiftButton
            }
        },
        State {
            name: "Symbol"
        }
    ]

    function setToDefault() {
        shiftButton.state = "Normal";
    }

    Connections {
        target: PluginProxy
        onKeyReleased : {
            if (isReleased && (languageChangeButton.state === "Select"))
                languageChangeButton.state = "Focus";
            else if (isReleased && (symbolButton.state === "Select"))
                symbolButton.state = "Focus";
            else if (isReleased && (shiftButton.state === "Select"))
                shiftButton.state = "Focus";
        }
    }
}
