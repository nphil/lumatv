/* @@@LICENSE
*
*      Copyright (c) 2013-2014 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

import "../keyboard-common"

ButtonBase {
    id: letterButton
    objectName: "letterButton"
    property string mode: "Hiragana"
    property string hiraganaChar    /* display character */
    property string katakanaChar
    property string fullWidthEnglishLowercaseChar
    property string fullWidthEnglishUppercaseChar
    property string symbolChar
    property string hiraganaRawcode        /* code sening to engine */
    property string katakanaRawcode
    property string fullWidthEnglishLowercaseRawcode
    property string fullWidthEnglishUppercaseRawcode
    property string symbolRawcode
    signal sendKey(string rawcode, bool shift, int eventType)

    text: getCurrentText()
    state: (text.length > 0) ? "Normal" : "Disable"

    onReleased: {
        switch (mode) {
        case "Hiragana":
            sendKey(hiraganaRawcode, false, eventType);
            break;
        case "Katakana":
            sendKey(katakanaRawcode, false, eventType);
            break;
        case "FullWidth-English":
            sendKey(fullWidthEnglishLowercaseRawcode, false, eventType);
            break;
        case "FullWidth-English-Shift":
        case "FullWidth-English-Shift-Lock":
            sendKey(fullWidthEnglishUppercaseRawcode, false, eventType);
            break;
        case "Symbol":
            sendKey(symbolRawcode, false, eventType);
        }
    }

    function getCurrentText() {
        var t;

        switch (mode) {
        case "Hiragana":
            t = hiraganaChar;
            break;
        case "Katakana":
            t = katakanaChar;
            break;
        case "FullWidth-English":
            t = fullWidthEnglishLowercaseChar;
            break;
        case "FullWidth-English-Shift":
        case "FullWidth-English-Shift-Lock":
            t = fullWidthEnglishUppercaseChar;
            break;
        case "Symbol":
            t = symbolChar;
            break;
        default:
            t = "";
        }

        return (t !== undefined) ? t : "";
    }
}
