/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import QtQuick.Window 2.2
import PmLog 1.0

import com.meego.maliit 1.0
import WebOSServices 1.0

import "../keyboard-common/commonvariables.js" as CommonVariables
import "../keyboard-common"

Rectangle {
    id: root
    objectName: "mainJpPlugin"
    enabled: false

    // Keyboard App Id for Luna Service
    property string appId: "com.webos.service.ime.globalplugin"

    property int resolution : {
        if ((Screen.width >= 3840 && Screen.height >= 2160) || (Screen.height >= 3840 && Screen.width >= 2160)) return style.resolution_4k;
        if ((Screen.width >= 1920 && Screen.height >= 1080) || (Screen.height >= 1920 && Screen.width >= 1080)) return style.resolution_2k;
        return style.resolution_HD;
    }

    property string orientation: "landscape"
    property bool isPortrait : { return orientation.includes("portrait"); }

    property QtObject style_landscape: JapaneseStyle {id: commonStyle; resolution: root.resolution}
    property QtObject style_portrait: JapaneseStylePortrait {id: commonStylePortrait; resolution: root.resolution}
    property QtObject style: isPortrait ? style_portrait : style_landscape

    property int contentType: PluginProxy.contentType
    property int inputSource: PluginProxy.inputSource
    property int hidMode: PluginProxy.hidMode
    property int windowHeight:style.keyboardDefaultHeight
    property bool hiddenText: PluginProxy.hiddenText
    property int enterKeyType: PluginProxy.enterKeyType
    property int windowWidth: style.keyboardDefaultWidth
    property bool supportVoiceRecognition: false
    property bool pointerVisible: false
    property bool setFocusFirstAfterEnabled: false
    property int shadowHeight: 3
    property string foregroundAppId: ''
    property alias pmLog: pmLog
    property bool restrictedWindowType:false

    color: 'transparent'

    signal keyPressed(string rawcode, bool shift, int eventType)
    signal textKeyPressed(string text)
    signal switchContext()
    signal clearAllPressed()
    signal activateSTT()
    signal clickInputCharacterChangeButton(string mode)
    signal setHidModeFromVkb(int mode)
    signal showRequested(bool reset)
    signal hideRequested(bool reset)
    signal switchSymbolMode(bool isSymbol)
    signal meetTopBoundary()
    signal moveCursorPosition(int direction, int eventType)

    onSetFocusFirstAfterEnabledChanged: {
        console.warn("onSetFocusAfterEnabledChanged : " + setFocusFirstAfterEnabled);
        if (setFocusFirstAfterEnabled){
            setDefaultFocusOnVirtualKeybaord();
            setFocusFirstAfterEnabled = false;
        }
    }

    onOrientationChanged: {
        if (root.orientation.includes("portrait"))
        {
            root.style = root.style_portrait;
            normalKeyboard.noPredictionItems = 5;
        }
        else
        {
            root.style = root.style_landscape;
            normalKeyboard.removeMovableArea();
            normalKeyboard.noPredictionItems = 10;
        }

        triggerOrientationChanged();
    }

    Component.onCompleted: {
        orientationService.getOrientationInfo();
    }

    function setFocusToEnter() {
        if (state === "Normal-Keyboard")
            normalKeyboard.setFocusToEnter();
        else if (state === "Number-Keyboard")
            numberKeyboard.setFocusToEnter();
    }

    function setFocusToHID() {
        hidWidget.setFocusToHID();
    }

    function inputModeReset() {
        if (state === "Normal-Keyboard") {
            normalKeyboard.setToDefault();
        } else if (state === "Number-Keyboard") {
            numberKeyboard.setToDefault();
        }
        root.switchSymbolMode(false);
    }

    PmLog {
        id: pmLog
        context: root.appId

        function printNormalLog(messageId, value) {
            pmLog.info(messageId, value);
        }

    }

    // Normal Keyboard
    NormalKeyboard {
        id: normalKeyboard
        objectName: "normalKeyboard"
        enterKeyType: root.enterKeyType
        width:  style.keyboardDefaultWidth
        height: style.keyboardDefaultHeight
        enabled: false
        y: windowHeight
        enableVoiceButton: root.restrictedWindowType ? false :((hiddenText || !supportVoiceRecognition) ? false : true)
        // slots
        onKeyPressed: root.keyPressed(rawcode, shift, eventType)
        onChangeLanguage: root.switchContext()
        onActivateSTT: root.activateSTT()
        onClearAllPressed: root.clearAllPressed()
        onClickInputCharacterChangeButton: {
            root.clickInputCharacterChangeButton(mode);
            switch (mode) {
                case "Hiragana":
                case "Katakana":
                    PluginProxy.setPanelSize(style.keyboardDefaultWidth,style.keyboardDefaultHeight);
                    style.japaneseLeft.leftMargin = style.japaneseLeft.defaultLeftMargin;
                    break;
                case "FullWidth-English":
                case "FullWidth-English-Shift":
                case "FullWidth-English-Shift-Lock":
                    PluginProxy.setPanelSize(style.romanjiKeyboardWidth,style.spaceBarKeyboardHeight);
                    height = style.spaceBarKeyboardHeight;
                    style.japaneseLeft.leftMargin = style.japaneseLeft.romanjiLeftMargin;
                    break;
                case "Symbol":
                    PluginProxy.setPanelSize(style.symbolKeyboardWidth,style.spaceBarKeyboardHeight);
                    height = style.spaceBarKeyboardHeight;
                    style.japaneseLeft.leftMargin = style.japaneseLeft.symbolLeftMargin;
                    break;
            }
        }
        onPredictVisibleChanged: {
            updateHeight();
            if (root.orientation.includes("portrait"))
                setMovableArea()
        }
        onChangeToSymbolMode: {
            root.switchSymbolMode(true);
            if (root.orientation.includes("portrait"))
                setMovableArea()
        }
        onChangeToHiraganaMode: {
            root.switchSymbolMode(false);
            if (root.orientation.includes("portrait"))
                setMovableArea()
        }
        onMeetTopBoundary: hideRequested(true)
        onMeetBottomBoundary: hideRequested(true)
    }

     // Number Keyboard
    NumberKeyboard {
        id: numberKeyboard
        objectName: "numberKeyboard"
        width: style.numberKeyboard.width
        height: style.numberKeyboard.height
        anchors.horizontalCenter: parent.horizontalCenter
        enabled: false
        y: windowHeight

        // slots
        onSendKey: root.keyPressed(keycode, shift, eventType)
        onSendText: root.textKeyPressed(text)

        onTtsService: ttsService.speakButton(text)
        onMeetTopBoundary: hideRequested(true)
        onMeetBottomBoundary: hideRequested(true)
    }

    // HID Prediction
    HidPredictionWidget {
        id: hidWidget
        objectName: "hidWidget"
        width: style.hidPredWidth
        height: style.hidPredHight
        anchors.horizontalCenter: parent.horizontalCenter
        enabled: false
        y: windowHeight
        onSetHidModeFromVkb: root.setHidModeFromVkb(mode)
        Keys.onPressed: onSendKey(event.key)
    }

    /* Service : Voice Recognition */
    Service {
        id: voiceService
        appId: root.appId
        service: "com.webos.service.config"
        method: "getConfigs"
        onResponse: {
            var jsonObject
            if (method.toString() && method.toString() === "getConfigs") {
                jsonObject = JSON.parse(payload);
                console.warn("= = = = = = = = = = = = voice config 2: " + jsonObject.configs["system.supportVoiceRecognition"])
                if (jsonObject && typeof jsonObject.configs !== 'undefined') {
                    root.supportVoiceRecognition = jsonObject.configs["system.supportVoiceRecognition"]
                } else {
                    root.supportVoiceRecognition = false
                }
            }
        }
        function getVoiceRecognition() {
            callService({"subscribe" : true, "configNames" : ["system.supportVoiceRecognition"]})
        }
    }

      /* Service : Get currentForegroundApplication */
    Service {
        id: surfaceManagerService
        appId: root.appId
        service: "com.webos.surfacemanager"
        method: "getForegroundAppInfo"
        onResponse: {
            var jsonObject = JSON.parse(payload);
            if (jsonObject.foregroundAppInfo.length > 0) {
                var foregroundAppInfo =  jsonObject.foregroundAppInfo.slice(-1)[0];
                root.foregroundAppId = foregroundAppInfo.appId;
                root.restrictedWindowType= (foregroundAppInfo.windowType === "_WEBOS_WINDOW_TYPE_RESTRICTED") ? true : false;
            }
            console.warn("@@@@ root.foregroundAppId", root.foregroundAppId);
        }
        function getForegroundAppInfo() {
            callService({"subscribe": true});
        }
    }

    /* Service: Get orientation */

    Service {
        id: orientationService
        appId: root.appId
        service: "com.webos.service.msc"
        method: "getOrientationInfo"
        onResponse: {
            var jsonObject = JSON.parse(payload);
            root.orientation = jsonObject && jsonObject.orientation;
        }
        function getOrientationInfo() {
            callService({"subscribe": true});
        }
    }

    Keys.onPressed: {
//#IF_COMMERCIAL
        if (event.key === Qt.Key_Cancel || event.key === Qt.Key_Up) {
//#ELSE
/*
        if (event.key === Qt.Key_Cancel) {
*/
//#END
            hideRequested(true);
            event.accepted = true;
        }
    }

    states: [
        State {
            name: "Active"
            PropertyChanges {
                target: root
                enabled: true
                y: 0
            }
            StateChangeScript {
                script:showRequested(false)
            }
        },
        State {
            name: "Normal-Keyboard"; extend: "Active"
            when: inputSource === 1 && (contentType !== Maliit.NumberContentType && contentType !== Maliit.PhoneNumberContentType)
            PropertyChanges {
                target: normalKeyboard
                enabled: true
                y: 0
                focus: true
            }
            PropertyChanges {
                target: numberKeyboard
                enabled: false
                visible: false
            }
            PropertyChanges {
                target: hidWidget
                enabled: false
                visible: false
            }

            StateChangeScript {
                script: {
                    PluginProxy.setPanelSize(normalKeyboard.width, normalKeyboard.height)
                    if (orientation.includes("portrait")) normalKeyboard.setMovableArea();
                }
            }
        },
        State {
            name: "Number-Keyboard"; extend: "Active"
            when: inputSource === 1 && (contentType === Maliit.NumberContentType || contentType === Maliit.PhoneNumberContentType)
            PropertyChanges {
                target: numberKeyboard
                enabled: true
                y: 0
                focus: true
            }
            StateChangeScript {
                script: {
                    PluginProxy.setPanelSize(numberKeyboard.width, numberKeyboard.height);
                    if (orientation.includes("portrait")) numberKeyboard.setMovableArea();
                }
            }
        },
        State {
            name: "Hid-Prediction"; extend: "Active"
            when: inputSource === 0 && Prediction.list.length > 0
            PropertyChanges {
                target: hidWidget
                enabled: true
                y: 0
                focus: true
            }
            StateChangeScript {
                script: {
                    PluginProxy.setPanelSize(hidWidget.width, hidWidget.height);
                    if (orientation.includes("portrait")) hidWidget.setMovableArea();
                }
            }
        },
        State {
            name: "Hide"
            when: inputSource === 0 && Prediction.list.length === 0
            StateChangeScript {
                script: {
                    hideRequested(false);
                    normalKeyboard.removeMovableArea();
                }
            }
        }
    ]

    Connections {
        target: PluginProxy
        onVisibleChanged: {
            console.warn("IMEManager JP visible : " + visible);
            if (!visible) {
                root.switchSymbolMode(false);
                // reset height Normal-Keyboard only - WOSLQEVENT-44774
                if (state == "Normal-Keyboard")
                    normalKeyboard.setToDefault();
                else if (state === "Number-Keyboard")
                    numberKeyboard.setDefaultFocus();
            } else {
                setFocusFirstAfterEnabled = Qt.binding(function(){
                    return state === "Normal-Keyboard" ? normalKeyboard.enabled : numberKeyboard.enabled;
                })
            }
        }
        onLanguageChanged: {
            voiceService.getVoiceRecognition();
            surfaceManagerService.getForegroundAppInfo();
            commonStyle.setDefaultFont("ja");
            root.inputModeReset();
            normalKeyboard.setDefaultFocus();
        }
        onHidModeChanged: hidWidget.setHidModeFromHid(hidMode)
        onUnfixedStatusChanged: normalKeyboard.setEnterKeyText(unfixedStatus)
        onCursorVisibleChanged: {
            console.warn("IMEManager cursor visible : " + cursorVisible);
            root.pointerVisible = cursorVisible;
            setDefaultFocusOnVirtualKeybaord();
        }
        onContentTypeChanged: {
            if (contentType === Maliit.NumberContentType || contentType === Maliit.PhoneNumberContentType) {
                hidWidget.setHidModeforNumberContent();
            }
        }
        onForceFocusTo: {
            switch (label) {
            case "Enter":
                setFocusToEnter();
                break;
            case "HID":
                setFocusToHID();
                break;
            default:
                break;
            }
        }
    }

    function setDefaultFocusOnVirtualKeybaord() {
        if (root.pointerVisible && CommonVariables.savedFocusItem)
            CommonVariables.savedFocusItem.focus = false;
        else if (CommonVariables.savedFocusItem && CommonVariables.savedFocusItem.visible)
            CommonVariables.savedFocusItem.focus = true;
        else if (state == "Normal-Keyboard")
            normalKeyboard.setDefaultFocus();
        else if (state == "Number-Keyboard")
            numberKeyboard.setDefaultFocus();
    }

    function triggerOrientationChanged()
    {
        if (state === "Normal-Keyboard")
        {
            normalKeyboard.orientationChanged(root.orientation);
        }
        else if (state === "Number-Keyboard")
        {
            numberKeyboard.orientationChanged(root.orientation);
        }
        else if (state === "Hid-Prediction")
        {
            hidWidget.orientationChanged(root.orientation);
        }
        else
        {
            normalKeyboard.height = style.keyboardDefaultHeight;
            normalKeyboard.removeMovableArea();
        }
    }
}
