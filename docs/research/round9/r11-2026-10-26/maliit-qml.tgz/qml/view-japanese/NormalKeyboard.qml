/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import com.meego.maliit 1.0

import "../keyboard-common"
import "variables.js" as Variables
import "../keyboard-common/commonvariables.js" as CommonVariables

Rectangle {
    id: root
    objectName:"normalKeyboard"

    color: style.bgColor
    opacity: style.opacity
    radius: style.radius

    property alias mode: leftFunctionAreaJapanese.state
    property alias currLanguage: leftFunctionAreaJapanese.currLanguage
    property alias supportShiftMode: leftFunctionAreaJapanese.supportShiftMode
    property alias predictionNum: middleLayoutArea.predictionNum
    property alias predictionHead: middleLayoutArea.predictionHead
    property alias predictionMode: middleLayoutArea.predictionMode
    property alias currIndex: middleLayoutArea.currIndex
    property alias noWords: predictionArea.noWords
    property alias predictVisible: predictionArea.visible
    property int contentType: 0
    property int enterKeyType: 0
    property alias enableVoiceButton: rightFunctionArea.enableVoiceButton
    property real predictionPage: 0
    property bool showScreenKeyboard: true
    property alias showMore: leftFunctionAreaJapanese.showMoreButton
    property int lastCloumn: 0
    property int lastFocusedArea: Variables.MiddleArea
    property int noPredictionItems: 10
    signal ttsService(string text)

    signal keyPressed(string rawcode, bool shift, int eventType)
    signal changeLanguage()
    signal clearAllPressed()
    signal activateSTT()
    signal reset()
    signal clickInputCharacterChangeButton(string mode)
    signal changeToSymbolMode()
    signal changeToHiraganaMode()
    signal meetTopBoundary()
    signal meetBottomBoundary()
    signal orientationChanged(string orientation)

    onEnabledChanged: {
        setDefaultFocusOnVirtualKeybaord();
    }

    onPredictVisibleChanged: {
        if (focusRect.focusAdjust) {
            focusRect.y += predictVisible ? 0 : -style.predictPanel.height;
            focusRect.focusAdjust = false;
        }
    }

    onOrientationChanged: {
        updateHeight();
        if (orientation.includes("portrait"))
        {
            noPredictionItems = 5;
            middleLayoutArea.modeChanged();
            setMovableArea();
        }
        else
        {
            noPredictionItems = 10
            middleLayoutArea.modeChanged()
            removeMovableArea();
        }

        middleLayoutArea.updateMiddleLayout();
        bottomArea.updateBottomLayout();
        rightFunctionArea.updateRightColumnLayout();
        predictionArea.updatePredictLayout();
        updateFocusItem();
    }

    function updateHeight() {
        var nHeight = predictVisible ? style.predictPanel.height : 0;
        switch (mode) {
            case "Hiragana":
            case "Katakana":
                nHeight += style.keyboardDefaultHeight
                style.japaneseLeft.leftMargin = style.japaneseLeft.defaultLeftMargin;
                break;
            case "FullWidth-English":
            case "FullWidth-English-Shift":
            case "FullWidth-English-Shift-Lock":
                nHeight += style.spaceBarKeyboardHeight;
                style.japaneseLeft.leftMargin = style.japaneseLeft.romanjiLeftMargin;
                break;
            case "Symbol":
                nHeight += style.spaceBarKeyboardHeight;
                style.japaneseLeft.leftMargin = style.japaneseLeft.symbolLeftMargin;
                break;
        }
        
        PluginProxy.setPanelSize(normalKeyboard.width, nHeight);
        height = nHeight;
    }

    function setMovableArea() {
        var marginTop = noWords ? 0 : style.predictPanel.height;
        var right_area_w = style.keyboardDefaultWidth - style.left.leftMargin - style.left.width - style.middle.leftMargin
                         - style.middle.width - style.right.leftMargin - style.right.width;
        var right_area_x = style.keyboardDefaultWidth - right_area_w;
        var bottom_area_y = normalKeyboard.height - style.bottom.bottomMargin;

        PluginProxy.setMovableArea(Maliit.MovableAreaLeft, 0, marginTop, style.left.leftMargin, style.keyboardDefaultHeight);
        PluginProxy.setMovableArea(Maliit.MovableAreaTop, 0, marginTop, style.keyboardDefaultWidth, style.middle.topMargin);
        PluginProxy.setMovableArea(Maliit.MovableAreaRight, right_area_x, marginTop, right_area_w, style.keyboardDefaultHeight);
        PluginProxy.setMovableArea(Maliit.MovableAreaBottom, 0, bottom_area_y, style.keyboardDefaultWidth, style.bottom.bottomMargin);
    }

    function removeMovableArea() {
        PluginProxy.setMovableArea(Maliit.MovableAreaLeft, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaTop, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaRight, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaBottom, 0, 0, 0, 0);
    }

    function updateFocusItem()
    {
        var item = focusRect.focusedItem;
        if (focusRect.visible && item)
        {
            var xOffset = 0;
            var yOffset = 0;

            if (focusRect.focusedArea === "bottomRow")
            {
                if (root.mode.includes("FullWidth-English"))
                    xOffset = style.japaneseLeft.romanjiLeftMargin + style.left.width + style.middle.leftMargin;
                else if (root.mode === "Symbol")
                    xOffset = style.japaneseLeft.symbolLeftMargin + style.left.width + style.middle.leftMargin;

                yOffset = style.left.topMargin + style.middle.height + style.bottom.topMargin;
            }
            else if (focusRect.focusedArea === "navButtons")
            {
                xOffset = style.left.leftMargin + style.left.width + style.middle.leftMargin + style.middle.width + style.right.leftMargin;
                yOffset = style.left.topMargin + style.middle.height + style.bottom.topMargin;
            }
            else if (focusRect.focusedArea === "japaneseLeftColumn")
            {
                if (root.mode === "Hiragana" || root.mode === "Katakana")
                    xOffset = style.japaneseLeft.defaultLeftMargin;
                else if (root.mode.includes("FullWidth-English"))
                    xOffset = style.japaneseLeft.romanjiLeftMargin;
                else if (root.mode === "Symbol")
                    xOffset = style.japaneseLeft.symbolLeftMargin;
                yOffset = style.left.topMargin;
            }
            else if (focusRect.focusedArea === "middleGrid" || focusRect.focusedArea === "predictionGrid")
            {
                if (root.mode === "Hiragana" || root.mode === "Katakana")
                    xOffset = style.japaneseLeft.defaultLeftMargin + style.left.width + style.middle.leftMargin;
                else if (root.mode.includes("FullWidth-English"))
                    xOffset = style.japaneseLeft.romanjiLeftMargin + style.left.width + style.middle.leftMargin;
                else if (root.mode === "Symbol")
                    xOffset = style.japaneseLeft.symbolLeftMargin + style.left.width + style.middle.leftMargin;

                yOffset = style.middle.topMargin;
            }
            else if (focusRect.focusedArea === "rightColumn" || focusRect.focusedArea === "navRow")
            {
                if (root.mode === "Hiragana" || root.mode === "Katakana")
                    xOffset = style.japaneseLeft.defaultLeftMargin + style.left.width + style.middle.leftMargin + style.japaneseMiddle.width + style.right.leftMargin;
                else if (root.mode.includes("FullWidth-English"))
                    xOffset = style.japaneseLeft.romanjiLeftMargin + style.left.width + style.middle.leftMargin + style.romanjiMiddle.width + style.right.leftMargin;
                else if (root.mode === "Symbol")
                    xOffset = style.japaneseLeft.symbolLeftMargin + style.left.width + style.middle.leftMargin + style.symbolMiddle.width + style.right.leftMargin;

                yOffset = style.middle.topMargin;
                if (focusRect.focusedArea === "navRow")
                    yOffset += rightFunctionArea.height - style.right.cellHeight;
            }
            else if(focusRect.focusedArea === "predictionBar")
            {
                if (!item.parent)
                {
                    setFocusOut();
                    return;
                }
                xOffset = predictionArea.xOffset;
                yOffset = -((style.predictPanel.height - style.predictPanel.panelButton.height) / 2 + style.predictPanel.panelButton.height);
            }
            else if(focusRect.focusedArea === "pageCount")
            {
                xOffset = predictionArea.xOffsetPageCount;
                yOffset = -((style.predictPanel.height - style.predictPanel.panelButton.height) / 2 + style.predictPanel.panelButton.height);
            }

            if (item.state === "Select") {
                var selectWidth  = (item.width  + focusRect.focusStyle.widthOffset)  * focusRect.focusStyle.selectRatio;
                var selectHeight = (item.height + focusRect.focusStyle.heightOffset) * focusRect.focusStyle.selectRatio;
                focusRect.width  = selectWidth  < item.width  ? item.width  : selectWidth;
                focusRect.height = selectHeight < item.height ? item.height : selectHeight;
            } else {
                focusRect.width  = item.width  + focusRect.focusStyle.widthOffset;
                focusRect.height = item.height + focusRect.focusStyle.heightOffset;
            }

            focusRect.x = xOffset + item.x - (focusRect.width - item.width)/2;
            focusRect.y = yOffset + item.y - (focusRect.height - item.height)/2 + (predictionArea.visible?predictionArea.height:0);
        }
    }

    function setFocusItem(item,x,y) {
        focusRect.image = "";
        focusRect.visible = true;
        focusRect.dotVisible = false;

        focusRect.focusedArea = item.parent.objectName;
        focusRect.focusedItem = item;

        // Space-bar "selection state" width will become lesser than its original width
        // if selection ratio directly applied.
        if (item.state === "Select") {
            var selectWidth  = focusRect.width  * focusRect.focusStyle.selectRatio;
            var selectHeight = focusRect.height * focusRect.focusStyle.selectRatio;
            focusRect.width  = selectWidth  < item.width  ? item.width  : selectWidth;
            focusRect.height = selectHeight < item.height ? item.height : selectHeight;
        } else {
            focusRect.width  = item.width  + focusRect.focusStyle.widthOffset;
            focusRect.height = item.height + focusRect.focusStyle.heightOffset;
        }

        focusRect.x = x - (focusRect.width - item.width)/2
        focusRect.y = y - (focusRect.height - item.height)/2 + (predictVisible?style.predictPanel.height:0);
        focusRect.focusTxt = item.text;
        focusRect.fontSize = item.fontSize;
        focusRect.focusAdjust = item.focusAdjust;
    }

    function setFocusOut() {
        focusRect.visible = false;
        focusRect.focusTxt = "";
        focusRect.image = "";
    }

    PredictionPanel {
        id: predictionArea
        objectName: "predictionArea"
        buttonStyle: style.predictPanel.panelButton
        visible: (!noWords) || predictionMode
        anchors.left: parent.left
        anchors.top: parent.top
        height: style.predictPanel.height
        width: root.width
        buttonWidth: style.predictPanel.panelButton.width
        buttonHeight: style.predictPanel.panelButton.height
        words: !predictionMode && root.mode === "Hiragana" ? selectPredictionWords() : undefined
        predictMode: predictionMode
        onSelectPrediction: {
            Prediction.onSelected(index);
            predictionMode = false;
            predictionNum = 0;
            predictionHead = 0;
            setDefaultFocus();
        }
        showNextButton: predictionNum < Prediction.list.length
        showPreviousButton: predictionNum > (Variables.FullScreenPredictionRows * Variables.FullScreenPredictionColumns)

        onPressNext: {
            root.drawPredictionLayout();
            middleLayoutArea.predictionHead += Variables.FullScreenPredictionRows * Variables.FullScreenPredictionColumns;
        }

        onPressPrev: {
            predictionNum -= Variables.FullScreenPredictionRows * Variables.FullScreenPredictionColumns * 2;
            root.drawPredictionLayout();
            middleLayoutArea.predictionHead -= Variables.FullScreenPredictionRows * Variables.FullScreenPredictionColumns;
        }

        onSendKey: root.keyPressed(keycode, shift, eventType)
        onTtsService: root.ttsService(text)

        onFocusItem: {
            focusRect.focusStyle = style.panelFocus;
            root.setFocusItem(item,x,y);
        }
        onFocusOut: root.setFocusOut()
        onMeetBottomBoundary: middleLayoutArea.setKeyNavigation(-1,"defaultIndex","Down")
        onMeetTopBoundary: root.meetTopBoundary()
    }

    LeftFunctionAreaJapanese {
        id: leftFunctionAreaJapanese
        objectName: "leftFunctionAreaJapanese"
        anchors.top: predictionArea.visible? predictionArea.bottom : parent.top
        anchors.topMargin: style.left.topMargin
        anchors.left: parent.left
        anchors.leftMargin: style.japaneseLeft.leftMargin
        width: style.left.width
        height: style.japaneseMiddle.height
        showBackButton: predictionMode

        onClickLanguageButton: root.changeLanguage()
        onClickInputCharacterChangeButton: {
            middleLayoutArea.clickInputCharacterChangeButton();
            root.clickInputCharacterChangeButton(root.mode);
        }

        onPressMore: {
            showMore = false;
            root.drawPredictionLayout();
        }

        onPressBack: {
            root.setToDefault(true);
        }

        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y)
        }
        onFocusDot: {
            focusRect.dotVisible = true;
            focusRect.dotColor = color;
        }
        onFocusImage: focusRect.image = img
        onFocusOut: root.setFocusOut()

        onMeetRightBoundary: middleLayoutArea.setKeyNavigation(row, 0)
        onMeetBottomBoundary: {
            if (root.predictionMode)
                backButton.setKeyNavigation();
            else {
                if (root.mode === "Hiragana" || root.mode === "Katakana") {
                    root.meetBottomBoundary();
                } else {
                    bottomArea.setKeyNavigation(-1);
                }
            }
        }
        onMeetLeftBoundary: rightFunctionArea.setKeyNavigation(row, "Left")
        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(1) :root.meetTopBoundary()
        onSetSymbolMode: {
            root.changeToSymbolMode();
        }
        onUnsetSymbolMode: {
            root.changeToHiraganaMode();
        }
    }

    MiddleLayout {
        id: middleLayoutArea
        objectName: "middleLayoutArea"
        mode: root.mode
        anchors.top: predictionArea.visible? predictionArea.bottom : parent.top
        anchors.topMargin: style.middle.topMargin
        anchors.left: leftFunctionAreaJapanese.right
        anchors.leftMargin: style.middle.leftMargin
        width: {
            switch (mode) {
                case "Hiragana":
                case "Katakana":
                    return style.japaneseMiddle.width;
                case "FullWidth-English":
                case "FullWidth-English-Shift":
                case "FullWidth-English-Shift-Lock":
                    return style.romanjiMiddle.width;
                case "Symbol":
                    return style.symbolMiddle.width;
            }
        }
        height: {
            switch (mode) {
                case "Hiragana":
                case "Katakana":
                    return style.japaneseMiddle.height;
                case "FullWidth-English":
                case "FullWidth-English-Shift":
                case "FullWidth-English-Shift-Lock":
                case "Symbol":
                    return style.romanjiMiddle.height;
            }
        }
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusImage: focusRect.image = img
        onSendKey: {
            root.keyPressed(rawcode, shift, eventType);
            if (root.mode === "FullWidth-English-Shift") {
                root.mode = "FullWidth-English";
                currRepeater.itemAt(currIndex).x = middleLayoutArea.currX;
                currRepeater.itemAt(currIndex).y = middleLayoutArea.currY;
                currRepeater.itemAt(currIndex).focus = true;
            }
        }
        onPressNextPrediction: root.drawPredictionLayout()
        onPredictionListSelected: setDefaultFocus()

        onMeetLeftBoundary: row === style.hiraganaKatakanaRows ? backButton.setKeyNavigation() : leftFunctionAreaJapanese.setKeyNavigation(row)
        onMeetRightBoundary: rightFunctionArea.setKeyNavigation(row)
        onMeetBottomBoundary: {
            if (root.mode === "Hiragana" || root.mode === "Katakana") {
                root.meetBottomBoundary();
            } else {
                bottomArea.setKeyNavigation(-1);
            }
        }
        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(2) :root.meetTopBoundary()
    }

    RightFunctionArea {
        id: rightFunctionArea
        objectName: "rightFunctionArea"
        mode: root.mode
        xOffset: style.japaneseLeft.leftMargin + style.left.width + style.middle.leftMargin + middleLayoutArea.width + style.right.leftMargin
        anchors.left: middleLayoutArea.right
        anchors.leftMargin: style.right.leftMargin
        anchors.top: predictionArea.visible? predictionArea.bottom : parent.top
        anchors.topMargin: style.right.topMargin
        width: style.right.width
        height: style.right.height + style.right.cellHeight + style.right.cellSpace
        enableNav: root.mode === "Hiragana" || root.mode === "Katakana"

        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusImage: focusRect.image = img
        onFocusOut: root.setFocusOut()

        enterText: {
            if(PluginProxy.unfixedStatus === true) {
                return Variables.EnterCaptionConfirm;
            } else {
                switch (enterKeyType) {
                    case Maliit.SearchEnterKeyType:
                        return Variables.EnterCaptionSearch;
                    default:
                        return Variables.EnterCaptionFinish;
                }
            }
        }

        Component.onCompleted: {
            clickVoiceButton.connect(activateSTT);
            clickClearAllButton.connect(clearAllPressed);
            sendKey.connect(keyPressed);
        }

        onMeetLeftBoundary: {
            if (!predictionMode) {
                if (mode === "Hiragana" && row === style.hiraganaKatakanaRows - 1) {
                    middleLayoutArea.setKeyNavigationToConvert();
                } else if (mode === "Katakana" && row === style.hiraganaKatakanaRows - 1) {
                    middleLayoutArea.setKeyNavigation(row, -1);
                } else {
                    if (row <= style.symbolEnglishRows - 1) middleLayoutArea.setKeyNavigation(row, -1);
                    else bottomArea.setKeyNavigation(root.mode);
                }
            } else {
                middleLayoutArea.setKeyNavigation(row, -1);
            }
        }
        onMeetRightBoundary: {
            if (row === style.hiraganaKatakanaRows){
                return backButton.setKeyNavigation()
            } else if (row === 4 && root.mode !== "Hiragana" && root.mode !== "Katakana") {
                return bottomArea.setKeyNavigation(root.mode)
            } else {
                return leftFunctionAreaJapanese.setKeyNavigation(row)
            }
        }
        onMeetTopBoundary: predictionArea.visible? predictionArea.setKeyNavigation(3) :root.meetTopBoundary()
        onMeetBottomBoundary:  {
            if (root.mode === "Hiragana" || root.mode === "Katakana") {
                root.meetBottomBoundary();
            } else {
                bottomArea.setKeyNavigation(-2);
            }
        }
    }

    BottomPanel {
        id: bottomArea
        objectName: "bottomArea"
        anchors.left: leftFunctionAreaJapanese.right
        anchors.leftMargin: style.middle.leftMargin
        anchors.top: middleLayoutArea.bottom
        anchors.topMargin: style.bottom.topMargin
        visible: root.mode !== "Hiragana" && root.mode !== "Katakana"
        height: style.bottom.height
        width:  middleLayoutArea.width
        onSendKey: root.keyPressed(rawcode, shift, eventType)
        onTtsService: root.ttsService(text)
        onFocusItem: {
            focusRect.focusStyle = style.focus;
            root.setFocusItem(item,x,y);
        }
        onFocusImage: focusRect.image = img
        onFocusOut: root.setFocusOut()
        onMeetTopBoundary: {
            if (column == -1) {
                middleLayoutArea.setKeyNavigation(-1,5);
            } else {
                rightFunctionArea.setKeyNavigation(3,"Bottom");
            }
        }
        onMeetBottomBoundary: root.meetBottomBoundary()
    }

    Item {
        id: dragIconArea
        objectName:"dragIconArea"
        anchors.left: rightFunctionArea.right
        anchors.top: noWords? parent.top : predictionArea.bottom
        width: style.right.rightMargin
        height: noWords? parent.height : parent.height - predictionArea.height
        visible:  isPortrait

        Image {
            id: dragIcon
            source: style.getImage("ic_drag");
            smooth: true
            anchors.centerIn: dragIconArea
        }
    }

    onModeChanged: {
        Prediction.clearPredictionList();
        showMore = false;
        if (root.mode === "Hiragana" || root.mode === "Katakana")
        {
            style.japaneseLeft.leftMargin = style.japaneseLeft.defaultLeftMargin;
        }
        else if (root.mode === "Symbol")
        {
            style.japaneseLeft.leftMargin = style.japaneseLeft.symbolLeftMargin;
        }
        else
        {
            style.japaneseLeft.leftMargin = style.japaneseLeft.romanjiLeftMargin;
        }
    }

    FocusPanel {
        id: focusRect
        objectName: "focusRect"
        focusStyle: style.focus
        visible: true
    }

    Connections {
        target: Prediction
        onActiveChanged: {
            if (!active) {
                root.predictionMode = false;
                root.predictionNum = 0;
                showMore = false;
            }
        }
    }

    function selectPredictionWords() {
        var words = [];
        var maxItem = Prediction.list.length > noPredictionItems ? noPredictionItems :Prediction.list.length;
        for (var i = 0; i < maxItem; i++) {
            if (Prediction.list[i].length > 6) {
                words.push(Prediction.list[i].substr(0,4) + "...");
            } else {
                words.push(Prediction.list[i]);
            }
        }
        showMore = Prediction.list.length > 10;
        return words;
    }

    function drawPredictionLayout() {
        var row = Variables.FullScreenPredictionRows;
        var column = Variables.FullScreenPredictionColumns;
        var model = [];
        for (var i = 0; i < row * column; i++) {
            if (Prediction.list[predictionNum] !== undefined) {
                model.push(Prediction.list[predictionNum]);
            } else {
                model.push('');
            }
            predictionNum++;
        }

        // set layout to grid
        predictionMode = true;
        middleLayoutArea.setPredictionLayoutData(row, column, model);
        showPageText();
        setDefaultFocus();
    }

    function setToDefault(visible) {
        predictionMode = false;
        predictionNum = 0;
        predictionHead = 0;
        mode = "Hiragana";
        middleLayoutArea.clickInputCharacterChangeButton();
        leftFunctionAreaJapanese.setToDefault();
        leftFunctionAreaJapanese.supportShiftMode = false;
        setDefaultFocus();
    }

    function setEnterKeyText (unfixedStatus) {
        if (unfixedStatus === true) {
            return Variables.EnterCaptionConfirm;
        } else {
            switch (enterKeyType) {
                case Maliit.SearchEnterKeyType:
                    return Variables.EnterCaptionSearch;
                default:
                    return Variables.EnterCaptionFinish;
            }
        }
    }

    function setDefaultFocus() {
        if (middleLayoutArea.defaultFocus !== undefined) {
            var item = middleLayoutArea.currRepeater.itemAt(middleLayoutArea.defaultFocus);
            if (item.x === 0) middleLayoutArea.currRepeater.itemAt(0).focus = true;
            else item.focus = true;
        }
    }

    function setFocusToEnter() {
        rightFunctionArea.setFocusTo("Enter");
    }

    function showPageText() {
        var currentPageNum = 0;
        var totalPgaeNum = 0;
        var currentPageTxt = "";
        var totalPgaeTxt = "";

        predictionPage = Prediction.list.length % (Variables.FullScreenPredictionRows * Variables.FullScreenPredictionColumns);
        if (predictionPage === 0) {
            currentPageNum = predictionNum / (Variables.FullScreenPredictionRows * Variables.FullScreenPredictionColumns);
            totalPgaeNum = Prediction.list.length / (Variables.FullScreenPredictionRows * Variables.FullScreenPredictionColumns);
        } else {
            currentPageNum = predictionNum / (Variables.FullScreenPredictionRows * Variables.FullScreenPredictionColumns);
            totalPgaeNum = Prediction.list.length / (Variables.FullScreenPredictionRows * Variables.FullScreenPredictionColumns) + 1;
        }

        currentPageTxt = parseInt(currentPageNum);;
        totalPgaeTxt = parseInt(totalPgaeNum);

        predictionArea.pageTxt = currentPageTxt + "/" + totalPgaeTxt;
    }
}
