/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

import "../keyboard-common"
import "../keyboard-common/commonvariables.js" as CommonVariables
import "variables.js" as Variables

Item {
    id: root
    objectName: "bottomArea"
    property variant preColumn: "defaultIndex"
    signal ttsService(string text)
    signal sendKey(string rawcode, bool shift, int eventType)
    signal meetTopBoundary(variant column)
    signal meetBottomBoundary()
    signal focusItem(var item, int x, int y)
    signal focusOut()
    signal focusImage(url img)
    signal pressMore()
    signal pressBack()

    property int xOffset: style.middle.leftMargin + style.left.width + style.japaneseLeft.leftMargin
    property int yOffset: style.left.topMargin + style.middle.height + style.bottom.topMargin

    function setFocusIn(item) {
        root.focusItem(item, item.x + root.xOffset, item.y + root.yOffset);
    }

    function updateBottomLayout() {
        navButtons.forceLayout();
        row.forceLayout();
    }

    Row {
        id: row
        objectName: "bottomRow"
        spacing: style.bottom.cellSpace

        // spaceBar
        ButtonBase {
            id: spaceButton
            objectName: "spaceButton"
            image: style.getImage("space_bar")
            onStateChanged: {
                switch(state) {
                    case "Focus":
                    case "Select":
                        root.setFocusIn(spaceButton);
                        root.focusImage(style.getImage("space_bar_f"))
                        break;
                    default:
                        break;
                }
            }
            onExited: root.focusOut()
            onReleased: root.sendKey(Variables.FullWidthSpaceRawCode, false, eventType)
            onFocusChanged: if (focus) root.ttsService("Space")
            width: root.width
            height: root.height

            KeyNavigation.left: moveCursorRightButton
            Keys.onPressed: {
                if (event.key === Qt.Key_Up) {
                    meetTopBoundary(-1);
                    event.accepted = true;
                } else
                if (event.key === Qt.key_Down) {
                    meetBottomBoundary();
                    event.accepted = true;
                }
            }
        }

        Row {
            id: navButtons
            objectName: "navButtons"
            width : style.right.width
            height: style.bottom.height
            spacing: style.bottom.navCellSpace

            ButtonBase {
                id: moveCursorLeftButton
                objectName: "moveCursorLeftButton"
                buttonStyle: style.panelButton
                image: style.getImage("back")
                onTtsService: root.ttsService(qsTr("Left"))
                height: style.bottom.height
                width: style.bottom.navBtnWidth
                fontSizeMode: Text.Fit

                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            root.focusItem(moveCursorLeftButton, moveCursorLeftButton.x + root.xOffset + spaceButton.width + style.bottom.cellSpace,
                                           moveCursorLeftButton.y + root.yOffset);
                            root.focusImage(style.getImage("back_f"));
                            break;
                        default:
                            break;
                    }
                }
                onExited: root.focusOut()
                onReleased: {
                    moveCursorPosition(CommonVariables.left,eventType);
                }

                KeyNavigation.left: spaceButton
                KeyNavigation.right: moveCursorRightButton
                Keys.onPressed: {
                    if (event.key === Qt.Key_Up) {
                        meetTopBoundary(-2);
                        event.accepted = true;
                    } else
                    if (event.key === Qt.Key_Down) {
                        meetBottomBoundary();
                        event.accepted = true;
                    }
                }
            }

            RightButtonBase {
                id: moveCursorRightButton
                objectName: "moveCursorRightButton"
                buttonStyle: style.panelButton
                image: style.getImage("next")
                onTtsService: root.ttsService(qsTr("Right"))
                height: style.bottom.height
                width: style.bottom.navBtnWidth
                fontSizeMode: Text.Fit
                onReleased: moveCursorPosition(CommonVariables.right,eventType)
                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            root.focusItem(moveCursorRightButton, moveCursorRightButton.x + root.xOffset + spaceButton.width + style.bottom.cellSpace,
                                             moveCursorRightButton.y + root.yOffset);
                            root.focusImage(style.getImage("next_f"));
                            break;
                        default:
                            break;
                    }
                }
                onExited: root.focusOut()

                KeyNavigation.left: moveCursorLeftButton
                KeyNavigation.right: spaceButton
                Keys.onPressed: {
                    if (event.key === Qt.Key_Up) {
                        meetTopBoundary(-2);
                        event.accepted = true;
                    } else
                    if (event.key === Qt.Key_Down) {
                        meetBottomBoundary();
                        event.accepted = true;
                    }
                }
            }
        }
    }

    Keys.onPressed: {
        if (event.key === Qt.Key_Down) {
            meetBottomBoundary();
            event.accepted = true;
        }
    }

    function setKeyNavigation(column) {
        if (column === -2) {
            moveCursorLeftButton.focus = true;
            root.preColumn = 0;
        } else {
            spaceButton.focus = true;
            root.preColumn = column
        }
    }
}
