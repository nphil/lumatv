/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0

QtObject {
    id: root
    property int resolution
    property int height: 180 / resolution
    property color bgColor: "#42484E"
    property real opacity: 1.0
    property int radius: 24 / resolution
    property int cellSpace: 42 / resolution
    property int constWidth: 294 / resolution
    property int minMargin:   40 / resolution

    property var panelButton: QtObject {
        property color bgMerge:"#42484E"
        property string fontFamily: defaultFontFamily
        property int fontWeight: 100 / resolution
        property int width: 294 / resolution
        property int height: 108 / resolution
        property int focusOffset: 36 / resolution
        property int radius: 12 / resolution
        property int minimumMargin: 12 / resolution

        property var normal: QtObject {
            property color bgColor: "#62676A"
            property color fgColor: "#E6E6E6"
            property color borderColor: "#6E7276"
            property int borderWidth: 4 / resolution
            property int fontSize: 62 / resolution
        }
        property var disable: QtObject {
            property color bgColor: "transparent"
            property color fgColor: "transparent"
            property color borderColor: "transparent"
            property int borderWidth: 0
            property int fontSize: 40 / resolution
        }
    }

    property var leftBtn: QtObject {
        property int width:  126 / resolution
        property int height: 126 / resolution
    }

    property var rightBtn: QtObject {
        property int width:  126 / resolution
        property int height: 126 / resolution
    }

    property var txtLabel: QtObject {
        property int height: 126 / resolution
    }

    property var moreButton: QtObject {
        property string fontFamily: defaultFontFamily
        property color bgMerge:"#3B4045"

        property var normal: QtObject {
            property color bgColor: "#42484E"
            property color fgColor: "#E6E6E6"
            property color borderColor: "#545A64"
            property int borderWidth: 4 / resolution
            property int fontSize: 66 / resolution
        }
        property var disable: QtObject {
            property color bgColor: "#42484E"
            property color fgColor: "#42484E"
            property color borderColor: "#545A64"
            property int borderWidth: 4 / resolution
            property int fontSize: 66 / resolution
        }
    }
}

