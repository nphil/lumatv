/* @@@LICENSE
*
*      Copyright (c) 2013-2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import com.meego.maliit 1.0
import "../keyboard-common"
import "variables.js" as Variables

Rectangle {
    id: root
    objectName: "hidPredictionWidget"
    property variant predictions: Prediction.list
    property variant predictionSlice
    property int maxLengthChar: 108
    property int maxCnt: 5
    property int pageCnt: 1
    property int head: 0
    property int cnt: 0
    property int reminder: 0
    property int mode: Variables.HidModeRomanHira
    signal setHidModeFromVkb(int mode)
    signal orientationChanged(string orientation)
    color: style.bgColor
    radius: style.radius

    function setFocusItem(item,x,y) {
        focusRect.image = "";
        focusRect.visible = true;
        focusRect.width =  item.state === "Select"? focusRect.width  * focusRect.focusStyle.selectRatio : item.width  + focusRect.focusStyle.widthOffset;
        focusRect.height = item.state === "Select"? focusRect.height * focusRect.focusStyle.selectRatio : item.height + focusRect.focusStyle.heightOffset;
        focusRect.x = x - (focusRect.width - item.width)/2;
        focusRect.y = y - (focusRect.height - item.height)/2;
        focusRect.focusTxt = item.wordText;
        focusRect.hotKeyText = item.hotKeyText;
        focusRect.fontSize = item.fontSize;
    }

    function focusOut() {
        focusRect.visible = false;
        focusRect.focusTxt = "";
        focusRect.hotKeyText = "";
        focusRect.image = "";
    }

    function updateHeight() {
        PluginProxy.setPanelSize(style.hidPredWidth, style.hidPredHight);
        height = style.hidPredHight;
    }

    function setMovableArea() {
        PluginProxy.setMovableArea(Maliit.MovableAreaLeft, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaTop, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaRight, 0, 0, 0, 0);
        PluginProxy.setMovableArea(Maliit.MovableAreaBottom, 0, 0, 0, 0);
    }

    onOrientationChanged: {
        if (orientation.includes("portrait")) {
            setMovableArea()
            root.maxCnt =  5
            root.maxLengthChar = 60
        }
        else {
            root.maxCnt = 6;
            root.maxLengthChar = 108
        }
        updateHeight();
        splitSlice();
        focusOut();
    }

    onPredictionsChanged: splitSlice()
    onHeadChanged: predictionSlice = predictions.slice(head, head+cnt)

    ListModel {
        id: cntArray
    }

    HidPredictionItem {
        id: prevButton
        objectName: "prevButton"
        anchors.top: parent.top
        anchors.topMargin: style.hidTopMargin
        anchors.left: parent.left
        anchors.leftMargin: style.hid.hidPreButton.leftMargin
        width: style.hid.hidPreButton.width
        height: style.hid.hidPreButton.height
        wordText: "<"   // FIXME: this should be replaced with image file.
        hotKeyText: "F10"
        onReleased: showPrevPrediction()
        onStateChanged: {
            switch(state) {
                case "Focus":
                case "Select":
                    focusRect.focusStyle = style.panelFocus;
                    root.setFocusItem(prevButton, prevButton.x,prevButton.y);
                    break;
                case "Disable":
                    root.focusOut();
                    break;
                default:
                    break;
            }
        }
        onExited: root.focusOut()
    }

    Row {
        id: predictionRow
        objectName: "predictionRow"
        anchors.top: parent.top
        anchors.topMargin: style.hidTopMargin
        anchors.left: prevButton.right
        anchors.leftMargin: style.hid.hidPredRow.leftMargin
        spacing:style.hid.hidPredRow.cellSpace
        width:  style.hid.hidPredRow.width
        height: style.hid.hidPredRow.height

        Repeater {
            id: predictionRepeater
            objectName: "predictionRepeater"
            model: predictionSlice
            onItemRemoved: item.removed = true
            HidPredictionItem {
                width: cntArray && cntArray.get(pageCnt-1)
                       ? (
                             (((cntArray.get(pageCnt) && (cntArray.get(pageCnt).cnt === 0)) || pageCnt === cntArray.count) && cntArray.get(pageCnt-1).cnt !== maxCnt)
                             ? (wordWidth + 2 * style.hid.hidPredRow.leftMargin)
                             : (predictionRow.width + style.hid.hidPredRow.cellSpace - style.hid.hidPredRow.cellSpace * cntArray.get(pageCnt-1).cnt) * (predictionSlice[index].length + 2) / cntArray.get(pageCnt-1).lengthChar
                         )
                       : 0
                height: style.hid.hidPredItem.height
                wordText: {
                    if (modelData.length > 6) {
                        return modelData.substr(0,4) + "...";
                    } else {
                        return modelData
                    }
                }
                hotKeyText: "F" + (index + 1)
                onReleased: selectPrediction(head + index)
                onStateChanged: {
                    switch(state) {
                        case "Focus":
                        case "Select":
                            focusRect.focusStyle = style.panelFocus;
                            root.setFocusItem(predictionRepeater.itemAt(index), predictionRepeater.itemAt(index).x + prevButton.width + style.hid.hidPreButton.leftMargin,
                                              predictionRepeater.itemAt(index).y + style.hidTopMargin);
                            break;
                        default:
                            break;
                    }
                }
                onExited: root.focusOut()
            }
        }
    }

    HidPredictionItem {
        id: nextButton
        objectName: "nextButton"
        anchors.top: parent.top
        anchors.topMargin: style.hidTopMargin
        anchors.left:predictionRow.right
        anchors.leftMargin: style.hid.hidNextButton.leftMargin
        width:  style.hid.hidNextButton.width
        height: style.hid.hidNextButton.height
        wordText: ">"   // FIXME: this should be replaced with image file.
        hotKeyText: "F11"
        borderPosition: 0
        onReleased: showNextPrediction()
        onStateChanged: {
            switch(state) {
                case "Focus":
                case "Select":
                    focusRect.focusStyle = style.panelFocus;
                    root.setFocusItem(nextButton, nextButton.x,nextButton.y);
                    break;
                case "Disable":
                    root.focusOut();
                    break;
                default:
                    break;
            }
        }
        onExited: root.focusOut()
    }

    HidPredictionItem {
        id: hidModeButton
        objectName: "hidModeButton"
        anchors.top: parent.top
        anchors.topMargin: style.hidTopMargin
        anchors.right: parent.right
        anchors.rightMargin: style.hid.hidModeButton.rightMargin
        width:  style.hid.hidModeButton.width
        height: style.hid.hidModeButton.height
        wordText: Variables.HidModeCaption[root.mode]
        hotKeyText: "F12"
        borderPosition: 0
        onReleased: nextHidMode()

        onStateChanged: {
            switch(state) {
                case "Focus":
                case "Select":
                    focusRect.focusStyle = style.panelFocus;
                    root.setFocusItem(hidModeButton, hidModeButton.x,hidModeButton.y);
                    break;
                case "Disable":
                    root.focusOut();
                    break;
                default:
                    break;
            }
        }
        onExited: root.focusOut()
    }

    FocusPanel {
        id: focusRect
        objectName: "focusRect"
        focusStyle: style.focus
        visible: false
    }

    function onSendKey(keycode) {
        if (keycode < Qt.Key_F1 || Qt.Key_F12 < keycode)
            return;

        if (keycode === Qt.Key_F10)
            showPrevPrediction();
        else if (keycode === Qt.Key_F11)
            showNextPrediction();
        else if (keycode === Qt.Key_F12)
            nextHidMode();
        else {
            var selectedIndex = keycode - Qt.Key_F1;
            selectPrediction(head + selectedIndex);
        }
    }

    function selectPrediction(index) {
        if (index >= 0 && index < Prediction.list.length) {
            Prediction.onSelected(index);
            head = 0;
        }
    }

    function setHidModeFromHid(hidMode) {
        mode = hidMode;
    }

    function setFocusToHID() {
        root.focus = true;
    }

    function nextHidMode() {
        mode++;
        if (Variables.HidModeKanaKata < mode)
            mode = Variables.HidModeRomanHira;
        setHidModeFromVkb(mode);
    }

    function setHidModeforNumberContent() {
        setHidModeFromVkb(Variables.HidModeHalfWidthEnglish);
    }

    function showPrevPrediction() {
        if (pageCnt > 1 && head - cntArray.get(pageCnt-2).cnt >= 0) {
            cnt = cntArray.get(pageCnt-2).cnt;
            head = head - cntArray.get(pageCnt-2).cnt;
            pageCnt -= 1;
            checkButtonState();
        }
    }

    function showNextPrediction() {
        if (cntArray.get(pageCnt) && cntArray.get(pageCnt).cnt && head + cntArray.get(pageCnt-1).cnt < Prediction.list.length) {
            cnt = cntArray.get(pageCnt).cnt;
            head = head + cntArray.get(pageCnt-1).cnt;
            pageCnt += 1;
            checkButtonState();
        }
    }

    function splitSlice() {
        pageCnt = 1;
        head = 0;
        var i;
        var indexArray =0;
        var cnt = 0;
        var lengthChar = 0;
        reminder = predictions.length;
        i = cntArray.count-1;
        while (i>=0) {
            cntArray.setProperty(i, "cnt", 0);
            cntArray.setProperty(i, "lengthChar", 0);
            i--;
        }
        for (i=0; i<predictions.length; i++) {
            cnt++;
            lengthChar += (predictions[i].length +2);
            if (lengthChar + cnt < maxLengthChar && cnt < maxCnt) {
                if (cnt !== reminder)
                    continue;
            } else if (lengthChar + cnt >= maxLengthChar && cnt <= maxCnt) {
                cnt--;
                lengthChar -= (predictions[i--].length +2);
                reminder -= cnt;
            } else if (cnt === maxCnt) {
                reminder -= cnt;
            }
            if (cntArray.get(indexArray) && cntArray.get(indexArray).cnt === 0) {
                cntArray.setProperty(indexArray, "cnt", cnt);
                cntArray.setProperty(indexArray, "lengthChar", lengthChar);
            } else {
                cntArray.append({"cnt" : cnt, "lengthChar" : lengthChar});
            }
            indexArray++;
            lengthChar = 0;
            cnt = 0;
            continue;
        }
        if (cntArray.get(0)) {
            cnt = cntArray.get(0).cnt;
            predictionSlice = predictions.slice(head, cnt);
            checkButtonState();
        }
    }

    function checkButtonState() {
        // prev button
        if (pageCnt > 1 && head - cntArray.get(0).cnt >= 0)
            prevButton.state = "Normal";
        else
            prevButton.state = "Disable";

        // next button
        if (head + cntArray.get(pageCnt-1).cnt < predictions.length)
            nextButton.state = "Normal";
        else
            nextButton.state = "Disable";
    }
}
