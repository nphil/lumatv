/* @@@LICENSE
*
*      Copyright (c) 2020 LG Electronics, Inc.
*
* Confidential computer software. Valid license from LG required for
* possession, use or copying. Consistent with FAR 12.211 and 12.212,
* Commercial Computer Software, Computer Software Documentation, and
* Technical Data for Commercial Items are licensed to the U.S. Government
* under vendor's standard commercial license.
*
* LICENSE@@@ */

import QtQuick 2.0
import "../keyboard-common/style-portrait"

Style {
    id: root
    property int keyboardDefaultHeight: 858 / resolution
    property int keyboardDefaultWidth: 2160 / resolution
    property int romanjiKeyboardWidth: 2160 / resolution
    property int spaceBarKeyboardHeight: 894 / resolution
    property int symbolKeyboardWidth: 2160 / resolution

    predictPanel : JapanesePredictionPanelStyle {resolution: root.resolution}

    property var romanjiMiddle: QtObject {
        property int width: 1170 / resolution
        property int height: 564 / resolution
    }

    property var japaneseMiddle: QtObject {
        property int width: 1170 / resolution
        property int height: 708 / resolution
    }

    property var japaneseLeft: QtObject {
        property int leftMargin: 195 / resolution
        property int defaultLeftMargin: 195 / resolution
        property int romanjiLeftMargin: 195 / resolution
        property int symbolLeftMargin: 195 / resolution
        property int rightMargin: 30 / resolution
    }


    property var symbolMiddle: QtObject {
        property int width: 1170 / resolution
    }

    property var moreMiddle: QtObject {
        property int cellWidth: 225 / resolution
    }

    property var hid: QtObject{
        property int hidTopMargin: 66 / resolution
        property int hidPredHight: 264 / resolution

        property var hidPreButton: QtObject {
            property int leftMargin: 114 / resolution
            property int width: 114 / resolution
            property int height: 132 / resolution
        }

        property var hidPredRow: QtObject {
            property int leftMargin: 24 / resolution
            property int cellSpace: 24 / resolution
            property int width: 1412 / resolution
            property int height:  132 / resolution
        }

        property var hidPredItem: QtObject {
            property string fontFamily: defaultFontFamily
            property int height: 132 / resolution
            property int radius: 12 / resolution
            property int focusOffset: 36 / resolution
            property var normal: QtObject {
                property color bgColor: "#42484E"
                property color fgColor: "#E6E6E6"
                property color borderColor: "#545A64"
                property int borderWidth: 4 / resolution
                property int fontSize: 66 / resolution
            }
            property var disable: QtObject {
                property color bgColor: "transparent"
                property color fgColor: "#42484E"
                property color borderColor: "#545A64"
                property int borderWidth: 4 / resolution
                property int fontSize: 38 / resolution
            }
            property var hotKey: QtObject {
                property int rightMargin: 12 / resolution
                property int height: 42 / resolution
                property int fontSize: 36 / resolution
                property color fgColor: "#ABAEB3"
            }
            property var word: QtObject {
                property int height: 78 / resolution
            }
        }

        property var hidNextButton: QtObject {
            property int leftMargin: 24 / resolution
            property int width: 114 / resolution
            property int height: 132 / resolution
        }

        property var hidModeButton: QtObject {
            property int rightMargin: 114 / resolution
            property int width: 220 / resolution
            property int height: 132 / resolution
        }
    }

    // resolution independent properties
    property int hiraganaKatakanaColumns: 14
    property int hiraganaKatakanaRows: 5
    property int englishColumns: 10
    property int symbolColumns: 12
    property int symbolEnglishRows: 4
}
